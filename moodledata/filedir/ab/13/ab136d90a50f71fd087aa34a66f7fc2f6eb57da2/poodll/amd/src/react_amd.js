/* jshint ignore:start */
define(['jquery', 'core/log', 'filter_poodll/react-with-addons'], function ($, log, React) {

    "use strict"; // jshint ;_;

    log.debug('Filter PoodLL: revealjs initialising');
    window.React = React;
    return {};
});
/* jshint ignore:end */