<?PHP // $Id: filter_poodll.php ,v 1.3 2012/05/16 12:47:13 Justin Hunt Exp $ 
// PoodLl Filter
$string['recui_record'] = 'Aufnahme';
$string['recui_pause'] = 'Pause';
$string['recui_play'] = 'Wiedergabe';
$string['recui_continue'] = 'Weiter';
$string['recui_stop'] = 'Stop';
$string['recui_save'] = 'Save';
$string['recui_time'] = 'Dauer:';
$string['recui_audiogain'] = 'Lautstärke';
$string['recui_silencelevel'] = 'Geräuschpegel';
$string['recui_echo'] = 'Echokompensation';
$string['recui_loopback'] = 'Loopback(Mikr->Lautspr)';
$string['recui_audiorate'] = 'Geschwindigkeit';
$string['recui_on'] = 'An';
$string['recui_off'] = 'Aus';
$string['recui_ok'] = 'OK';
$string['recui_close'] = 'Schließen';
$string['recui_uploading'] = 'Hochladen';
$string['recui_converting'] = 'Konvertierung';
$string['recui_inaudibleerror'] = 'Wir können Sie nicht hören. Bitte überprüfen Sie die Flash- und Browserberechtigungen.';
$string['recui_timeouterror'] = 'Zeitüberschreitung der Anforderung';
$string['recui_uploaderror'] = 'Ein Fehler ist aufgetreten und Ihre Datei wurde NICHT hochgeladen.';
