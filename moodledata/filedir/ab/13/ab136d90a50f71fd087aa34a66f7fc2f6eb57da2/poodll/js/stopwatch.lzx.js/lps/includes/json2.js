var $runtime = "dhtml";
var $dhtml = true;
var $as3 = false;
var $as2 = false;
var $swf10 = false;
var $j2me = false;
var $debug = false;
var $js1 = true;
var $backtrace = false;
var $swf7 = false;
var $swf9 = false;
var $svg = false;
var $swf8 = false;
var $mobile = false;
var $profile = false;
(function () {
    if (!this.JSON) {
        this.JSON = {}
    }
})();
(function () {
    var f;
    var quote;
    var str;
    f = function ($0) {
        return $0 < 10 ? "0" + $0 : $0
    };
    quote = function ($0) {
        escapable.lastIndex = 0;
        return ( escapable.test($0) ? '"' + $0.replace(escapable, function ($0) {
            var $1 = meta[$0];
            return typeof $1 === "string" ? $1 : "\\u" + ("0000" + $0.charCodeAt(0).toString(16)).slice(-4)
        }) + '"' : '"' + $0 + '"')
    };
    str = function ($0, $1) {
        var $2, $3, $4, $5, $6 = gap, $7, $8 = $1[$0];
        if ($8 && typeof $8 === "object" && typeof $8.toJSON === "function") {
            $8 = $8.toJSON($0)
        }
        ;
        if (typeof rep === "function") {
            $8 = rep.call($1, $0, $8)
        }
        ;
        switch (typeof $8) {
            case "string":
                return quote($8);
            case "number":
                return isFinite($8) ? String($8) : "null";
            case "boolean":
            case "null":
                return String($8);
            case "object":
                if (!$8) {
                    return "null"
                }
                gap += indent;
                $7 = [];
                if (Object.prototype.toString.apply($8) === "[object Array]") {
                    $5 = $8.length;
                    for ($2 = 0; $2 < $5; $2 += 1) {
                        $7[$2] = str($2, $8) || "null"
                    }
                    ;$4 = $7.length === 0 ? "[]" : (gap ? "[\n" + gap + $7.join(",\n" + gap) + "\n" + $6 + "]" : "[" + $7.join(",") + "]");
                    gap = $6;
                    return $4
                }
                if (rep && typeof rep === "object") {
                    $5 = rep.length;
                    for ($2 = 0; $2 < $5; $2 += 1) {
                        $3 = rep[$2];
                        if (typeof $3 === "string") {
                            $4 = str($3, $8);
                            if ($4) {
                                $7.push(quote($3) + (gap ? ": " : ":") + $4)
                            }
                        }
                    }
                } else {
                    for ($3 in $8) {
                        if (Object.hasOwnProperty.call($8, $3)) {
                            $4 = str($3, $8);
                            if ($4) {
                                $7.push(quote($3) + (gap ? ": " : ":") + $4)
                            }
                        }
                    }
                }
                $4 = $7.length === 0 ? "{}" : (gap ? "{\n" + gap + $7.join(",\n" + gap) + "\n" + $6 + "}" : "{" + $7.join(",") + "}");
                gap = $6;
                return $4;

        }
    };
    if (typeof Date.prototype.toJSON !== "function") {
        Date.prototype.toJSON = function ($0) {
            return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + f(this.getUTCMonth() + 1) + "-" + f(this.getUTCDate()) + "T" + f(this.getUTCHours()) + ":" + f(this.getUTCMinutes()) + ":" + f(this.getUTCSeconds()) + "Z" : null
        };
        String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function ($0) {
            return this.valueOf()
        }
    }
    ;var cx = new RegExp("[\\u0000\\u00ad\\u0600-\\u0604\\u070f\\u17b4\\u17b5\\u200c-\\u200f\\u2028-\\u202f\\u2060-\\u206f\\ufeff\\ufff0-\\uffff]", "g"),
        escapable = new RegExp('[\\\\\\"\\x00-\\x1f\\x7f-\\x9f\\u00ad\\u0600-\\u0604\\u070f\\u17b4\\u17b5\\u200c-\\u200f\\u2028-\\u202f\\u2060-\\u206f\\ufeff\\ufff0-\\uffff]', "g"),
        gap, indent, meta = {"\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r", '"': '\\"', "\\": "\\\\"}, rep;
    if (typeof JSON.stringify !== "function") {
        JSON.stringify = function ($0, $1, $2) {
            var $3;
            gap = "";
            indent = "";
            if (typeof $2 === "number") {
                for ($3 = 0; $3 < $2; $3 += 1) {
                    indent += " "
                }
            } else if (typeof $2 === "string") {
                indent = $2
            }
            ;rep = $1;
            if ($1 && typeof $1 !== "function" && (typeof $1 !== "object" || typeof $1.length !== "number")) {
                throw new Error("JSON.stringify")
            }
            ;
            return str("", {"": $0})
        }
    }
    ;
    if (typeof JSON.parse !== "function") {
        JSON.parse = function ($0, reviver) {
            var walk;
            walk = function ($0, $1) {
                var $2, $3, $4 = $0[$1];
                if ($4 && typeof $4 === "object") {
                    for ($2 in $4) {
                        if (Object.hasOwnProperty.call($4, $2)) {
                            $3 = walk($4, $2);
                            if ($3 !== undefined) {
                                $4[$2] = $3
                            } else {
                                delete $4[$2]
                            }
                        }
                    }
                }
                ;
                return reviver.call($0, $1, $4)
            };
            var $1;
            $0 = String($0);
            cx.lastIndex = 0;
            if (cx.test($0)) {
                $0 = $0.replace(cx, function ($0) {
                    return "\\u" + ("0000" + $0.charCodeAt(0).toString(16)).slice(-4)
                })
            }
            ;
            if (new RegExp("^[\\],:{}\\s]*$").test($0.replace(new RegExp('\\\\(?:["\\\\\\/bfnrt]|u[0-9a-fA-F]{4})', "g"), "@").replace(new RegExp('"[^"\\\\\\n\\r]*"|true|false|null|-?\\d+(?:\\.\\d*)?(?:[eE][+\\-]?\\d+)?', "g"), "]").replace(new RegExp("(?:^|:|,)(?:\\s*\\[)+", "g"), ""))) {
                $1 = eval("(" + $0 + ")");
                return typeof reviver === "function" ? walk({"": $1}, "") : $1
            }
            ;
            throw new SyntaxError("JSON.parse")
        }
    }
})();