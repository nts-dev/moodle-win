<?php
/**
 * Created by PhpStorm.
 * User: ishineguy
 * Date: 2018/06/16
 * Time: 19:31
 */

namespace filter_poodll;

class constants {
    const MOD_FRANKY = 'filter_poodll';
    const M_COMP = 'filter_poodll';
    const CLOUDPOODLL = 'https://cloud.poodll.com';
   // const CLOUDPOODLL = 'https://cloudpoodll.poodll.com';
   // const CLOUDPOODLL = 'http://localhost/moodle';

}
