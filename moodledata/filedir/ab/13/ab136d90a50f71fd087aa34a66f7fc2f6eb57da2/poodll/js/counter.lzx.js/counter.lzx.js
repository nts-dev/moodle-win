LzResourceLibrary.lzfocusbracket_rsrc={ptype:"sr",frames:['lps/components/lz/resources/focus/focus_top_lft.png','lps/components/lz/resources/focus/focus_top_rt.png','lps/components/lz/resources/focus/focus_bot_lft.png','lps/components/lz/resources/focus/focus_bot_rt.png'],width:7,height:7,sprite:'lps/components/lz/resources/focus/focus_top_lft.sprite.png',spriteoffset:0};LzResourceLibrary.lzfocusbracket_shdw={ptype:"sr",frames:['lps/components/lz/resources/focus/focus_top_lft_shdw.png','lps/components/lz/resources/focus/focus_top_rt_shdw.png','lps/components/lz/resources/focus/focus_bot_lft_shdw.png','lps/components/lz/resources/focus/focus_bot_rt_shdw.png'],width:9,height:9,sprite:'lps/components/lz/resources/focus/focus_top_lft_shdw.sprite.png',spriteoffset:7};LzResourceLibrary.lzscrollbar_ythumbtop_rsc={ptype:"sr",frames:['lps/components/lz/resources/scrollbar/scrollthumb_y_top.png'],width:12.0,height:1.0,spriteoffset:16};LzResourceLibrary.lzscrollbar_ythumbmiddle_rsc={ptype:"sr",frames:['lps/components/lz/resources/scrollbar/autoPng/scrollthumb_y_mid.png'],width:12.0,height:6.0,spriteoffset:17};LzResourceLibrary.lzscrollbar_ythumbbottom_rsc={ptype:"sr",frames:['lps/components/lz/resources/scrollbar/autoPng/scrollthumb_y_bot.png'],width:12.0,height:2.0,spriteoffset:23};LzResourceLibrary.lzscrollbar_ythumbgripper_rsc={ptype:"sr",frames:['lps/components/lz/resources/scrollbar/thumb_y_gripper.png'],width:9.0,height:440.0,spriteoffset:25};LzResourceLibrary.lzscrollbar_ybuttontop_rsc={ptype:"sr",frames:['lps/components/lz/resources/scrollbar/autoPng/scrollbtn_y_top_up.png','lps/components/lz/resources/scrollbar/autoPng/scrollbtn_y_top_mo.png','lps/components/lz/resources/scrollbar/autoPng/scrollbtn_y_top_dn.png','lps/components/lz/resources/scrollbar/autoPng/scrollbtn_y_top_dsbl.png'],width:12,height:13,sprite:'lps/components/lz/resources/scrollbar/autoPng/scrollbtn_y_top_up.sprite.png',spriteoffset:465};LzResourceLibrary.lzscrollbar_ybuttonbottom_rsc={ptype:"sr",frames:['lps/components/lz/resources/scrollbar/autoPng/scrollbtn_y_bot_up.png','lps/components/lz/resources/scrollbar/autoPng/scrollbtn_y_bot_mo.png','lps/components/lz/resources/scrollbar/autoPng/scrollbtn_y_bot_dn.png','lps/components/lz/resources/scrollbar/autoPng/scrollbtn_y_bot_dsbl.png'],width:12,height:13,sprite:'lps/components/lz/resources/scrollbar/autoPng/scrollbtn_y_bot_up.sprite.png',spriteoffset:478};LzResourceLibrary.lzscrollbar_ytrack_rsc={ptype:"sr",frames:['lps/components/lz/resources/scrollbar/y_scrolltrack.png','lps/components/lz/resources/scrollbar/y_scrolltrack_dn.png','lps/components/lz/resources/scrollbar/y_scrolltrack_dsbl.png'],width:12,height:1,sprite:'lps/components/lz/resources/scrollbar/y_scrolltrack.sprite.png',spriteoffset:491};LzResourceLibrary.shadowTR={ptype:"sr",frames:['lps/components/lz/resources/floatinglist/pop_shadow_flush_top_rt.png','lps/components/lz/resources/floatinglist/pop_shadow_corner_top_rt.png','lps/components/lz/resources/floatinglist/pop_shadow_oval_top_rt.png'],width:15,height:14,sprite:'lps/components/lz/resources/floatinglist/pop_shadow_flush_top_rt.sprite.png',spriteoffset:492};LzResourceLibrary.shadowMR={ptype:"sr",frames:['lps/components/lz/resources/floatinglist/pop_shadow_mid_rt.png'],width:15.0,height:1.0,spriteoffset:506};LzResourceLibrary.shadowBL={ptype:"sr",frames:['lps/components/lz/resources/floatinglist/autoPng/pop_shadow_bot_lft.png'],width:13.0,height:14.0,spriteoffset:507};LzResourceLibrary.shadowBM={ptype:"sr",frames:['lps/components/lz/resources/floatinglist/pop_shadow_bot_mid.png'],width:1.0,height:14.0,spriteoffset:521};LzResourceLibrary.shadowBR={ptype:"sr",frames:['lps/components/lz/resources/floatinglist/autoPng/pop_shadow_bot_rt.png'],width:15.0,height:14.0,spriteoffset:535};LzResourceLibrary.menucap_lft={ptype:"sr",frames:['lps/components/lz/resources/floatinglist/autoPng/topmenu_lft.png','lps/components/lz/resources/floatinglist/autoPng/botmenu_lft.png'],width:7,height:10,sprite:'lps/components/lz/resources/floatinglist/autoPng/topmenu_lft.sprite.png',spriteoffset:549};LzResourceLibrary.menucap_mid={ptype:"sr",frames:['lps/components/lz/resources/floatinglist/topmenu_mid.png','lps/components/lz/resources/floatinglist/botmenu_mid.png'],width:1,height:11,sprite:'lps/components/lz/resources/floatinglist/topmenu_mid.sprite.png',spriteoffset:559};LzResourceLibrary.menucap_rt={ptype:"sr",frames:['lps/components/lz/resources/floatinglist/autoPng/topmenu_rt.png','lps/components/lz/resources/floatinglist/autoPng/botmenu_rt.png'],width:7,height:10,sprite:'lps/components/lz/resources/floatinglist/autoPng/topmenu_rt.sprite.png',spriteoffset:570};LzResourceLibrary.lzcombobox_lft_rsc={ptype:"sr",frames:['lps/components/lz/resources/combobox/autoPng/combobox_lft_up.png','lps/components/lz/resources/combobox/autoPng/popup_lft_up.png','lps/components/lz/resources/combobox/autoPng/combobox_lft_dsbl.png','lps/components/lz/resources/combobox/autoPng/popup_lft_dsbl.png'],width:2,height:22,sprite:'lps/components/lz/resources/combobox/autoPng/combobox_lft_up.sprite.png',spriteoffset:580};LzResourceLibrary.lzcombobox_mid_rsc={ptype:"sr",frames:['lps/components/lz/resources/combobox/combobox_mid_up.png','lps/components/lz/resources/combobox/popup_mid_up.png','lps/components/lz/resources/combobox/combobox_mid_dsbl.png','lps/components/lz/resources/combobox/popup_mid_dsbl.png'],width:1,height:22,sprite:'lps/components/lz/resources/combobox/combobox_mid_up.sprite.png',spriteoffset:602};LzResourceLibrary.lzcombobox_rgt_rsc={ptype:"sr",frames:['lps/components/lz/resources/combobox/autoPng/popbtn_rt_up.png','lps/components/lz/resources/combobox/autoPng/popbtn_rt_mo.png','lps/components/lz/resources/combobox/autoPng/popbtn_rt_dn.png','lps/components/lz/resources/combobox/autoPng/popbtn_rt_dsbl.png'],width:17,height:22,sprite:'lps/components/lz/resources/combobox/autoPng/popbtn_rt_up.sprite.png',spriteoffset:624};LzResourceLibrary.add_button={ptype:"ar",frames:['resources/classic_add_button.png'],width:32.0,height:32.0,spriteoffset:646};LzResourceLibrary.remove_button={ptype:"ar",frames:['resources/classic_remove_button.png'],width:32.0,height:32.0,spriteoffset:678};LzResourceLibrary.reset_button={ptype:"ar",frames:['resources/classic_reset_button.png'],width:32.0,height:32.0,spriteoffset:710};LzResourceLibrary.__allcss={path:'usr/local/red5/webapps/openlaszlo/my-apps/counter/counter.sprite.png'};;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;{
Class.make("$lzc$class__m7",["$m4",function($0){
this.setAttribute("initcount",lz.Browser.getInitArg("initcount"))
},"initcount",void 0,"$m5",function($0){
this.setAttribute("fontheight",lz.Browser.getInitArg("fontheight"))
},"fontheight",void 0,"$m6",function($0){
this.setAttribute("usepresets",lz.Browser.getInitArg("usepresets"))
},"usepresets",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzCanvas,["displayName","<anonymous extends='canvas'>","__LZCSSTagSelectors",["canvas","view","node","Instance"],"attributes",new LzInheritedHash(LzCanvas.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",accessible:"boolean",align:"string",allowfullscreen:"boolean",appbuilddate:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",compileroptions:"string",contextmenu:"string",cornerradius:"string",cursor:"token",dataloadtimeout:"numberExpression",datapath:"string",datasets:"string",debug:"boolean",defaultdataprovider:"string",defaultplacement:"string",embedfonts:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framerate:"number",framesloadratio:"number",fullscreen:"boolean",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",history:"boolean",httpdataprovider:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",lpsbuild:"string",lpsbuilddate:"string",lpsrelease:"string",lpsversion:"string",mask:"string",mediaerrortimeout:"numberExpression",medialoadtimeout:"numberExpression",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",percentcreated:"number",pixellock:"boolean",placement:"string",playing:"boolean",proxied:"inheritableBoolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",runtime:"string",screenorientation:"boolean",scriptlimits:"css",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",title:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m7.attributes)
}}})($lzc$class__m7)
};canvas=new $lzc$class__m7(null,{__LZproxied:"false",allowfullscreen:true,appbuilddate:"2011-12-03T12:10:00Z",bgcolor:16777215,embedfonts:true,font:"Verdana,Vera,sans-serif",fontheight:new LzOnceExpr("$m5",null),fontsize:11,fontstyle:"plain",height:"100%",initcount:new LzOnceExpr("$m4",null),lpsbuild:"trunk@19126 (19126)",lpsbuilddate:"2011-04-30T08:09:13Z",lpsrelease:"Latest",lpsversion:"5.0.x",runtime:"dhtml",usepresets:new LzOnceExpr("$m6",null),width:"100%"});lz.colors.offwhite=15921906;lz.colors.gray10=1710618;lz.colors.gray20=3355443;lz.colors.gray30=5066061;lz.colors.gray40=6710886;lz.colors.gray50=8355711;lz.colors.gray60=10066329;lz.colors.gray70=11776947;lz.colors.gray80=13421772;lz.colors.gray90=15066597;lz.colors.iceblue1=3298963;lz.colors.iceblue2=5472718;lz.colors.iceblue3=12240085;lz.colors.iceblue4=14017779;lz.colors.iceblue5=15659509;lz.colors.palegreen1=4290113;lz.colors.palegreen2=11785139;lz.colors.palegreen3=12637341;lz.colors.palegreen4=13888170;lz.colors.palegreen5=15725032;lz.colors.gold1=9331721;lz.colors.gold2=13349195;lz.colors.gold3=15126388;lz.colors.gold4=16311446;lz.colors.sand1=13944481;lz.colors.sand2=14276546;lz.colors.sand3=15920859;lz.colors.sand4=15986401;lz.colors.ltpurple1=6575768;lz.colors.ltpurple2=12038353;lz.colors.ltpurple3=13353453;lz.colors.ltpurple4=15329264;lz.colors.grayblue=12501704;lz.colors.graygreen=12635328;lz.colors.graypurple=10460593;lz.colors.ltblue=14540287;lz.colors.ltgreen=14548957;{
Class.make("$lzc$class_basefocusview",["active",void 0,"$lzc$set_active",function($0){
this.setActive($0)
},"target",void 0,"$lzc$set_target",function($0){
this.setTarget($0)
},"duration",void 0,"_animatorcounter",void 0,"ontarget",void 0,"_nexttarget",void 0,"onactive",void 0,"_xydelegate",void 0,"_widthdel",void 0,"_heightdel",void 0,"_delayfadeoutDL",void 0,"_dofadeout",void 0,"_onstopdel",void 0,"reset",function(){
this.setAttribute("x",0);this.setAttribute("y",0);this.setAttribute("width",canvas.width);this.setAttribute("height",canvas.height);this.setTarget(null)
},"setActive",function($0){
this.active=$0;if(this.onactive)this.onactive.sendEvent($0)
},"doFocus",function($0){
this._dofadeout=false;this.bringToFront();if(this.target)this.setTarget(null);this.setAttribute("visibility",this.active?"visible":"hidden");this._nexttarget=$0;if(this.visible){
this._animatorcounter+=1;var $1=null;var $2;var $3;var $4;var $5;if($0["getFocusRect"])$1=$0.getFocusRect();if($1){
$2=$1[0];$3=$1[1];$4=$1[2];$5=$1[3]
}else{
$2=$0.getAttributeRelative("x",canvas);$3=$0.getAttributeRelative("y",canvas);$4=$0.getAttributeRelative("width",canvas);$5=$0.getAttributeRelative("height",canvas)
};var $6=this.animate("x",$2,this.duration);this.animate("y",$3,this.duration);this.animate("width",$4,this.duration);this.animate("height",$5,this.duration);if(this.capabilities["minimize_opacity_changes"]){
this.setAttribute("visibility","visible")
}else{
this.animate("opacity",1,500)
};if(!this._onstopdel)this._onstopdel=new LzDelegate(this,"stopanim");this._onstopdel.register($6,"onstop")
};if(this._animatorcounter<1){
this.setTarget(this._nexttarget);var $1=null;var $2;var $3;var $4;var $5;if($0["getFocusRect"])$1=$0.getFocusRect();if($1){
$2=$1[0];$3=$1[1];$4=$1[2];$5=$1[3]
}else{
$2=$0.getAttributeRelative("x",canvas);$3=$0.getAttributeRelative("y",canvas);$4=$0.getAttributeRelative("width",canvas);$5=$0.getAttributeRelative("height",canvas)
};this.setAttribute("x",$2);this.setAttribute("y",$3);this.setAttribute("width",$4);this.setAttribute("height",$5)
}},"stopanim",function($0){
this._animatorcounter-=1;if(this._animatorcounter<1){
this._dofadeout=true;if(!this._delayfadeoutDL)this._delayfadeoutDL=new LzDelegate(this,"fadeout");lz.Timer.addTimer(this._delayfadeoutDL,1000);this.setTarget(this._nexttarget);this._onstopdel.unregisterAll()
}},"fadeout",function($0){
if(this._dofadeout){
if(this.capabilities["minimize_opacity_changes"]){
this.setAttribute("visibility","hidden")
}else{
this.animate("opacity",0,500)
}};this._delayfadeoutDL.unregisterAll()
},"setTarget",function($0){
this.target=$0;if(!this._xydelegate){
this._xydelegate=new LzDelegate(this,"followXY")
}else{
this._xydelegate.unregisterAll()
};if(!this._widthdel){
this._widthdel=new LzDelegate(this,"followWidth")
}else{
this._widthdel.unregisterAll()
};if(!this._heightdel){
this._heightdel=new LzDelegate(this,"followHeight")
}else{
this._heightdel.unregisterAll()
};if(this.target==null)return;var $1=$0;var $2=0;while($1!=canvas){
this._xydelegate.register($1,"onx");this._xydelegate.register($1,"ony");$1=$1.immediateparent;$2++
};this._widthdel.register($0,"onwidth");this._heightdel.register($0,"onheight");this.followXY(null);this.followWidth(null);this.followHeight(null)
},"followXY",function($0){
var $1=null;if(this.target["getFocusRect"])$1=this.target.getFocusRect();if($1){
this.setAttribute("x",$1[0]);this.setAttribute("y",$1[1])
}else{
this.setAttribute("x",this.target.getAttributeRelative("x",canvas));this.setAttribute("y",this.target.getAttributeRelative("y",canvas))
}},"followWidth",function($0){
var $1=null;if(this.target["getFocusRect"])$1=this.target.getFocusRect();if($1){
this.setAttribute("width",$1[2])
}else{
this.setAttribute("width",this.target.width)
}},"followHeight",function($0){
var $1=null;if(this.target["getFocusRect"])$1=this.target.getFocusRect();if($1){
this.setAttribute("height",$1[3])
}else{
this.setAttribute("height",this.target.height)
}},"$m8",function(){
return lz.Focus
},"$m9",function($0){
this.setActive(lz.Focus.focuswithkey);if($0){
this.doFocus($0)
}else{
this.reset();if(this.active){
this.setActive(false)
}}},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["tagname","basefocusview","__LZCSSTagSelectors",["basefocusview","view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$delegates:["onstop","stopanim",null,"onfocus","$m9","$m8"],_animatorcounter:0,_delayfadeoutDL:null,_dofadeout:false,_heightdel:null,_nexttarget:null,_onstopdel:null,_widthdel:null,_xydelegate:null,active:false,duration:400,initstage:"late",onactive:LzDeclaredEvent,ontarget:LzDeclaredEvent,options:{ignorelayout:true},target:null,visible:false},$lzc$class_basefocusview.attributes)
}}})($lzc$class_basefocusview)
};{
Class.make("$lzc$class__mq",["$ma",function($0){
var $1=-this.classroot.offset;if($1!==this["x"]||!this.inited){
this.setAttribute("x",$1)
}},"$mb",function(){
try{
return [this.classroot,"offset"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$mc",function($0){
var $1=-this.classroot.offset;if($1!==this["y"]||!this.inited){
this.setAttribute("y",$1)
}},"$md",function(){
try{
return [this.classroot,"offset"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","children",[{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,opacity:0.25,resource:"lzfocusbracket_shdw",x:1,y:1},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,resource:"lzfocusbracket_rsrc"},"class":LzView}],"__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__mq.attributes)
}}})($lzc$class__mq)
};{
Class.make("$lzc$class__mr",["$me",function($0){
var $1=this.parent.width-this.width+this.classroot.offset;if($1!==this["x"]||!this.inited){
this.setAttribute("x",$1)
}},"$mf",function(){
try{
return [this.parent,"width",this,"width",this.classroot,"offset"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$mg",function($0){
var $1=-this.classroot.offset;if($1!==this["y"]||!this.inited){
this.setAttribute("y",$1)
}},"$mh",function(){
try{
return [this.classroot,"offset"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","children",[{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,frame:2,opacity:0.25,resource:"lzfocusbracket_shdw",x:1,y:1},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,frame:2,resource:"lzfocusbracket_rsrc"},"class":LzView}],"__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__mr.attributes)
}}})($lzc$class__mr)
};{
Class.make("$lzc$class__ms",["$mi",function($0){
var $1=-this.classroot.offset;if($1!==this["x"]||!this.inited){
this.setAttribute("x",$1)
}},"$mj",function(){
try{
return [this.classroot,"offset"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$mk",function($0){
var $1=this.parent.height-this.height+this.classroot.offset;if($1!==this["y"]||!this.inited){
this.setAttribute("y",$1)
}},"$ml",function(){
try{
return [this.parent,"height",this,"height",this.classroot,"offset"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","children",[{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,frame:3,opacity:0.25,resource:"lzfocusbracket_shdw",x:1,y:1},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,frame:3,resource:"lzfocusbracket_rsrc"},"class":LzView}],"__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__ms.attributes)
}}})($lzc$class__ms)
};{
Class.make("$lzc$class__mt",["$mm",function($0){
var $1=this.parent.width-this.width+this.classroot.offset;if($1!==this["x"]||!this.inited){
this.setAttribute("x",$1)
}},"$mn",function(){
try{
return [this.parent,"width",this,"width",this.classroot,"offset"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$mo",function($0){
var $1=this.parent.height-this.height+this.classroot.offset;if($1!==this["y"]||!this.inited){
this.setAttribute("y",$1)
}},"$mp",function(){
try{
return [this.parent,"height",this,"height",this.classroot,"offset"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","children",[{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,frame:4,opacity:0.25,resource:"lzfocusbracket_shdw",x:1,y:1},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,frame:4,resource:"lzfocusbracket_rsrc"},"class":LzView}],"__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__mt.attributes)
}}})($lzc$class__mt)
};{
Class.make("$lzc$class_focusoverlay",["offset",void 0,"topleft",void 0,"topright",void 0,"bottomleft",void 0,"bottomright",void 0,"doFocus",function($0){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["doFocus"]||this.nextMethod(arguments.callee,"doFocus")).call(this,$0);if(this.visible)this.bounce()
},"bounce",function(){
this.animate("offset",12,this.duration/2);this.animate("offset",5,this.duration)
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basefocusview,["tagname","focusoverlay","children",[{attrs:{$classrootdepth:1,name:"topleft",x:new LzAlwaysExpr("$ma","$mb",null),y:new LzAlwaysExpr("$mc","$md",null)},"class":$lzc$class__mq},{attrs:{$classrootdepth:1,name:"topright",x:new LzAlwaysExpr("$me","$mf",null),y:new LzAlwaysExpr("$mg","$mh",null)},"class":$lzc$class__mr},{attrs:{$classrootdepth:1,name:"bottomleft",x:new LzAlwaysExpr("$mi","$mj",null),y:new LzAlwaysExpr("$mk","$ml",null)},"class":$lzc$class__ms},{attrs:{$classrootdepth:1,name:"bottomright",x:new LzAlwaysExpr("$mm","$mn",null),y:new LzAlwaysExpr("$mo","$mp",null)},"class":$lzc$class__mt}],"__LZCSSTagSelectors",["focusoverlay","basefocusview","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basefocusview.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({offset:5},$lzc$class_focusoverlay.attributes)
}}})($lzc$class_focusoverlay)
};{
Class.make("$lzc$class__componentmanager",["focusclass",void 0,"keyhandlers",void 0,"lastsdown",void 0,"lastedown",void 0,"defaults",void 0,"currentdefault",void 0,"defaultstyle",void 0,"ondefaultstyle",void 0,"init",function(){
var $0=this.focusclass;if(typeof canvas.focusclass!="undefined"){
$0=canvas.focusclass
};if($0!=null){
canvas.__focus=new (lz[$0])(canvas);canvas.__focus.reset()
};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this)
},"_lastkeydown",void 0,"upkeydel",void 0,"$mu",function(){
return lz.Keys
},"dispatchKeyDown",function($0){
var $1=false;if($0==32){
this.lastsdown=null;var $2=lz.Focus.getFocus();if($2 instanceof lz.basecomponent){
$2.doSpaceDown();this.lastsdown=$2
};$1=true
}else if($0==13&&this.currentdefault){
this.lastedown=this.currentdefault;this.currentdefault.doEnterDown();$1=true
};if($1){
if(!this.upkeydel)this.upkeydel=new LzDelegate(this,"dispatchKeyTimer");this._lastkeydown=$0;lz.Timer.addTimer(this.upkeydel,50)
}},"dispatchKeyTimer",function($0){
if(this._lastkeydown==32&&this.lastsdown!=null){
this.lastsdown.doSpaceUp();this.lastsdown=null
}else if(this._lastkeydown==13&&this.currentdefault&&this.currentdefault==this.lastedown){
this.currentdefault.doEnterUp()
}},"findClosestDefault",function($0){
if(!this.defaults){
return null
};var $1=null;var $2=null;var $3=this.defaults;$0=$0||canvas;var $4=lz.ModeManager.getModalView();for(var $5=0;$5<$3.length;$5++){
var $6=$3[$5];if($4&&!$6.childOf($4)){
continue
};var $7=this.findCommonParent($6,$0);if($7&&(!$1||$7.nodeLevel>$1.nodeLevel)){
$1=$7;$2=$6
}};return $2
},"findCommonParent",function($0,$1){
while($0.nodeLevel>$1.nodeLevel){
$0=$0.immediateparent;if(!$0.visible)return null
};while($1.nodeLevel>$0.nodeLevel){
$1=$1.immediateparent;if(!$1.visible)return null
};while($0!=$1){
$0=$0.immediateparent;$1=$1.immediateparent;if(!$0.visible||!$1.visible)return null
};return $0
},"makeDefault",function($0){
if(!this.defaults)this.defaults=[];this.defaults.push($0);this.checkDefault(lz.Focus.getFocus())
},"unmakeDefault",function($0){
if(!this.defaults)return;for(var $1=0;$1<this.defaults.length;$1++){
if(this.defaults[$1]==$0){
this.defaults.splice($1,1);this.checkDefault(lz.Focus.getFocus());return
}}},"$mv",function(){
return lz.Focus
},"checkDefault",function($0){
if(!($0 instanceof lz.basecomponent)||!$0.doesenter){
if($0 instanceof lz.inputtext&&$0.multiline){
$0=null
}else{
$0=this.findClosestDefault($0)
}};if($0==this.currentdefault)return;if(this.currentdefault){
this.currentdefault.setAttribute("hasdefault",false)
};this.currentdefault=$0;if($0){
$0.setAttribute("hasdefault",true)
}},"$mw",function(){
return lz.ModeManager
},"$mx",function($0){
switch(arguments.length){
case 0:
$0=null;

};if(lz.Focus.getFocus()==null){
this.checkDefault(null)
}},"setDefaultStyle",function($0){
this.defaultstyle=$0;if(this.ondefaultstyle)this.ondefaultstyle.sendEvent($0)
},"getDefaultStyle",function(){
if(this.defaultstyle==null){
this.defaultstyle=new (lz.style)(canvas,{isdefault:true})
};return this.defaultstyle
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzNode,["tagname","_componentmanager","__LZCSSTagSelectors",["_componentmanager","node","Instance"],"attributes",new LzInheritedHash(LzNode.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",focusclass:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",styleclass:"string",subnodes:"string",transition:"string","with":"string"}},$delegates:["onkeydown","dispatchKeyDown","$mu","onfocus","checkDefault","$mv","onmode","$mx","$mw"],_lastkeydown:0,currentdefault:null,defaults:null,defaultstyle:null,focusclass:"focusoverlay",keyhandlers:null,lastedown:null,lastsdown:null,ondefaultstyle:LzDeclaredEvent,upkeydel:null},$lzc$class__componentmanager.attributes)
}}})($lzc$class__componentmanager)
};{
Class.make("$lzc$class_style",["isstyle",void 0,"$my",function($0){
this.setAttribute("canvascolor",LzColorUtils.convertColor("null"))
},"canvascolor",void 0,"$lzc$set_canvascolor",function($0){
this.setCanvasColor($0)
},"$mz",function($0){
this.setAttribute("textcolor",LzColorUtils.convertColor("gray10"))
},"textcolor",void 0,"$lzc$set_textcolor",function($0){
this.setStyleAttr($0,"textcolor")
},"$m10",function($0){
this.setAttribute("textfieldcolor",LzColorUtils.convertColor("white"))
},"textfieldcolor",void 0,"$lzc$set_textfieldcolor",function($0){
this.setStyleAttr($0,"textfieldcolor")
},"$m11",function($0){
this.setAttribute("texthilitecolor",LzColorUtils.convertColor("iceblue1"))
},"texthilitecolor",void 0,"$lzc$set_texthilitecolor",function($0){
this.setStyleAttr($0,"texthilitecolor")
},"$m12",function($0){
this.setAttribute("textselectedcolor",LzColorUtils.convertColor("black"))
},"textselectedcolor",void 0,"$lzc$set_textselectedcolor",function($0){
this.setStyleAttr($0,"textselectedcolor")
},"$m13",function($0){
this.setAttribute("textdisabledcolor",LzColorUtils.convertColor("gray60"))
},"textdisabledcolor",void 0,"$lzc$set_textdisabledcolor",function($0){
this.setStyleAttr($0,"textdisabledcolor")
},"$m14",function($0){
this.setAttribute("basecolor",LzColorUtils.convertColor("offwhite"))
},"basecolor",void 0,"$lzc$set_basecolor",function($0){
this.setStyleAttr($0,"basecolor")
},"$m15",function($0){
this.setAttribute("bgcolor",LzColorUtils.convertColor("white"))
},"bgcolor",void 0,"$lzc$set_bgcolor",function($0){
this.setStyleAttr($0,"bgcolor")
},"$m16",function($0){
this.setAttribute("hilitecolor",LzColorUtils.convertColor("iceblue4"))
},"hilitecolor",void 0,"$lzc$set_hilitecolor",function($0){
this.setStyleAttr($0,"hilitecolor")
},"$m17",function($0){
this.setAttribute("selectedcolor",LzColorUtils.convertColor("iceblue3"))
},"selectedcolor",void 0,"$lzc$set_selectedcolor",function($0){
this.setStyleAttr($0,"selectedcolor")
},"$m18",function($0){
this.setAttribute("disabledcolor",LzColorUtils.convertColor("gray30"))
},"disabledcolor",void 0,"$lzc$set_disabledcolor",function($0){
this.setStyleAttr($0,"disabledcolor")
},"$m19",function($0){
this.setAttribute("bordercolor",LzColorUtils.convertColor("gray40"))
},"bordercolor",void 0,"$lzc$set_bordercolor",function($0){
this.setStyleAttr($0,"bordercolor")
},"$m1a",function($0){
this.setAttribute("bordersize",1)
},"bordersize",void 0,"$lzc$set_bordersize",function($0){
this.setStyleAttr($0,"bordersize")
},"$m1b",function($0){
var $1=this.textfieldcolor;if($1!==this["menuitembgcolor"]||!this.inited){
this.setAttribute("menuitembgcolor",$1)
}},"$m1c",function(){
try{
return [this,"textfieldcolor"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"menuitembgcolor",void 0,"isdefault",void 0,"$lzc$set_isdefault",function($0){
this._setdefault($0)
},"onisdefault",void 0,"_setdefault",function($0){
this.isdefault=$0;if(this.isdefault){
lz._componentmanager.service.setDefaultStyle(this);if(this["canvascolor"]!=null){
canvas.setAttribute("bgcolor",this.canvascolor)
}};if(this.onisdefault)this.onisdefault.sendEvent(this)
},"onstylechanged",void 0,"setStyleAttr",function($0,$1){
this[$1]=$0;if(this["on"+$1])this["on"+$1].sendEvent($1);if(this.onstylechanged)this.onstylechanged.sendEvent(this)
},"setCanvasColor",function($0){
if(this.isdefault&&$0!=null){
canvas.setAttribute("bgcolor",$0)
};this.canvascolor=$0;if(this.onstylechanged)this.onstylechanged.sendEvent(this)
},"extend",function($0){
var $1=new (lz.style)();$1.canvascolor=this.canvascolor;$1.textcolor=this.textcolor;$1.textfieldcolor=this.textfieldcolor;$1.texthilitecolor=this.texthilitecolor;$1.textselectedcolor=this.textselectedcolor;$1.textdisabledcolor=this.textdisabledcolor;$1.basecolor=this.basecolor;$1.bgcolor=this.bgcolor;$1.hilitecolor=this.hilitecolor;$1.selectedcolor=this.selectedcolor;$1.disabledcolor=this.disabledcolor;$1.bordercolor=this.bordercolor;$1.bordersize=this.bordersize;$1.menuitembgcolor=this.menuitembgcolor;$1.isdefault=this.isdefault;for(var $2 in $0){
$1[$2]=$0[$2]
};new LzDelegate($1,"_forwardstylechanged",this,"onstylechanged");return $1
},"_forwardstylechanged",function($0){
if(this.onstylechanged)this.onstylechanged.sendEvent(this)
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzNode,["tagname","style","__LZCSSTagSelectors",["style","node","Instance"],"attributes",new LzInheritedHash(LzNode.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{basecolor:"color",bgcolor:"color",bordercolor:"color",bordersize:"number",canvascolor:"color",classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",disabledcolor:"color",hilitecolor:"color",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isdefault:"boolean",isinited:"boolean",menuitembgcolor:"color",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",selectedcolor:"color",styleclass:"string",subnodes:"string",textcolor:"color",textdisabledcolor:"color",textfieldcolor:"color",texthilitecolor:"color",textselectedcolor:"color",transition:"string","with":"string"}},basecolor:new LzOnceExpr("$m14",null),bgcolor:new LzOnceExpr("$m15",null),bordercolor:new LzOnceExpr("$m19",null),bordersize:new LzOnceExpr("$m1a",null),canvascolor:new LzOnceExpr("$my",null),disabledcolor:new LzOnceExpr("$m18",null),hilitecolor:new LzOnceExpr("$m16",null),isdefault:false,isstyle:true,menuitembgcolor:new LzAlwaysExpr("$m1b","$m1c",null),onisdefault:LzDeclaredEvent,onstylechanged:LzDeclaredEvent,selectedcolor:new LzOnceExpr("$m17",null),textcolor:new LzOnceExpr("$mz",null),textdisabledcolor:new LzOnceExpr("$m13",null),textfieldcolor:new LzOnceExpr("$m10",null),texthilitecolor:new LzOnceExpr("$m11",null),textselectedcolor:new LzOnceExpr("$m12",null)},$lzc$class_style.attributes)
}}})($lzc$class_style)
};canvas.LzInstantiateView({"class":lz.script,attrs:{script:function(){
lz._componentmanager.service=new (lz._componentmanager)(canvas,null,null,true)
}}},1);{
Class.make("$lzc$class_statictext",["$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzText,["tagname","statictext","__LZCSSTagSelectors",["statictext","text","view","node","Instance"],"attributes",new LzInheritedHash(LzText.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",antiAliasType:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",cdata:"cdata",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",direction:"string",embedfonts:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",gridFit:"string",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",hscroll:"number",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",letterspacing:"number",lineheight:"number",loadratio:"number",mask:"string",maxhscroll:"number",maxlength:"numberExpression",maxscroll:"number",multiline:"boolean",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pattern:"string",pixellock:"boolean",placement:"string",playing:"boolean",resize:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",scroll:"number",scrollevents:"boolean",scrollheight:"number",scrollwidth:"number",selectable:"boolean",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",sharpness:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",textalign:"string",textdecoration:"string",textindent:"number",thickness:"number",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",xscroll:"number",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression",yscroll:"number"}}},$lzc$class_statictext.attributes)
}}})($lzc$class_statictext)
};{
Class.make("$lzc$class_basecomponent",["enabled",void 0,"$lzc$set_focusable",function($0){
this._setFocusable($0)
},"_focusable",void 0,"text",void 0,"doesenter",void 0,"$lzc$set_doesenter",function($0){
this._setDoesEnter($0)
},"$m1d",function($0){
var $1=this.enabled&&(this._parentcomponent?this._parentcomponent._enabled:true);if($1!==this["_enabled"]||!this.inited){
this.setAttribute("_enabled",$1)
}},"$m1e",function(){
try{
return [this,"enabled",this,"_parentcomponent",this._parentcomponent,"_enabled"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"_enabled",void 0,"$lzc$set__enabled",function($0){
this._setEnabled($0)
},"_parentcomponent",void 0,"_initcomplete",void 0,"isdefault",void 0,"$lzc$set_isdefault",function($0){
this._setIsDefault($0)
},"onisdefault",void 0,"hasdefault",void 0,"_setEnabled",function($0){
this._enabled=$0;var $1=this._enabled&&this._focusable;if($1!=this.focusable){
this.focusable=$1;if(this.onfocusable.ready)this.onfocusable.sendEvent()
};if(this._initcomplete)this._showEnabled();if(this.on_enabled.ready)this.on_enabled.sendEvent()
},"_setFocusable",function($0){
this._focusable=$0;if(this.enabled){
this.focusable=this._focusable;if(this.onfocusable.ready)this.onfocusable.sendEvent()
}else{
this.focusable=false
}},"construct",function($0,$1){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["construct"]||this.nextMethod(arguments.callee,"construct")).call(this,$0,$1);var $2=this.immediateparent;while($2!=canvas){
if(lz.basecomponent["$lzsc$isa"]?lz.basecomponent.$lzsc$isa($2):$2 instanceof lz.basecomponent){
this._parentcomponent=$2;break
};$2=$2.immediateparent
}},"init",function(){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this);this._initcomplete=true;this._mousedownDel=new LzDelegate(this,"_doMousedown",this,"onmousedown");if(this.styleable){
this._usestyle()
};if(!this["_enabled"])this._showEnabled()
},"_doMousedown",function($0){},"doSpaceDown",function(){
return false
},"doSpaceUp",function(){
return false
},"doEnterDown",function(){
return false
},"doEnterUp",function(){
return false
},"_setIsDefault",function($0){
this.isdefault=this["isdefault"]==true;if(this.isdefault==$0)return;if($0){
lz._componentmanager.service.makeDefault(this)
}else{
lz._componentmanager.service.unmakeDefault(this)
};this.isdefault=$0;if(this.onisdefault.ready){
this.onisdefault.sendEvent($0)
}},"_setDoesEnter",function($0){
this.doesenter=$0;if(lz.Focus.getFocus()==this){
lz._componentmanager.service.checkDefault(this)
}},"updateDefault",function(){
lz._componentmanager.service.checkDefault(lz.Focus.getFocus())
},"$m1f",function($0){
this.setAttribute("style",null)
},"style",void 0,"$lzc$set_style",function($0){
this.styleable?this.setStyle($0):(this.style=null)
},"styleable",void 0,"_style",void 0,"onstyle",void 0,"_styledel",void 0,"_otherstyledel",void 0,"setStyle",function($0){
if(!this.styleable)return;if($0!=null&&!$0["isstyle"]){
var $1=this._style;if(!$1){
if(this._parentcomponent){
$1=this._parentcomponent.style
}else $1=lz._componentmanager.service.getDefaultStyle()
};$0=$1.extend($0)
};this._style=$0;if($0==null){
if(!this._otherstyledel){
this._otherstyledel=new LzDelegate(this,"_setstyle")
}else{
this._otherstyledel.unregisterAll()
};if(this._parentcomponent&&this._parentcomponent.styleable){
this._otherstyledel.register(this._parentcomponent,"onstyle");$0=this._parentcomponent.style
}else{
this._otherstyledel.register(lz._componentmanager.service,"ondefaultstyle");$0=lz._componentmanager.service.getDefaultStyle()
}}else if(this._otherstyledel){
this._otherstyledel.unregisterAll();this._otherstyledel=null
};this._setstyle($0)
},"_usestyle",function($0){
switch(arguments.length){
case 0:
$0=null;

};if(this._initcomplete&&this["style"]&&this.style.isinited){
this._applystyle(this.style)
}},"_setstyle",function($0){
if(!this._styledel){
this._styledel=new LzDelegate(this,"_usestyle")
}else{
this._styledel.unregisterAll()
};if($0){
this._styledel.register($0,"onstylechanged")
};this.style=$0;this._usestyle();if(this.onstyle.ready)this.onstyle.sendEvent(this.style)
},"_applystyle",function($0){},"setTint",function($0,$1,$2){
switch(arguments.length){
case 2:
$2=0;

};if($0.capabilities.colortransform){
if($1!=""&&$1!=null){
var $3=$1;var $4=$3>>16&255;var $5=$3>>8&255;var $6=$3&255;$4+=51;$5+=51;$6+=51;$4=$4/255;$5=$5/255;$6=$6/255;$0.setAttribute("colortransform",{redMultiplier:$4,greenMultiplier:$5,blueMultiplier:$6,redOffset:$2,greenOffset:$2,blueOffset:$2})
}}},"on_enabled",void 0,"_showEnabled",function(){},"acceptValue",function($0,$1){
switch(arguments.length){
case 1:
$1=null;

};this.setAttribute("text",$0)
},"presentValue",function($0){
switch(arguments.length){
case 0:
$0=null;

};return this.text
},"$lzc$presentValue_dependencies",function($0,$1,$2){
switch(arguments.length){
case 2:
$2=null;

};return [this,"text"]
},"applyData",function($0){
this.acceptValue($0)
},"updateData",function(){
return this.presentValue()
},"destroy",function(){
this.styleable=false;this._initcomplete=false;if(this["isdefault"]&&this.isdefault){
lz._componentmanager.service.unmakeDefault(this)
};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["destroy"]||this.nextMethod(arguments.callee,"destroy")).call(this)
},"toString",function(){
var $0="";var $1="";var $2="";if(this["id"]!=null)$0="  id="+this.id;if(this["name"]!=null)$1=' named "'+this.name+'"';if(this["text"]&&this.text!="")$2="  text="+this.text;return this.constructor.tagname+$1+$0+$2
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["tagname","basecomponent","__LZCSSTagSelectors",["basecomponent","view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{_focusable:"boolean",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",doesenter:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},_enabled:new LzAlwaysExpr("$m1d","$m1e",null),_focusable:true,_initcomplete:false,_otherstyledel:null,_parentcomponent:null,_style:null,_styledel:null,doesenter:false,enabled:true,focusable:true,hasdefault:false,on_enabled:LzDeclaredEvent,onfocusable:LzDeclaredEvent,onisdefault:LzDeclaredEvent,onstyle:LzDeclaredEvent,style:new LzOnceExpr("$m1f",null),styleable:true,text:""},$lzc$class_basecomponent.attributes)
}}})($lzc$class_basecomponent)
};Mixin.make("DrawviewShared",["$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
},"lineTo",function($0,$1){},"moveTo",function($0,$1){},"quadraticCurveTo",function($0,$1,$2,$3){},"__radtodegfactor",180/Math.PI,"arc",function($0,$1,$2,$3,$4,$5){
switch(arguments.length){
case 5:
$5=false;

};if($3==null||$4==null)return;$3=-$3;$4=-$4;var $6;if($5==false&&$4-$3>=2*Math.PI||$5==true&&$3-$4>=2*Math.PI){
$6=360
}else if($3==$4||$2==0){
$6=0
}else{
var $7=$3*this.__radtodegfactor;var $8=$4*this.__radtodegfactor;if($5){
if($8<$7){
$6=-($7-$8-360)
}else{
$6=$8-$7+360
}}else{
if($8<$7){
$6=-($7-$8+360)
}else{
$6=$8-$7-360
}};while($6<-360){
$6+=360
};while($6>360){
$6-=360
}};var $9=$0+$2*Math.cos($3);var $a=$1+$2*Math.sin(2*Math.PI-$3);this.moveTo($9,$a);this._drawArc($0,$1,$2,$6,$3*this.__radtodegfactor)
},"rect",function($0,$1,$2,$3,$4,$5,$6,$7){
switch(arguments.length){
case 4:
$4=0;
case 5:
$5=null;
case 6:
$6=null;
case 7:
$7=null;

};LzKernelUtils.rect(this,$0,$1,$2,$3,$4,$5,$6,$7)
},"oval",function($0,$1,$2,$3){
switch(arguments.length){
case 3:
$3=NaN;

};if(isNaN($3)){
$3=$2
};var $4=$2<10&&$3<10?5:8;var $5=Math.PI/($4/2);var $6=$2/Math.cos($5/2);var $7=$3/Math.cos($5/2);this.moveTo($0+$2,$1);var $8=0,$9,$a,$b,$c,$d;for(var $e=0;$e<$4;$e++){
$8+=$5;$9=$8-$5/2;$c=$0+Math.cos($9)*$6;$d=$1+Math.sin($9)*$7;$a=$0+Math.cos($8)*$2;$b=$1+Math.sin($8)*$3;this.quadraticCurveTo($c,$d,$a,$b)
};return {x:$a,y:$b}},"_drawArc",function($0,$1,$2,$3,$4,$5){
switch(arguments.length){
case 5:
$5=NaN;

};if(isNaN($5)){
$5=$2
};if(Math.abs($3)>360){
$3=360
};var $6=Math.ceil(Math.abs($3)/45);var $7,$8;if($6>0){
var $9=$3/$6;var $a=-($9/180)*Math.PI;var $b=-($4/180)*Math.PI;var $c,$d,$e;for(var $f=0;$f<$6;$f++){
$b+=$a;$c=$b-$a/2;$7=$0+Math.cos($b)*$2;$8=$1+Math.sin($b)*$5;$d=$0+Math.cos($c)*($2/Math.cos($a/2));$e=$1+Math.sin($c)*($5/Math.cos($a/2));this.quadraticCurveTo($d,$e,$7,$8)
}};return {x:$7,y:$8}},"distance",function($0,$1){
var $2=$1.x-$0.x;var $3=$1.y-$0.y;return Math.sqrt($2*$2+$3*$3)
},"intersection",function($0,$1,$2,$3){
var $4=($3.x-$2.x)*($0.y-$2.y)-($3.y-$2.y)*($0.x-$2.x);var $5=($3.y-$2.y)*($1.x-$0.x)-($3.x-$2.x)*($1.y-$0.y);if($5==0){
if($4==0){
return -1
}else{
return null
}};$4/=$5;return {x:$0.x+($1.x-$0.x)*$4,y:$0.y+($1.y-$0.y)*$4}},"midpoint",function($0,$1){
return {x:($0.x+$1.x)/2,y:($0.y+$1.y)/2}},"globalAlpha",1,"lineWidth",1,"lineCap","butt","lineJoin","miter","miterLimit",10,"strokeStyle","#000000","fillStyle","#000000"]);Class.make("$lzc$class_drawview",["__globalAlpha",null,"__lineWidth",null,"__lineCap",null,"__lineJoin",null,"__miterLimit",null,"__strokeStyle",null,"__fillStyle",null,"__pathdrawn",-1,"__lastoffset",-1,"__dirty",false,"__pathisopen",false,"_lz",lz,"__contextstates",null,"init",function(){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this);this.createContext()
},"construct",function($0,$1){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["construct"]||this.nextMethod(arguments.callee,"construct")).call(this,$0,$1);this.__contextstates=[]
},"$lzc$set_context",function($0){
this.beginPath();if(this.context){
this.__lineWidth=null;this.__lineCap=null;this.__lineJoin=null;this.__miterLimit=null;this.__fillStyle=null;this.__strokeStyle=null;this.__globalAlpha=null
};if($0["fillText"]&&this._lz.embed.browser.browser!=="iPad"){
this.capabilities["2dcanvastext"]=true
};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzc$set_context"]||this.nextMethod(arguments.callee,"$lzc$set_context")).call(this,$0)
},"__drawImageCnt",0,"getImage",function($0){
var $1=this._lz.drawview.images;if(!$1[$0]){
var $2=$0;if($0.indexOf("http:")!=0&&$0.indexOf("https:")!=0){
$2=this.sprite.getResourceUrls($0)[0]
};var $3=new Image();$3.src=$2;$1[$0]=$3;if($2!=$0){
$1[$2]=$3
}};return $1[$0]
},"drawImage",function(image,x,y,w,h,r){
switch(arguments.length){
case 1:
x=0;
case 2:
y=0;
case 3:
w=null;
case 4:
h=null;
case 5:
r=0;

};if(image==null){
image=this.sprite.__LZcanvas
}else if(typeof image=="string"){
image=this.getImage(image)
};if(!image)return;this.__dirty=true;if(w==null)w=image.width;if(h==null)h=image.height;var $0=image.nodeName;var $1=image&&image.nodeType==1&&$0=="IMG"||$0=="CANVAS";var $2=image&&image.complete||$0=="CANVAS";if(!$1){

}else if(!$2){
var fname="__drawImage"+this.__drawImageCnt++;this[fname]=function(){
this._lz.embed.removeEventHandler(image,"load",this,fname);delete this[fname];this.drawImage(image,x,y,w,h,r)
};this._lz.embed.attachEventHandler(image,"load",this,fname)
}else{
this.__updateFillStyle();var $3=x||y||r;if($3){
this.context.save();if(x||y){
this.context.translate(x,y)
};if(r){
this.context.rotate(r)
}};if(w==null)w=image.width;if(h==null)h=image.height;this.context.drawImage(image,0,0,w,h);if($3){
this.context.restore()
}}},"fillText",function($0,$1,$2,$3){
switch(arguments.length){
case 3:
$3=null;

};if(!this.capabilities["2dcanvastext"]){
return
};this.__styleText();this.__dirty=true;this.__updateFillStyle();if($3){
this.context.fillText($0,$1,$2,$3)
}else{
this.context.fillText($0,$1,$2)
}},"strokeText",function($0,$1,$2,$3){
switch(arguments.length){
case 3:
$3=null;

};if(!this.capabilities["2dcanvastext"]){
return
};this.__styleText();this.__dirty=true;this.__updateLineStyle();if($3){
this.context.strokeText($0,$1,$2,$3)
}else{
this.context.strokeText($0,$1,$2)
}},"measureText",function($0){
if(!this.capabilities["2dcanvastext"]){
return
};this.__styleText();return this.context.measureText($0)
},"__styleText",function(){
var $0=this.font||canvas.font;var $1=(this.fontsize||canvas.fontsize)+"px";var $2=this.fontstyle||"plain";if($2=="plain"){
var $3="normal";var $4="normal"
}else if($2=="bold"){
var $3="bold";var $4="normal"
}else if($2=="italic"){
var $3="normal";var $4="italic"
}else if($2=="bold italic"||$2=="bolditalic"){
var $3="bold";var $4="italic"
};var $5=$4+" "+$3+" "+$1+" "+$0;this.context.font=$5
},"__checkContext",function(){},"beginPath",function(){
this.__path=[[1,0,0]];this.__pathisopen=true;this.__pathdrawn=-1
},"closePath",function(){
if(this.__pathisopen){
this.__path.push([0])
};this.__pathisopen=false
},"moveTo",function($0,$1){
if(this.__pathisopen){
this.__path.push([1,$0,$1])
}},"lineTo",function($0,$1){
if(this.__pathisopen){
this.__path.push([2,$0,$1])
}},"quadraticCurveTo",function($0,$1,$2,$3){
if(this.__pathisopen){
this.__path.push([3,$0,$1,$2,$3])
}},"bezierCurveTo",function($0,$1,$2,$3,$4,$5){
if(this.__pathisopen){
this.__path.push([4,$0,$1,$2,$3,$4,$5])
}},"arc",function($0,$1,$2,$3,$4,$5){
if(this.__pathisopen){
var $6=$0+$2*Math.cos(-$3);var $7=$1+$2*Math.sin(2*Math.PI+$3);this.__path.push([1,$6,$7]);this.__path.push([5,$0,$1,$2,$3,$4,$5])
}},"fill",function(){
this.__updateFillStyle();this.__playPath(0);this.context.fill()
},"__updateFillStyle",function(){
if(this.__globalAlpha!=this.globalAlpha){
this.__globalAlpha=this.context.globalAlpha=this.globalAlpha
};if(this.__fillStyle!=this.fillStyle){
if(this.fillStyle instanceof this._lz.CanvasGradient){
this.fillStyle.__applyFillTo(this.context)
}else{
this.context.fillStyle=this._lz.ColorUtils.torgb(this.fillStyle)
};this.__fillStyle=this.fillStyle
}},"__strokeOffset",0,"__updateLineStyle",function(){
if(this.__globalAlpha!=this.globalAlpha){
this.__globalAlpha=this.context.globalAlpha=this.globalAlpha
};if(this.__lineWidth!=this.lineWidth){
this.__lineWidth=this.context.lineWidth=this.lineWidth;if(this.aliaslines){
this.__strokeOffset=this.lineWidth%2?0.5:0
}};if(this.__lineCap!=this.lineCap){
this.__lineCap=this.context.lineCap=this.lineCap
};if(this.__lineJoin!=this.lineJoin){
this.__lineJoin=this.context.lineJoin=this.lineJoin
};if(this.__miterLimit!=this.miterLimit){
this.__miterLimit=this.context.miterLimit=this.miterLimit
};if(this.__strokeStyle!=this.strokeStyle){
if(this.strokeStyle instanceof this._lz.CanvasGradient){
this.strokeStyle.__applyStrokeTo(this.context)
}else{
this.context.strokeStyle=this._lz.ColorUtils.torgb(this.strokeStyle)
};this.__strokeStyle=this.strokeStyle
}},"__playPath",function($0){
var $1=this.__path;var $2=$1.length;if($2==0)return;if(this.__pathdrawn===$2&&this.__lastoffset===$0){
return
};this.__pathdrawn=$2;this.__lastoffset=$0;if($0){
this.context.translate($0,$0)
};this.__dirty=true;this.context.beginPath();for(var $3=0;$3<$2;$3+=1){
var $4=$1[$3];switch($4[0]){
case 0:
this.context.closePath();break;
case 1:
this.context.moveTo($4[1],$4[2]);break;
case 2:
this.context.lineTo($4[1],$4[2]);break;
case 3:
this.context.quadraticCurveTo($4[1],$4[2],$4[3],$4[4]);break;
case 4:
this.context.bezierCurveTo($4[1],$4[2],$4[3],$4[4],$4[5],$4[6]);break;
case 5:
this.context.arc($4[1],$4[2],$4[3],$4[4],$4[5],$4[6]);break;

}};if($0){
this.context.translate(-$0,-$0)
}},"clipPath",function(){
this.__playPath(0);this.context.clip()
},"clipButton",function(){},"stroke",function(){
this.__updateLineStyle();this.__playPath(this.__strokeOffset);this.context.stroke()
},"clear",function(){
if(this["__dirty"]==false)return;this.__pathdrawn=-1;this.__dirty=false;this.context.clearRect(0,0,this.width,this.height)
},"clearMask",function(){},"createLinearGradient",function($0,$1,$2,$3){
return new (this._lz.CanvasGradient)(this,[$0,$1,$2,$3],false)
},"createRadialGradient",function($0,$1,$2,$3,$4,$5){
return new (this._lz.CanvasGradient)(this,[$0,$1,$2,$3,$4,$5],true)
},"rotate",function($0){
this.context.rotate($0)
},"translate",function($0,$1){
this.context.translate($0,$1)
},"scale",function($0,$1){
this.context.scale($0,$1)
},"save",function(){
this.__contextstates.push({fillStyle:this.fillStyle,strokeStyle:this.strokeStyle,globalAlpha:this.globalAlpha,lineWidth:this.lineWidth,lineCap:this.lineCap,lineJoin:this.lineJoin,miterLimit:this.miterLimit});this.context.save()
},"restore",function(){
var $0=this.__contextstates.pop();if($0){
for(var $1 in $0){
this[$1]=this["__"+$1]=$0[$1]
}};this.context.restore()
},"fillRect",function($0,$1,$2,$3){
this.__dirty=true;this.__updateFillStyle();this.context.fillRect($0,$1,$2,$3)
},"clearRect",function($0,$1,$2,$3){
this.context.clearRect($0,$1,$2,$3)
},"strokeRect",function($0,$1,$2,$3){
this.__dirty=true;this.__updateLineStyle();this.context.strokeRect($0,$1,$2,$3)
}],[DrawviewShared,LzView],["tagname","drawview","attributes",new LzInheritedHash(LzView.attributes),"images",{}]);lz[$lzc$class_drawview.tagname]=$lzc$class_drawview;Class.make("LzCanvasGradient",["__context",null,"__g",null,"$lzsc$initialize",function($0,$1,$2){
this.__context=$0;var $3=$0.context;if($2){
this.__g=$3.createRadialGradient($1[0],$1[1],$1[2],$1[3],$1[4],$1[5])
}else{
this.__g=$3.createLinearGradient($1[0],$1[1],$1[2],$1[3])
}},"addColorStop",function($0,$1){
var $2=lz.ColorUtils.torgb($1);var $3=this.__context.globalAlpha;if($3!=null&&$3!=1){
$2=this.torgba($2,$3)
};this.__g.addColorStop($0,$2)
},"torgba",function($0,$1){
if($0.indexOf("rgba")==-1){
var $2=$0.substring(4,$0.length-1).split(",");$2.push($1);return "rgba("+$2.join(",")+")"
}else{
return $0
}},"__applyFillTo",function($0){
$0.fillStyle=this.__g
},"__applyStrokeTo",function($0){
$0.strokeStyle=this.__g
}]);lz.CanvasGradient=LzCanvasGradient;{
Class.make("$lzc$class_basevaluecomponent",["value",void 0,"type",void 0,"getValue",function(){
return this.value==null?this.text:this.value
},"$lzc$getValue_dependencies",function($0,$1){
return [this,"value",this,"text"]
},"acceptValue",function($0,$1){
switch(arguments.length){
case 1:
$1=null;

};if($1==null)$1=this.type;(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["acceptValue"]||this.nextMethod(arguments.callee,"acceptValue")).call(this,$0,$1);this.acceptAttribute("value",$1,$0)
},"presentValue",function($0){
switch(arguments.length){
case 0:
$0=null;

};if($0==null)$0=this.type;return lz.Type.presentTypeValue($0,this.getValue(),this,"value")
},"$lzc$presentValue_dependencies",function($0,$1,$2){
switch(arguments.length){
case 2:
$2=null;

};return [this,"type"].concat(this.$lzc$getValue_dependencies($0,$1))
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basecomponent,["tagname","basevaluecomponent","__LZCSSTagSelectors",["basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basecomponent.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{_focusable:"boolean",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",doesenter:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",tintcolor:"string",totalframes:"number",transition:"string",type:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},type:"expression",value:null},$lzc$class_basevaluecomponent.attributes)
}}})($lzc$class_basevaluecomponent)
};{
Class.make("$lzc$class_baseformitem",["_parentform",void 0,"submitname",void 0,"$m1g",function($0){
var $1=this.enabled;if($1!==this["submit"]||!this.inited){
this.setAttribute("submit",$1)
}},"$m1h",function(){
try{
return [this,"enabled"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"submit",void 0,"changed",void 0,"$lzc$set_changed",function($0){
this.setChanged($0)
},"$lzc$set_value",function($0){
this.setValue($0,false)
},"onchanged",void 0,"onvalue",void 0,"rollbackvalue",void 0,"ignoreform",void 0,"init",function(){
if(this.submitname=="")this.submitname=this.name;if(this.submitname==""){};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this);var $0=this.findForm();if($0!=null){
$0.addFormItem(this);this._parentform=$0
}},"destroy",function(){
if(this._parentform)this._parentform.removeFormItem(this);(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["destroy"]||this.nextMethod(arguments.callee,"destroy")).call(this)
},"setChanged",function($0,$1){
switch(arguments.length){
case 1:
$1=null;

};if(!this._initcomplete){
this.changed=false;return
};var $2=this.changed;this.changed=$0;if(this.changed!=$2){
if(this.onchanged)this.onchanged.sendEvent(this.changed)
};if(!$1&&this.changed&&!this.ignoreform){
if(this["_parentform"]&&this._parentform["changed"]!=undefined&&!this._parentform.changed){
this._parentform.setChanged($0,false)
}};if(!$1&&!this.changed&&!this.ignoreform){
if(this["_parentform"]&&this._parentform["changed"]!=undefined&&this._parentform.changed){
this._parentform.setChanged($0,true)
}}},"rollback",function(){
if(this.rollbackvalue!=this["value"]){
this.setAttribute("value",this.rollbackvalue)
};this.setAttribute("changed",false)
},"commit",function(){
this.rollbackvalue=this.value;this.setAttribute("changed",false)
},"setValue",function($0,$1){
switch(arguments.length){
case 1:
$1=null;

};var $2=this.value!=$0;this.value=$0;if($1||!this._initcomplete){
this.rollbackvalue=$0
};this.setChanged($2&&!$1&&this.rollbackvalue!=$0);if(this["onvalue"])this.onvalue.sendEvent($0)
},"acceptValue",function($0,$1){
switch(arguments.length){
case 1:
$1=null;

};if($1==null)$1=this.type;this.setValue(lz.Type.acceptTypeValue($1,$0,this,"value"),true)
},"findForm",function(){
if(this._parentform!=null){
return this._parentform
}else{
var $0=this.immediateparent;var $1=null;while($0!=canvas){
if($0["formdata"]){
$1=$0;break
};$0=$0.immediateparent
};return $1
}},"toXML",function($0){
var $1=this.value;if($0){
if(typeof $1=="boolean")$1=$1-0
};return lz.Browser.xmlEscape(this.submitname)+'="'+lz.Browser.xmlEscape($1)+'"'
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basevaluecomponent,["tagname","baseformitem","__LZCSSTagSelectors",["baseformitem","basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basevaluecomponent.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{_focusable:"boolean",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",doesenter:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",submit:"boolean",submitname:"string",subnodes:"string",subviews:"string",text:"html",tintcolor:"string",totalframes:"number",transition:"string",type:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},_parentform:null,changed:false,ignoreform:false,onchanged:LzDeclaredEvent,onvalue:LzDeclaredEvent,rollbackvalue:null,submit:new LzAlwaysExpr("$m1g","$m1h",null),submitname:"",value:null},$lzc$class_baseformitem.attributes)
}}})($lzc$class_baseformitem)
};{
Class.make("$lzc$class_selectionmanager",["sel",void 0,"selectedHash",void 0,"selected",void 0,"toggle",void 0,"lastRangeStart",void 0,"construct",function($0,$1){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["construct"]||this.nextMethod(arguments.callee,"construct")).call(this,$0,$1);this.__LZsetSelection([])
},"destroy",function(){
if(this.__LZdeleted)return;this.__LZsetSelection([]);(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["destroy"]||this.nextMethod(arguments.callee,"destroy")).call(this)
},"__LZaddToSelection",function($0,$1){
if($0!=null&&!this.__LZisSelected($0)){
this.selected.push($0);this.__LZsetSelected($0,$1,true)
}},"__LZremoveFromSelection",function($0,$1){
var $2=this.__LZindexOf($0);if($2!=-1){
this.selected.splice($2,1);this.__LZsetSelected($0,$1,false)
}},"__LZindexOf",function($0){
var $1=this.selected;for(var $2=$1.length-1;$2>=0;--$2){
if($1[$2]===$0)return $2
};return -1
},"__LZupdateSelection",function($0,$1){
this.__LZsetSelection($0);for(var $2=$1.length-1;$2>=0;--$2){
var $3=$1[$2];this.__LZsetSelected($3,this.__LZgetView($3),false)
}},"__LZselectRange",function($0,$1){
var $2=this.createRange($0,$1);if($2!=null){
var $3=this.__LZsplitRange($2);this.__LZupdateSelection($3.unchanged,$3.removed);this.lastRangeStart=$0;var $4=$3.added;for(var $5=$4.length-1;$5>=0;--$5){
var $6=$4[$5];this.__LZaddToSelection($6,this.__LZgetView($6))
}}else{
this.clearSelection();this.lastRangeStart=$0
}},"__LZgetSubList",function($0,$1,$2){
var $3=-1;var $4=-1;for(var $5=$0.length-1;$5>=0&&($3==-1||$4==-1);--$5){
if($0[$5]===$1)$3=$5;if($0[$5]===$2)$4=$5
};var $6=null;if($3!=-1&&$4!=-1){
if($4<$3){
$6=$0.slice($4,$3+1);$6.reverse()
}else{
$6=$0.slice($3,$4+1)
}};return $6
},"__LZgetObject",function($0){
return $0
},"__LZgetView",function($0){
return $0
},"__LZsetSelection",function($0){
var $1={};for(var $2=$0.length-1;$2>=0;--$2){
$1[$0[$2].__LZUID]=true
};this.selectedHash=$1;this.selected=$0;this.lastRangeStart=null
},"__LZisSelected",function($0){
return this.selectedHash[$0.__LZUID]==true
},"__LZsetSelected",function($0,$1,$2){
if($2){
this.selectedHash[$1.__LZUID]=true
}else{
delete this.selectedHash[$1.__LZUID]
};if($1[this.sel]){
$1[this.sel]($2)
}},"__LZsplitRange",function($0){
var $1=this.selected;var $2=this.selectedHash;var $3={};var $4=[],$5=[],$6=[];for(var $7=$0.length-1;$7>=0;--$7){
var $8=$0[$7];if($2[$8.__LZUID]){
$4.push($8);$3[$8.__LZUID]=true
}else{
$5.push($8)
}};for(var $7=$1.length-1;$7>=0;--$7){
var $8=$1[$7];if(!$3[$8.__LZUID]){
$6.push($8)
}};return {unchanged:$4,added:$5,removed:$6}},"createRange",function($0,$1){
return this.__LZgetSubList($0.immediateparent.subviews,$0,$1)
},"isSelected",function($0){
return this.__LZisSelected(this.__LZgetObject($0))
},"select",function($0){
var $1=this.__LZgetObject($0);var $2=this.__LZisSelected($1);if($2&&(this.toggle||this.isMultiSelect($0))){
this.unselect($0)
}else{
if(this.selected.length>0&&this.isRangeSelect($0)){
var $3=this.lastRangeStart||this.selected[0];this.__LZselectRange($3,$0)
}else{
if(!this.isMultiSelect($0)){
var $4=$2?this.__LZindexOf($1):-1;var $5=this.selected;this.__LZupdateSelection($4!=-1?$5.splice($4,1):[],$5)
};this.__LZaddToSelection($1,$0)
}}},"unselect",function($0){
this.__LZremoveFromSelection(this.__LZgetObject($0),$0)
},"clearSelection",function(){
this.__LZupdateSelection([],this.selected)
},"getSelection",function(){
return this.selected.concat()
},"isMultiSelect",function($0){
return lz.Keys.isKeyDown("control")
},"isRangeSelect",function($0){
return lz.Keys.isKeyDown("shift")
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzNode,["tagname","selectionmanager","__LZCSSTagSelectors",["selectionmanager","node","Instance"],"attributes",new LzInheritedHash(LzNode.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",sel:"string",styleclass:"string",subnodes:"string",toggle:"boolean",transition:"string","with":"string"}},sel:"setSelected"},$lzc$class_selectionmanager.attributes)
}}})($lzc$class_selectionmanager)
};{
Class.make("$lzc$class_listselector",["multiselect",void 0,"_forcemulti",void 0,"isRangeSelect",function($0){
return this.multiselect&&(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["isRangeSelect"]||this.nextMethod(arguments.callee,"isRangeSelect")).call(this,$0)
},"isMultiSelect",function($0){
return this._forcemulti||this.multiselect&&(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["isMultiSelect"]||this.nextMethod(arguments.callee,"isMultiSelect")).call(this,$0)
},"select",function($0){
if(this.multiselect&&(Array["$lzsc$isa"]?Array.$lzsc$isa($0):$0 instanceof Array)){
this._forcemulti=true;for(var $1=0;$1<$0.length;$1++){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["select"]||this.nextMethod(arguments.callee,"select")).call(this,$0[$1])
};this._forcemulti=false
}else{
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["select"]||this.nextMethod(arguments.callee,"select")).call(this,$0)
}},"getValue",function(){
var $0=this.getSelection();if($0.length==0)return null;if($0.length==1&&!this.multiselect){
return $0[0].getValue()
};var $1=[];for(var $2=0;$2<$0.length;$2++){
$1[$2]=$0[$2].getValue()
};return $1
},"getText",function(){
var $0=this.getSelection();if($0.length==0)return null;if($0.length==1&&!this.multiselect){
return $0[0].text
};var $1=[];for(var $2=0;$2<$0.length;$2++){
$1[$2]=$0[$2].text
};return $1
},"getNumItems",function(){
if(!this.immediateparent.subviews)return 0;return this.immediateparent.subviews.length
},"getNextSubview",function($0,$1){
switch(arguments.length){
case 1:
$1=1;

};if(typeof $1=="undefined")$1=1;var $2=this.immediateparent.subviews;if(!$0){
if($1>0){
return $2[0]
}else{
return $2[$2.length-1]
}};var $3;var $4=$2.length;for(var $5=0;$5<$4;$5++){
var $6=$2[$5];if($6==$0){
var $7=$5+$1;if($7<0){
$3=$2[0]
}else if($7>=$4){
$3=$2[$4-1]
}else{
$3=$2[$7]
};break
}};this.ensureItemInView($3);return $3
},"ensureItemInView",function($0){
if(!$0){
return
};var $1=this.immediateparent.parent;var $2=false;if($0.y+$0.height>$1.height-this.immediateparent.y){
var $3=$1.height-this.immediateparent.y-($0.y+$0.height);var $4=Math.max($1.height-this.immediateparent.height,this.immediateparent.y+$3);this.immediateparent.setAttribute("y",$4);$2=true
}else if(this.immediateparent.y*-1>$0.y){
var $3=this.immediateparent.y*-1-$0.y;var $4=Math.min(0,this.immediateparent.y+$3);this.immediateparent.setAttribute("y",$4);$2=true
};if($2){
this._updatefromscrolling=true
}},"_updatefromscrolling",void 0,"allowhilite",function($0){
if(this._updatefromscrolling){
if($0!=null)this._updatefromscrolling=false;return false
};return true
},"getItemByIndex",function($0){
return this.parent._contentview.subviews[$0]
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_selectionmanager,["tagname","listselector","__LZCSSTagSelectors",["listselector","selectionmanager","node","Instance"],"attributes",new LzInheritedHash($lzc$class_selectionmanager.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{_forcemulti:"boolean",classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",multiselect:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",sel:"string",styleclass:"string",subnodes:"string",toggle:"boolean",transition:"string","with":"string"}},_forcemulti:false,_updatefromscrolling:false,multiselect:false},$lzc$class_listselector.attributes)
}}})($lzc$class_listselector)
};Class.make("$lzc$class_dataselectionmanager",["manager",void 0,"__LZsingleClone",void 0,"destroy",function(){
if(this.__LZdeleted)return;this.manager=null;this.__LZsingleClone=null;(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["destroy"]||this.nextMethod(arguments.callee,"destroy")).call(this)
},"__LZgetObject",function($0){
return $0.datapath.p
},"__LZgetView",function($0){
if(this.manager!=null){
return this.manager.getCloneForNode($0,true)
}else{
var $1=this.__LZsingleClone;if($1&&$1.datapath.p===$0){
return $1
}else{
return null
}}},"__LZsetSelection",function($0){
this.selected=$0;this.lastRangeStart=null
},"__LZisSelected",function($0){
return $0&&$0.sel||false
},"__LZsetSelected",function($0,$1,$2){
if(this.manager==null&&$1!=null){
this.manager=$1.cloneManager;this.__LZsingleClone=$2&&this.manager==null?$1:null
};$0.sel=$2;if($1!=null){
$1.datapath.setSelected($2)
}},"__LZsplitRange",function($0){
var $1="$lzselkey";var $2=this.selected;var $3=[],$4=[],$5=[];for(var $6=$0.length-1;$6>=0;--$6){
var $7=$0[$6];if($7.sel){
$3.push($7);$7.setUserData($1,true)
}else{
$4.push($7)
}};for(var $6=$2.length-1;$6>=0;--$6){
var $7=$2[$6];if(!$7.setUserData($1,null)){
$5.push($7)
}};return {unchanged:$3,added:$4,removed:$5}},"createRange",function($0,$1){
if(this.manager==null){
this.manager=$1.cloneManager;if(this.manager==null){
return null
}else{
this.__LZsingleClone=null
}};return this.__LZgetSubList(this.manager.nodes,$0,$1.datapath.p)
},"getSelection",function(){
var $0=this.selected;var $1=[];for(var $2=0,$3=$0.length;$2<$3;++$2){
$1[$2]=new LzDatapointer(null,{p:$0[$2]})
};return $1
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_selectionmanager,["tagname","dataselectionmanager","__LZCSSTagSelectors",["dataselectionmanager","selectionmanager","node","Instance"],"attributes",new LzInheritedHash($lzc$class_selectionmanager.attributes)]);{
Class.make("$lzc$class_datalistselector",["multiselect",void 0,"_forcemulti",void 0,"isRangeSelect",function($0){
return this.multiselect&&(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["isRangeSelect"]||this.nextMethod(arguments.callee,"isRangeSelect")).call(this,$0)
},"isMultiSelect",function($0){
return this._forcemulti||this.multiselect&&(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["isMultiSelect"]||this.nextMethod(arguments.callee,"isMultiSelect")).call(this,$0)
},"select",function($0){
if(this.multiselect&&(Array["$lzsc$isa"]?Array.$lzsc$isa($0):$0 instanceof Array)){
this._forcemulti=true;for(var $1=0;$1<$0.length;$1++){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["select"]||this.nextMethod(arguments.callee,"select")).call(this,$0[$1])
};this._forcemulti=false
}else{
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["select"]||this.nextMethod(arguments.callee,"select")).call(this,$0)
}},"getValue",function(){
var $0=this.getSelection();if($0.length==0)return null;var $1=this.immediateparent.subviews[0]._valuedatapath;if(!$1)$1=this.immediateparent.subviews[0]._textdatapath;if(!$1)$1="text()";if($0.length==1&&!this.multiselect){
return $0[0].xpathQuery($1)
}else{
var $2=[];for(var $3=0;$3<$0.length;$3++){
$2[$3]=$0[$3].xpathQuery($1)
};return $2
}},"getText",function(){
var $0=this.getSelection();if($0.length==0)return null;var $1=this.immediateparent.subviews[0]._textdatapath;if(!$1)$1="text()";if($0.length==1&&!this.multiselect){
return $0[0].xpathQuery($1)
}else{
var $2=[];for(var $3=0;$3<$0.length;$3++){
$2[$3]=$0[$3].xpathQuery($1)
};return $2
}},"getNumItems",function(){
if(!this.cloneManager){
var $0=this.immediateparent.subviews;if($0==null||$0.length==0){
return 0
}else{
this.cloneManager=$0[0].cloneManager
}};if(this.cloneManager!=null){
if(!this.cloneManager["nodes"]){
return 0
}else{
return this.cloneManager.nodes.length
}}else if($0[0].data){
return 1
}else{
return 0
}},"getNextSubview",function($0,$1){
switch(arguments.length){
case 1:
$1=1;

};var $2=this.immediateparent.subviews[0].cloneManager["clones"];if($0==null){
var $3=$1==-1&&this.parent.shownitems!=-1?this.parent.shownitems-1:0;return $2[$3]
};var $4=this.findIndex($0);if($4==-1)return null;var $5=this.immediateparent.subviews[0].cloneManager.nodes;if(!$1)$1=1;$4+=$1;if($4==-1)$4=0;if($4==$5.length)$4=$5.length-1;this._ensureItemInViewByIndex($4);var $6=$5[$4];var $7=this.immediateparent.subviews;for(var $8=0;$8<$7.length;$8++){
if($7[$8].datapath.p==$6){
return $7[$8]
}}},"findIndex",function($0){
if(!this.immediateparent.subviews[0].cloneManager){
if($0 instanceof lz.view){
return this.immediateparent.subviews[0]==$0?0:-1
}else{
return this.immediateparent.subviews[0].datapath.p==$0.p?0:-1
}};var $1;if($0 instanceof lz.view){
$1=$0.datapath.p
}else{
$1=$0.p
};var $2=this.immediateparent.subviews[0].cloneManager.nodes;var $3=-1;if($2!=null){
for(var $4=0;$4<$2.length;$4++){
if($2[$4]==$1){
$3=$4;break
}}};return $3
},"ensureItemInView",function($0){
if(!$0)return;var $1=this.findIndex($0);if($1!=-1)this._ensureItemInViewByIndex($1)
},"_ensureItemInViewByIndex",function($0){
var $1=this.immediateparent;var $2=$1.subviews;if(!$2||$2.length==0){
return
};var $3=$2[0].height;var $4=$0*$3;var $5=0;if($0>0){
var $6=$2[0].cloneManager;if(this.parent["spacing"]){
$5=this.parent.spacing
}else if($6&&$6["spacing"]){
$5=$6.spacing
};$4+=$5*($0-1)
};var $7=false;var $8=$1.parent.height;var $9=$1.y;if($4+$3>$8-$9){
var $a=$8-$9-($4+$3+$5);var $b=Math.max($8-$1.height,$9+$a);$1.setAttribute("y",$b);$7=true
}else if($9*-1>$4){
var $a=$9*-1-$4-$5;var $b=Math.min(0,$9+$a);$1.setAttribute("y",$b);$7=true
};if($7){
this._updatefromscrolling=true
}},"getItemByIndex",function($0){
var $1=this.immediateparent.subviews;if(!$1||$1.length==0)return null;this._ensureItemInViewByIndex($0);var $2=$1[0].cloneManager;if($2==null){
return $0==0?$1[0]:undefined
};var $3=$2.clones[0].datapath.xpathQuery("position()")-1;return $2.clones[$0-$3]
},"getItemByData",function($0){
return $0?this.getItemByIndex(this.getItemIndexByData($0)):null
},"getItemIndexByData",function($0){
if($0){
var $1=this.immediateparent.subviews;if($1[0].cloneManager){
var $2=$1[0].cloneManager["nodes"];if($2!=null){
for(var $3=0;$3<$2.length;$3++){
if($2[$3]==$0){
return $3
}}}}else if($1[0].datapath.p==$0){
return 0
}};return null
},"_updatefromscrolling",void 0,"allowhilite",function($0){
if(this._updatefromscrolling){
if($0!=null)this._updatefromscrolling=false;return false
};return true
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_dataselectionmanager,["tagname","datalistselector","__LZCSSTagSelectors",["datalistselector","dataselectionmanager","selectionmanager","node","Instance"],"attributes",new LzInheritedHash($lzc$class_dataselectionmanager.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{_forcemulti:"boolean",classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",multiselect:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",sel:"string",styleclass:"string",subnodes:"string",toggle:"boolean",transition:"string","with":"string"}},_forcemulti:false,_updatefromscrolling:false,multiselect:false},$lzc$class_datalistselector.attributes)
}}})($lzc$class_datalistselector)
};{
Class.make("$lzc$class_baselist",["itemclassname",void 0,"__itemclass",void 0,"defaultselection",void 0,"multiselect",void 0,"toggleselected",void 0,"dataoption",void 0,"_hiliteview",void 0,"_contentview",void 0,"_initialselection",void 0,"_selector",void 0,"__focusfromchild",void 0,"onselect",void 0,"onitemclassname",void 0,"doEnterDown",function(){
if((lz.view["$lzsc$isa"]?lz.view.$lzsc$isa(this._hiliteview):this._hiliteview instanceof lz.view)&&this._hiliteview.enabled){
this._hiliteview.setAttribute("selected",true)
}},"doEnterUp",function(){
return
},"init",function(){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this);if(this._contentview==null){
if(this.defaultplacement!=null){
this._contentview=this.searchSubnodes("name",this.defaultplacement)
}else{
this._contentview=this
}};if(this.dataoption=="lazy"||this.dataoption=="resize"){
this._selector=new (lz.datalistselector)(this,{multiselect:this.multiselect,toggle:this.toggleselected})
}else{
this._selector=new (lz.listselector)(this,{multiselect:this.multiselect,toggle:this.toggleselected})
};if(this._initialselection!=null){
this.select(this._initialselection)
}else if(this.defaultselection!=null){
this.selectItemAt(this.defaultselection)
}},"_doFocus",function($0){
if(this["_selector"]!=null){
var $1=this._selector.getSelection();if($1&&$1.length>0){
if(lz.view["$lzsc$isa"]?lz.view.$lzsc$isa($1[0]):$1[0] instanceof lz.view){
this._hiliteview=$1[0];this._hiliteview.setHilite(true)
}}}},"_doblur",function($0){
if(lz.view["$lzsc$isa"]?lz.view.$lzsc$isa(this._hiliteview):this._hiliteview instanceof lz.view){
this._hiliteview.setHilite(false)
};this._hiliteview=null
},"setHilite",function($0){
if(this._selector.allowhilite($0)){
if(lz.view["$lzsc$isa"]?lz.view.$lzsc$isa(this._hiliteview):this._hiliteview instanceof lz.view)this._hiliteview.setHilite(false);this._hiliteview=$0;if(lz.view["$lzsc$isa"]?lz.view.$lzsc$isa($0):$0 instanceof lz.view){
$0.setHilite(true)
}}},"_dokeydown",function($0){
var $1=this._hiliteview;if($1==null){
$1=this.getSelection();if(this.multiselect)$1=$1[$1.length-1]
};if(this.focusable&&$0==32){
if((lz.view["$lzsc$isa"]?lz.view.$lzsc$isa($1):$1 instanceof lz.view)&&$1.enabled){
$1.setAttribute("selected",true);$1.setHilite(true);this._hiliteview=$1
};return
};if(this.focusable&&$0>=37&&$0<=40){
this.setAttribute("doesenter",true);var $2;if($0==39||$0==40){
$2=this._selector.getNextSubview($1)
};if($0==37||$0==38){
$2=this._selector.getNextSubview($1,-1)
};if(lz.view["$lzsc$isa"]?lz.view.$lzsc$isa($1):$1 instanceof lz.view){
$1.setHilite(false)
};if($2){
if($2.enabled&&this._selector.isRangeSelect($2)){
$2.setAttribute("selected",true)
};$2.setHilite(true)
};this._hiliteview=$2
}},"getValue",function(){
return this._selector.getValue()
},"getText",function(){
if(this._initcomplete)return this._selector.getText();return null
},"getSelection",function(){
if(this._initcomplete){
var $0=this._selector.getSelection();if(this.multiselect){
return $0
}else{
if($0.length==0){
return null
}else{
return $0[0]
}}}else{
return this._initialselection
}},"selectNext",function(){
this.moveSelection(1)
},"selectPrev",function(){
this.moveSelection(-1)
},"moveSelection",function($0){
if(!$0)$0=1;var $1=this._selector.getSelection();var $2;if($1.length==0){
$2=this._contentview.subviews[0]
}else{
var $3=$1[0];$2=this._selector.getNextSubview($3,$0)
};var $4=lz.Focus.getFocus();this.select($2);if($3&&$4&&$4.childOf($3)){
lz.Focus.setFocus($2)
}},"getNumItems",function(){
if(this["_selector"]==null)return 0;return this._selector.getNumItems()
},"getItemAt",function($0){
if(this._contentview.subviews[$0]){
return this.getItem(this._contentview.subviews[$0].getValue())
};return null
},"getItem",function($0){
if(this._contentview!=null&&this._contentview.subviews!=null){
for(var $1=0;$1<this._contentview.subviews.length;$1++){
var $2=this._contentview.subviews[$1];if($2.getValue()==$0){
return $2
}}};return null
},"addItem",function($0,$1){
switch(arguments.length){
case 1:
$1=null;

};new (this.__itemclass)(this,{text:$0,value:$1})
},"$lzc$set_itemclassname",function($0){
this.itemclassname=$0;this.__itemclass=lz[$0];if(this.onitemclassname.ready){
this.onitemclassname.sendEvent($0)
}},"removeItem",function($0){
var $1=this.getItem($0);this._removeitem($1)
},"removeItemAt",function($0){
var $1=this._contentview.subviews[$0];this._removeitem($1)
},"removeAllItems",function(){
while(this._contentview.subviews.length!=0){
for(var $0=0;$0<this._contentview.subviews.length;$0++){
this._removeitem(this._contentview.subviews[$0])
}}},"_removeitem",function($0){
if($0){
if($0.selected)this._selector.unselect($0);$0.destroy()
}},"selectItem",function($0){
var $1=this.getItem($0);if($1){
this.select($1)
}},"selectItemAt",function($0){
if(this._selector!=null){
var $1=this._selector.getItemByIndex($0);this.select($1)
}},"clearSelection",function(){
if(this._initcomplete){
this._selector.clearSelection()
}else{
this._initialselection=null;this.defaultselection=null
}},"select",function($0){
if($0==null){

}else if(this._initcomplete){
this._selector.select($0);if(!this.multiselect){
this.setAttribute("value",$0.getValue())
}}else{
if(this.multiselect){
if(this._initialselection==null)this._initialselection=[];this._initialselection.push($0)
}else{
this._initialselection=$0
}};if((lz.view["$lzsc$isa"]?lz.view.$lzsc$isa(this._hiliteview):this._hiliteview instanceof lz.view)&&this._hiliteview["enabled"]){
this._hiliteview.setHilite(false);this._hiliteview=null
};this.setAttribute("doesenter",false);if(this.onselect)this.onselect.sendEvent($0)
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_baseformitem,["tagname","baselist","__LZCSSTagSelectors",["baselist","baseformitem","basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_baseformitem.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{__focusfromchild:"boolean",_focusable:"boolean",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",dataoption:"string",datapath:"string",defaultplacement:"string",doesenter:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",itemclassname:"string",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",submit:"boolean",submitname:"string",subnodes:"string",subviews:"string",text:"html",tintcolor:"string",totalframes:"number",transition:"string",type:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$delegates:["onfocus","_doFocus",null,"onblur","_doblur",null,"onkeydown","_dokeydown",null],__focusfromchild:false,__itemclass:null,_contentview:null,_hiliteview:null,_initialselection:null,_selector:null,dataoption:"none",defaultselection:null,itemclassname:"",multiselect:false,onitemclassname:LzDeclaredEvent,onselect:LzDeclaredEvent,toggleselected:false},$lzc$class_baselist.attributes)
}}})($lzc$class_baselist)
};{
Class.make("$lzc$class_basetrackgroup",["$m1i",function($0){
var $1=this;if($1!==this["boundsref"]||!this.inited){
this.setAttribute("boundsref",$1)
}},"$m1j",function(){
try{
return []
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"boundsref",void 0,"$lzc$set_boundsref",function($0){
this.setBoundsRef($0)
},"onboundsref",void 0,"trackingrate",void 0,"tracking",void 0,"$lzc$set_tracking",function($0){
this.setTracking($0)
},"ontracking",void 0,"_trackgroup",void 0,"_boundstrackgroup",void 0,"activateevents",void 0,"deactivateevents",void 0,"_activateDL",void 0,"_deactivateDL",void 0,"_repeattrackDL",void 0,"_destroyDL",void 0,"onmousetrackoutbottom",void 0,"onmousetrackouttop",void 0,"onmousetrackoutright",void 0,"onmousetrackoutleft",void 0,"construct",function($0,$1){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["construct"]||this.nextMethod(arguments.callee,"construct")).call(this,$0,$1);this._activateDL=new LzDelegate(this,"activateTrackgroup");this._deactivateDL=new LzDelegate(this,"deactivateTrackgroup");this._repeattrackDL=new LzDelegate(this,"trackingout");this._destroyDL=new LzDelegate(this,"destroyitem");this._trackgroup="tg"+this.getUID();this._boundstrackgroup="btg"+this.getUID()
},"init",function(){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this);lz.Track.register(this.boundsref,this._boundstrackgroup)
},"destroy",function(){
this.setTracking(false);lz.Track.unregister(this.boundsref,this._boundstrackgroup);this.activateevents=null;this.deactivateevents=null;(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["destroy"]||this.nextMethod(arguments.callee,"destroy")).call(this)
},"setBoundsRef",function($0){
this.boundsref=$0;if(this.onboundsref)this.onboundsref.sendEvent()
},"setTracking",function($0){
this.tracking=$0;if(this.isinited){
if($0){
lz.Track.activate(this._trackgroup);lz.Track.activate(this._boundstrackgroup)
}else{
lz.Track.deactivate(this._trackgroup);lz.Track.deactivate(this._boundstrackgroup)
}};if(this.ontracking)this.ontracking.sendEvent($0)
},"activateTrackgroup",function($0){
this.setTracking(true);this._destroyDL.register($0,"ondestroy")
},"deactivateTrackgroup",function($0){
this.setTracking(false)
},"destroyitem",function($0){
this.setTracking(false)
},"$m1k",function($0){
lz.Track.register($0,this._trackgroup);if(this.activateevents){
var $1=this._activateDL;var $2=this.activateevents;for(var $3=0;$3<$2.length;++$3){
$1.register($0,$2[$3])
}};if(this.deactivateevents){
var $4=this._deactivateDL;var $5=this.deactivateevents;for(var $3=0;$3<$5.length;++$3){
$4.register($0,$5[$3])
}}},"$m1l",function($0){
lz.Track.unregister($0,this._trackgroup);if(this.activateevents){
var $1=this._activateDL;var $2=this.activateevents;for(var $3=0;$3<$2.length;++$3){
$1.unregisterFrom($0[$2[$3]])
}};if(this.deactivateevents){
var $4=this._deactivateDL;var $5=this.deactivateevents;for(var $3=0;$3<$5.length;++$3){
$4.unregisterFrom($0[$5[$3]])
}}},"$m1m",function(){
return this.boundsref
},"trackingout",function($0){
if(this.tracking){
lz.Timer.addTimer(this._repeattrackDL,this.trackingrate)
};var $1=this.boundsref.getMouse("x");var $2=this.boundsref.getMouse("y");if($1<=0){
if(this.boundsref.onmousetrackoutleft)this.boundsref.onmousetrackoutleft.sendEvent($1)
}else if($1>=this.boundsref.width){
if(this.boundsref.onmousetrackoutright)this.boundsref.onmousetrackoutright.sendEvent($1)
};if($2<=0){
if(this.boundsref.onmousetrackouttop)this.boundsref.onmousetrackouttop.sendEvent($2)
}else if($2>=this.boundsref.height){
if(this.boundsref.onmousetrackoutbottom)this.boundsref.onmousetrackoutbottom.sendEvent($2-this.boundsref.height)
}},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["tagname","basetrackgroup","__LZCSSTagSelectors",["basetrackgroup","view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$delegates:["onaddsubview","$m1k",null,"onremovesubview","$m1l",null,"onmousetrackout","trackingout","$m1m"],_activateDL:null,_deactivateDL:null,_destroyDL:null,_repeattrackDL:null,activateevents:["onmousedown"],boundsref:new LzAlwaysExpr("$m1i","$m1j",null),deactivateevents:["onmouseup"],onboundsref:LzDeclaredEvent,onmousetrackoutbottom:LzDeclaredEvent,onmousetrackoutleft:LzDeclaredEvent,onmousetrackoutright:LzDeclaredEvent,onmousetrackouttop:LzDeclaredEvent,ontracking:LzDeclaredEvent,tracking:true,trackingrate:150},$lzc$class_basetrackgroup.attributes)
}}})($lzc$class_basetrackgroup)
};{
Class.make("$lzc$class_basebutton",["normalResourceNumber",void 0,"overResourceNumber",void 0,"downResourceNumber",void 0,"disabledResourceNumber",void 0,"$m1n",function($0){
this.setAttribute("maxframes",this.totalframes)
},"maxframes",void 0,"resourceviewcount",void 0,"$lzc$set_resourceviewcount",function($0){
this.setResourceViewCount($0)
},"respondtomouseout",void 0,"$m1o",function($0){
this.setAttribute("reference",this)
},"reference",void 0,"$lzc$set_reference",function($0){
this.setreference($0)
},"onresourceviewcount",void 0,"_msdown",void 0,"_msin",void 0,"setResourceViewCount",function($0){
this.resourceviewcount=$0;if(this._initcomplete){
if($0>0){
if(this.subviews){
this.maxframes=this.subviews[0].totalframes;if(this.onresourceviewcount){
this.onresourceviewcount.sendEvent()
}}}}},"_callShow",function(){
if(this._msdown&&this._msin&&this.maxframes>=this.downResourceNumber){
this.showDown()
}else if(this._msin&&this.maxframes>=this.overResourceNumber){
this.showOver()
}else this.showUp()
},"$m1p",function(){
return lz.ModeManager
},"$m1q",function($0){
if($0&&(this._msdown||this._msin)&&!this.childOf($0)){
this._msdown=false;this._msin=false;this._callShow()
}},"$lzc$set_frame",function($0){
if(this.resourceviewcount>0){
for(var $1=0;$1<this.resourceviewcount;$1++){
this.subviews[$1].setAttribute("frame",$0)
}}else{
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzc$set_frame"]||this.nextMethod(arguments.callee,"$lzc$set_frame")).call(this,$0)
}},"doSpaceDown",function(){
if(this._enabled){
this.showDown()
}},"doSpaceUp",function(){
if(this._enabled){
this.onclick.sendEvent();this.showUp()
}},"doEnterDown",function(){
if(this._enabled){
this.showDown()
}},"doEnterUp",function(){
if(this._enabled){
if(this.onclick){
this.onclick.sendEvent()
};this.showUp()
}},"$m1r",function($0){
if(this.isinited){
this.maxframes=this.totalframes;this._callShow()
}},"init",function(){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this);this.setResourceViewCount(this.resourceviewcount);this._callShow()
},"$m1s",function($0){
this.setAttribute("_msin",true);this._callShow()
},"$m1t",function($0){
this.setAttribute("_msin",false);this._callShow()
},"$m1u",function($0){
this.setAttribute("_msdown",true);this._callShow()
},"$m1v",function($0){
this.setAttribute("_msdown",false);this._callShow()
},"_showEnabled",function(){
this.reference.setAttribute("clickable",this._enabled);this.showUp()
},"showDown",function($0){
switch(arguments.length){
case 0:
$0=null;

};this.setAttribute("frame",this.downResourceNumber)
},"showUp",function($0){
switch(arguments.length){
case 0:
$0=null;

};if(!this._enabled&&this.disabledResourceNumber){
this.setAttribute("frame",this.disabledResourceNumber)
}else{
this.setAttribute("frame",this.normalResourceNumber)
}},"showOver",function($0){
switch(arguments.length){
case 0:
$0=null;

};this.setAttribute("frame",this.overResourceNumber)
},"setreference",function($0){
this.reference=$0;if($0!=this)this.setAttribute("clickable",false)
},"_applystyle",function($0){
this.setTint(this,$0.basecolor)
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basecomponent,["tagname","basebutton","__LZCSSTagSelectors",["basebutton","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basecomponent.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{_focusable:"boolean",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",disabledResourceNumber:"number",doesenter:"boolean",downResourceNumber:"number",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",maxframes:"number",name:"token",nodeLevel:"number",normalResourceNumber:"number",opacity:"number",options:"css",overResourceNumber:"number",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourceviewcount:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$delegates:["onmode","$m1q","$m1p","ontotalframes","$m1r",null,"onmouseover","$m1s",null,"onmouseout","$m1t",null,"onmousedown","$m1u",null,"onmouseup","$m1v",null],_msdown:false,_msin:false,clickable:true,disabledResourceNumber:4,downResourceNumber:3,focusable:false,maxframes:new LzOnceExpr("$m1n",null),normalResourceNumber:1,onclick:LzDeclaredEvent,onresourceviewcount:LzDeclaredEvent,overResourceNumber:2,reference:new LzOnceExpr("$m1o",null),resourceviewcount:0,respondtomouseout:true,styleable:false},$lzc$class_basebutton.attributes)
}}})($lzc$class_basebutton)
};{
Class.make("$lzc$class_basebuttonrepeater",["_lasttime",void 0,"stillDownDelegate",void 0,"isMouseDown",void 0,"onmousestilldown",void 0,"stillDownEventGenerator",function($0){
var $1=new Date().getTime();var $2=$1-this._lasttime;this._lasttime=$1;if(this.isMouseDown){
var $3;if($2>600){
$3=500
}else{
$3=50;this.onmousestilldown.sendEvent()
};lz.Timer.resetTimer(this.stillDownDelegate,$3)
}},"$m1w",function($0){
this._lasttime=new Date().getTime();this.isMouseDown=true;if(!this.stillDownDelegate){
this.stillDownDelegate=new LzDelegate(this,"stillDownEventGenerator")
};lz.Timer.addTimer(this.stillDownDelegate,500)
},"$m1x",function($0){
this.isMouseDown=false;lz.Timer.removeTimer(this.stillDownDelegate)
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basebutton,["tagname","basebuttonrepeater","__LZCSSTagSelectors",["basebuttonrepeater","basebutton","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basebutton.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{_focusable:"boolean",_lasttime:"number",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",disabledResourceNumber:"number",doesenter:"boolean",downResourceNumber:"number",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isMouseDown:"boolean",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",maxframes:"number",name:"token",nodeLevel:"number",normalResourceNumber:"number",opacity:"number",options:"css",overResourceNumber:"number",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourceviewcount:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$delegates:["onmousedown","$m1w",null,"onmouseup","$m1x",null],_lasttime:0,clickable:true,isMouseDown:false,onmousestilldown:LzDeclaredEvent,stillDownDelegate:null},$lzc$class_basebuttonrepeater.attributes)
}}})($lzc$class_basebuttonrepeater)
};{
Class.make("$lzc$class_basescrollbar",["$m1y",function($0){
var $1=null;if($1!==this["scrolltarget"]||!this.inited){
this.setAttribute("scrolltarget",$1)
}},"$m1z",function(){
try{
return []
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"scrolltarget",void 0,"axis",void 0,"sizeAxis",void 0,"otherSizeAxis",void 0,"scrollattr",void 0,"scrollmax",void 0,"onscrollmax",void 0,"pagesize",void 0,"stepsize",void 0,"scrollable",void 0,"focusview",void 0,"usemousewheel",void 0,"$lzc$set_usemousewheel",function($0){
if($0==this.usemousewheel)return;this.usemousewheel=$0;if(this._mwUpdateDel)this._mwUpdateDel.unregisterAll();if($0){
this._mwUpdateDel=new LzDelegate(this,"mousewheelUpdate",lz.Keys,"onmousewheeldelta")
}},"mousewheelevent_on",void 0,"mousewheelevent_off",void 0,"mousewheelactive",void 0,"onscrollable",void 0,"$m20",function($0){
var $1=this.enabled&&this.scrollable&&(this._parentcomponent?this._parentcomponent._enabled:true);if($1!==this["_enabled"]||!this.inited){
this.setAttribute("_enabled",$1)
}},"$m21",function(){
try{
return [this,"enabled",this,"scrollable",this,"_parentcomponent",this._parentcomponent,"_enabled"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"usetargetsize",void 0,"othersb",void 0,"thumb",void 0,"_mwActivateDel",void 0,"_mwDeactivateDel",void 0,"_mwUpdateDel",void 0,"clipSizeDel",void 0,"targetHeightDel",void 0,"targetPosDel",void 0,"heightDel",void 0,"heightConstraint",void 0,"widthConstraint",void 0,"init",function(){
this.sizeAxis=this.axis=="x"?"width":"height";this.otherSizeAxis=this.axis=="x"?"height":"width";if(this.scrollattr==""){
this.scrollattr=this.axis
};var $0=false;if(!this.scrolltarget){
var $1=this.immediateparent.subviews.length;for(var $2=0;$2<$1;$2++){
var $3=this.immediateparent.subviews[$2];if($3 instanceof lz.view){
if(!($3 instanceof lz.basescrollbar)){
if(!this.scrolltarget)this.scrolltarget=$3
}else{
if($3!=this){
this.setAttribute("othersb",$3)
}}}};if(this.axis=="y"){
this.setAttribute("align","right")
}else{
this.setAttribute("valign","bottom")
};$0=true
};if(!this.focusview){
if(this.scrolltarget&&this.scrolltarget["focusable"]){
this.focusview=this.scrolltarget
}else if(this.immediateparent["focusable"]){
this.focusview=this.immediateparent
}};if(this.focusview){
this._mwActivateDel=new LzDelegate(this,"activateMouseWheel",this.focusview,this.mousewheelevent_on);this._mwDeactivateDel=new LzDelegate(this,"deactivateMouseWheel",this.focusview,this.mousewheelevent_off)
};if(this.sizeAxis=="width"){
if(!this.hassetwidth){
this.widthConstraint.setAttribute("applied",true)
}};if(this.sizeAxis=="height"){
if(!this.hassetheight){
this.heightConstraint.setAttribute("applied",true)
}};if(!this.scrolltarget){
this.setAttribute("enabled",false)
}else{
this.clipSizeDel=new LzDelegate(this,"scrollbarSizeUpdate",this.scrolltarget.immediateparent,"on"+this.sizeAxis);if(this.scrollmax==null){
this.usetargetsize=true;this.targetHeightDel=new LzDelegate(this,"targetSizeUpdate",this.scrolltarget,"on"+this.sizeAxis);this.scrollmax=this.scrolltarget[this.sizeAxis];if($0&&this.othersb){
this.scrollmax+=this[this.otherSizeAxis]
}}else{
this.targetHeightDel=new LzDelegate(this,"scrollbarSizeUpdate",this,"onscrollmax")
};var $4;if(this.scrollattr=="yscroll"){
$4="onscrolly"
}else $4="on"+this.scrollattr;this.targetPosDel=new LzDelegate(this,"targetPosUpdate",this.scrolltarget,$4);this.heightDel=new LzDelegate(this,"scrollbarSizeUpdate",this.scrolltrack,"on"+this.sizeAxis);this.scrollbarSizeUpdate(null)
};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this)
},"destroy",function(){
this.scrolltarget=null;this.focusview=null;this.othersb=null;(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["destroy"]||this.nextMethod(arguments.callee,"destroy")).call(this)
},"activateMouseWheel",function($0){
this.setAttribute("mousewheelactive",true)
},"deactivateMouseWheel",function($0){
this.setAttribute("mousewheelactive",false)
},"mousewheelUpdate",function($0){
if(this.axis!="y")return;if(this.mousewheelactive||this.scrolltarget&&this.scrolltarget.immediateparent&&this.scrolltarget.immediateparent.isMouseOver()){
this.step(-$0)
}},"targetSizeUpdate",function($0){
if(this.scrolltarget){
var $1=this.scrolltarget[this.sizeAxis];if(this.othersb&&this.othersb.visible){
$1+=this[this.otherSizeAxis]
};this.setAttribute("scrollmax",$1);this.scrollbarSizeUpdate(null)
}},"scrollbarSizeUpdate",function($0){
this.updateThumbSize();if(this.scrolltarget.immediateparent[this.sizeAxis]-this.scrollmax>=0){
return
};var $1=this.scrolltarget[this.scrollattr]+this.scrollmax;if($1<this.scrolltarget.immediateparent[this.sizeAxis]){
var $2=this.scrolltarget.immediateparent[this.sizeAxis]-this.scrollmax;this.scrolltarget.setAttribute(this.scrollattr,$2)
}else{
this.updateThumbPos()
};this.pagesize=this[this.sizeAxis]
},"targetPosUpdate",function($0){
this.updateThumbPos()
},"updateThumbPos",function(){
var $0=0;if(this.scrollmax>0&&this.scrolltrack&&this.scrolltarget){
$0=Math.min(Math.ceil(-this.scrolltarget[this.scrollattr]/this.scrollmax*this.scrolltrack[this.sizeAxis]),this.scrolltrack[this.sizeAxis]-this.thumb[this.sizeAxis])
};this.thumb.setAttribute(this.axis,$0)
},"_showEnabled",function(){
if(!this._enabled){
this.thumb.setAttribute(this.sizeAxis,0)
}else this.updateThumbSize();this.thumb.setAttribute("visible",this._enabled);if(this.scrolltarget)this.scrolltarget.setAttribute(this.scrollattr,0)
},"updateThumbSize",function(){
if(this.scrollmax<=this.scrolltarget.immediateparent[this.sizeAxis]){
if(this.scrollable){
this.setAttribute("scrollable",false);if(this.othersb)this.othersb.targetSizeUpdate(null)
};return
}else{
if(!this.scrollable){
this.setAttribute("scrollable",true);if(this.othersb)this.othersb.targetSizeUpdate(null)
}};var $0=0;if(this.scrollmax>0&&this.scrolltrack&&this.scrolltarget){
$0=Math.floor(this.scrolltarget.immediateparent[this.sizeAxis]/this.scrollmax*this.scrolltrack[this.sizeAxis])
};if($0<14)$0=14;this.thumb.setAttribute(this.sizeAxis,$0)
},"setPosRelative",function($0){
if(!this.scrolltarget)return;var $1=this.scrolltarget[this.scrollattr]-$0;if($1>0)$1=0;var $2=Math.max(this.scrollmax-this.scrolltarget.immediateparent[this.sizeAxis],0);if($1<-$2)$1=-$2;this.scrolltarget.setAttribute(this.scrollattr,$1)
},"step",function($0){
this.setPosRelative($0*this.stepsize)
},"page",function($0){
this.setPosRelative($0*this.pagesize)
},"_applystyle",function($0){
if(this.style!=null){
this.setTint(this,this.style.basecolor)
}},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basecomponent,["tagname","basescrollbar","children",[{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{applied:"boolean",classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",pooling:"boolean",styleclass:"string",subnodes:"string",transition:"string","with":"string"}},$classrootdepth:1,$m22:function($0){
var $1=this.othersb&&this.othersb.visible?this.immediateparent.height-this.othersb.height:this.immediateparent.height;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},$m23:function(){
try{
return [this,"othersb",this.othersb,"visible",this.immediateparent,"height",this.othersb,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},height:new LzAlwaysExpr("$m22","$m23",null),name:"heightConstraint"},"class":LzState},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{applied:"boolean",classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",pooling:"boolean",styleclass:"string",subnodes:"string",transition:"string","with":"string"}},$classrootdepth:1,$m24:function($0){
var $1=this.othersb&&this.othersb.visible?this.immediateparent.width-this.othersb.width:this.immediateparent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},$m25:function(){
try{
return [this,"othersb",this.othersb,"visible",this.immediateparent,"width",this.othersb,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},name:"widthConstraint",width:new LzAlwaysExpr("$m24","$m25",null)},"class":LzState}],"__LZCSSTagSelectors",["basescrollbar","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basecomponent.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{_focusable:"boolean",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",axis:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",doesenter:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",mousewheelactive:"boolean",mousewheelevent_off:"string",mousewheelevent_on:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",otherSizeAxis:"string",pagesize:"number",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",scrollattr:"string",scrollmax:"number",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",sizeAxis:"string",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},_enabled:new LzAlwaysExpr("$m20","$m21",null),_mwActivateDel:null,_mwDeactivateDel:null,_mwUpdateDel:null,axis:"y",clipSizeDel:null,focusable:false,focusview:null,heightDel:null,mousewheelactive:false,mousewheelevent_off:"onblur",mousewheelevent_on:"onfocus",onscrollable:LzDeclaredEvent,onscrollmax:LzDeclaredEvent,othersb:null,pagesize:null,scrollable:true,scrollattr:"",scrollmax:null,scrolltarget:new LzAlwaysExpr("$m1y","$m1z",null),stepsize:10,targetHeightDel:null,targetPosDel:null,thumb:null,usemousewheel:true,usetargetsize:false},$lzc$class_basescrollbar.attributes)
}}})($lzc$class_basescrollbar)
};{
Class.make("$lzc$class_basescrollthumb",["target",void 0,"axis",void 0,"trackscroll",void 0,"targetscroll",void 0,"dragging",void 0,"init",function(){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this);this.classroot.thumb=this
},"destroy",function(){
this.classroot.thumb=null;this.target=null;(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["destroy"]||this.nextMethod(arguments.callee,"destroy")).call(this)
},"startDrag",function($0){
switch(arguments.length){
case 0:
$0=null;

};if(this.dragging)return;this.dragging=true;var $1=this.classroot;$1.targetPosDel.disable();var $2=$1.sizeAxis;this.target=$1.scrolltarget;this.axis=$1.axis;this.trackscroll=this.immediateparent[$2]-this[$2];this.targetscroll=$1.scrollmax-this.target.immediateparent[$2];this[this.axis+"thumbdrag"].setAttribute("applied",true)
},"stopDrag",function($0){
switch(arguments.length){
case 0:
$0=null;

};if(!this.dragging)return;this.dragging=false;this[this.axis+"thumbdrag"].setAttribute("applied",false);this.classroot.targetPosDel.enable()
},"ythumbdrag",void 0,"xthumbdrag",void 0,"thumbControl",function($0){
var $1=$0-this.doffset;if($1<=0){
$1=0
}else if($1>this.trackscroll){
$1=this.trackscroll
};var $2=Math.round(-$1/this.trackscroll*this.targetscroll);if($2!=this.target[this.classroot.scrollattr]){
this.target.setAttribute(this.classroot.scrollattr,$2)
};return $1
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basecomponent,["tagname","basescrollthumb","children",[{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{applied:"boolean",classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",pooling:"boolean",styleclass:"string",subnodes:"string",transition:"string","with":"string"}},$classrootdepth:1,$m26:function($0){
this.setAttribute("doffset",this.getMouse("y"))
},$m27:function($0){
var $1=this.thumbControl(this.immediateparent.getMouse("y"));if($1!==this["y"]||!this.inited){
this.setAttribute("y",$1)
}},$m28:function(){
try{
return [].concat($lzc$getFunctionDependencies("thumbControl",this,this,[this.immediateparent.getMouse("y")],null)).concat($lzc$getFunctionDependencies("getMouse",this,this.immediateparent,["y"],null))
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},doffset:new LzOnceExpr("$m26",null),name:"ythumbdrag",y:new LzAlwaysExpr("$m27","$m28",null)},"class":LzState},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{applied:"boolean",classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",pooling:"boolean",styleclass:"string",subnodes:"string",transition:"string","with":"string"}},$classrootdepth:1,$m29:function($0){
this.setAttribute("doffset",this.getMouse("x"))
},$m2a:function($0){
var $1=this.thumbControl(this.immediateparent.getMouse("x"));if($1!==this["x"]||!this.inited){
this.setAttribute("x",$1)
}},$m2b:function(){
try{
return [].concat($lzc$getFunctionDependencies("thumbControl",this,this,[this.immediateparent.getMouse("x")],null)).concat($lzc$getFunctionDependencies("getMouse",this,this.immediateparent,["x"],null))
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},doffset:new LzOnceExpr("$m29",null),name:"xthumbdrag",x:new LzAlwaysExpr("$m2a","$m2b",null)},"class":LzState}],"__LZCSSTagSelectors",["basescrollthumb","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basecomponent.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{_focusable:"boolean",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",axis:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",doesenter:"boolean",dragging:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",targetscroll:"number",text:"html",tintcolor:"string",totalframes:"number",trackscroll:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$delegates:["onmousedown","startDrag",null,"onmouseup","stopDrag",null],axis:"",clickable:true,dragging:false,focusable:false,styleable:false,target:null,targetscroll:0,trackscroll:0},$lzc$class_basescrollthumb.attributes)
}}})($lzc$class_basescrollthumb)
};{
Class.make("$lzc$class_basescrollarrow",["direction",void 0,"$m2c",function($0){
this.classroot.step(this.direction)
},"$m2d",function($0){
this.classroot.step(this.direction)
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basebuttonrepeater,["tagname","basescrollarrow","__LZCSSTagSelectors",["basescrollarrow","basebuttonrepeater","basebutton","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basebuttonrepeater.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$delegates:["onmousedown","$m2c",null,"onmousestilldown","$m2d",null],clickable:true,direction:1},$lzc$class_basescrollarrow.attributes)
}}})($lzc$class_basescrollarrow)
};{
Class.make("$lzc$class_basescrolltrack",["direction",void 0,"$m2e",function($0){
this.classroot.page(this.direction)
},"$m2f",function($0){
this.classroot.page(this.direction)
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basebuttonrepeater,["tagname","basescrolltrack","__LZCSSTagSelectors",["basescrolltrack","basebuttonrepeater","basebutton","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basebuttonrepeater.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$delegates:["onmousedown","$m2e",null,"onmousestilldown","$m2f",null],clickable:true,direction:1},$lzc$class_basescrolltrack.attributes)
}}})($lzc$class_basescrolltrack)
};{
Class.make("LzLayout",["vip",void 0,"locked",void 0,"$lzc$set_locked",function($0){
if(this.locked==$0)return;if($0){
this.lock()
}else{
this.unlock()
}},"subviews",void 0,"updateDelegate",void 0,"construct",function($0,$1){
this.locked=2;(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["construct"]||this.nextMethod(arguments.callee,"construct")).call(this,$0,$1);this.subviews=[];this.vip=this.immediateparent;if(this.vip.layouts==null){
this.vip.layouts=[this]
}else{
this.vip.layouts.push(this)
};this.updateDelegate=new LzDelegate(this,"update");if(this.immediateparent.isinited){
this.__parentInit()
}else{
new LzDelegate(this,"__parentInit",this.immediateparent,"oninit")
}},"$m2g",function($0){
new LzDelegate(this,"gotNewSubview",this.vip,"onaddsubview");new LzDelegate(this,"removeSubview",this.vip,"onremovesubview");var $1=this.vip.subviews.length;for(var $2=0;$2<$1;$2++){
this.gotNewSubview(this.vip.subviews[$2])
}},"destroy",function(){
if(this.__LZdeleted)return;this.releaseLayout(true);(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["destroy"]||this.nextMethod(arguments.callee,"destroy")).call(this)
},"reset",function($0){
switch(arguments.length){
case 0:
$0=null;

};if(this.locked){
return
};this.update($0)
},"addSubview",function($0){
var $1=$0.options["layoutAfter"];if($1){
this.__LZinsertAfter($0,$1)
}else{
this.subviews.push($0)
}},"gotNewSubview",function($0){
if(!$0.options["ignorelayout"]){
this.addSubview($0)
}},"removeSubview",function($0){
var $1=this.subviews;for(var $2=$1.length-1;$2>=0;$2--){
if($1[$2]==$0){
$1.splice($2,1);break
}};this.reset()
},"ignore",function($0){
var $1=this.subviews;for(var $2=$1.length-1;$2>=0;$2--){
if($1[$2]==$0){
$1.splice($2,1);break
}};this.reset()
},"lock",function(){
this.locked=true
},"unlock",function($0){
switch(arguments.length){
case 0:
$0=null;

};this.locked=false;this.reset()
},"__parentInit",function($0){
switch(arguments.length){
case 0:
$0=null;

};if(this.locked==2){
if(this.isinited){
this.unlock()
}else{
new LzDelegate(this,"unlock",this,"oninit")
}}},"releaseLayout",function($0){
switch(arguments.length){
case 0:
$0=null;

};if($0==null&&this.__delegates!=null)this.removeDelegates();if(this.immediateparent&&this.vip.layouts){
for(var $1=this.vip.layouts.length-1;$1>=0;$1--){
if(this.vip.layouts[$1]==this){
this.vip.layouts.splice($1,1)
}}}},"setLayoutOrder",function($0,$1){
var $2=this.subviews;for(var $3=$2.length-1;$3>=0;$3--){
if($2[$3]===$1){
$2.splice($3,1);break
}};if($3==-1){
return
};if($0=="first"){
$2.unshift($1)
}else if($0=="last"){
$2.push($1)
}else{
for(var $4=$2.length-1;$4>=0;$4--){
if($2[$4]===$0){
$2.splice($4+1,0,$1);break
}};if($4==-1){
$2.splice($3,0,$1)
}};this.reset();return
},"swapSubviewOrder",function($0,$1){
var $2=-1;var $3=-1;var $4=this.subviews;for(var $5=$4.length-1;$5>=0&&($2<0||$3<0);$5--){
if($4[$5]===$0){
$2=$5
};if($4[$5]===$1){
$3=$5
}};if($2>=0&&$3>=0){
$4[$3]=$0;$4[$2]=$1
};this.reset();return
},"__LZinsertAfter",function($0,$1){
var $2=this.subviews;for(var $3=$2.length-1;$3>=0;$3--){
if($2[$3]==$1){
$2.splice($3,0,$0)
}}},"update",function($0){
switch(arguments.length){
case 0:
$0=null;

}},"toString",function(){
return "lz.layout for view "+this.immediateparent
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzNode,["tagname","layout","__LZCSSTagSelectors",["layout","node","Instance"],"attributes",new LzInheritedHash(LzNode.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",styleclass:"string",subnodes:"string",transition:"string","with":"string"}},$delegates:["onconstruct","$m2g",null],locked:2},LzLayout.attributes)
}}})(LzLayout)
};{
Class.make("$lzc$class_stableborderlayout",["axis",void 0,"$lzc$set_axis",function($0){
this.setAxis($0)
},"reset",function($0){
switch(arguments.length){
case 0:
$0=null;

};if(this.locked||this.subviews&&this.subviews.length<2){
return
};this.subviews[1].setAttribute(this.axis,this.subviews[0][this.sizeAxis]);this.update()
},"update",function($0){
switch(arguments.length){
case 0:
$0=null;

};if(this.locked||this.subviews.length<3){
return
};if($0==null){
var $1=this.immediateparent;if($1.usegetbounds){
$1=$1.getBounds()
};$0=$1[this.sizeAxis]
};this.lock();var $2=this.subviews[1];var $3=this.subviews[2];var $4=$3.usegetbounds?$3.getBounds():$3;var $5=$2.usegetbounds?$2.getBounds():$2;$3.setAttribute(this.axis,$0-$4[this.sizeAxis]-0.1);$2.setAttribute(this.sizeAxis,$0-$4[this.sizeAxis]-$5[this.axis]+0.1);this.locked=false
},"addSubview",function($0){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["addSubview"]||this.nextMethod(arguments.callee,"addSubview")).call(this,$0);if(this.subviews.length==2){
var $1=this.subviews[0];if($1.usegetbounds){
$1=$1.getBounds()
};this.subviews[1].setAttribute(this.axis,$1[this.sizeAxis]);$0.setAttribute(this.sizeAxis,0)
}else if(this.subviews.length>2){
this.update()
}},"setAxis",function($0){
this.axis=$0;this.sizeAxis=$0=="x"?"width":"height";if(this.updateDelegate)this.updateDelegate.register(this.immediateparent,"on"+this.sizeAxis)
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzLayout,["tagname","stableborderlayout","__LZCSSTagSelectors",["stableborderlayout","layout","node","Instance"],"attributes",new LzInheritedHash(LzLayout.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{axis:"string",classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",styleclass:"string",subnodes:"string",transition:"string","with":"string"}}},$lzc$class_stableborderlayout.attributes)
}}})($lzc$class_stableborderlayout)
};Class.make("$lzc$class__m2v",["$m2j",function($0){
var $1=this.parent.thumb.y;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$m2k",function(){
try{
return [this.parent.thumb,"y"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m2l",function($0){
var $1=this.parent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m2m",function(){
try{
return [this.parent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basescrolltrack,["displayName","<anonymous extends='basescrolltrack'>","__LZCSSTagSelectors",["basescrolltrack","basebuttonrepeater","basebutton","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basescrolltrack.attributes)]);{
Class.make("$lzc$class__m2w",["$m2n",function($0){
var $1=Math.min(200,this.parent.height-16);if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$m2o",function(){
try{
return [this.parent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m2w.attributes)
}}})($lzc$class__m2w)
};Class.make("$lzc$class__m2x",["$m2p",function($0){
var $1=this.parent.thumb.y+this.parent.thumb.height;if($1!==this["y"]||!this.inited){
this.setAttribute("y",$1)
}},"$m2q",function(){
try{
return [this.parent.thumb,"y",this.parent.thumb,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m2r",function($0){
var $1=this.parent.height-this.parent.thumb.y-this.parent.thumb.height;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$m2s",function(){
try{
return [this.parent,"height",this.parent.thumb,"y",this.parent.thumb,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m2t",function($0){
var $1=this.parent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m2u",function(){
try{
return [this.parent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basescrolltrack,["displayName","<anonymous extends='basescrolltrack'>","__LZCSSTagSelectors",["basescrolltrack","basebuttonrepeater","basebutton","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basescrolltrack.attributes)]);{
Class.make("$lzc$class_vscrollbar",["disabledbgcolor",void 0,"$m2h",function(){
return canvas
},"$m2i",function($0){
this._showEnabled()
},"_showEnabled",function(){
if(!this._enabled){
var $0=this.disabledbgcolor;if($0==null){
var $1=this.immediateparent;while($1.bgcolor==null&&$1!=canvas){
$1=$1.immediateparent
};$0=$1.bgcolor;if($0==null)$0=16777215
};this.setAttribute("bgcolor",$0)
}else{
this.setAttribute("bgcolor",5855577)
};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["_showEnabled"]||this.nextMethod(arguments.callee,"_showEnabled")).call(this)
},"toparrow",void 0,"scrolltrack",void 0,"bottomarrow",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basescrollbar,["tagname","vscrollbar","children",LzNode.mergeChildren([{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:1,name:"toparrow"},children:[{attrs:{$classrootdepth:2,direction:-1,resource:"lzscrollbar_ybuttontop_rsc",x:1,y:1},"class":$lzc$class_basescrollarrow}],"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:1,bottom:void 0,name:"scrolltrack",thumb:void 0,top:void 0},children:[{attrs:{$classrootdepth:2,direction:-1,disabledResourceNumber:3,downResourceNumber:2,height:new LzAlwaysExpr("$m2j","$m2k",null),name:"top",overResourceNumber:0,resource:"lzscrollbar_ytrack_rsc",stretches:"height",width:new LzAlwaysExpr("$m2l","$m2m",null),x:1},"class":$lzc$class__m2v},{attrs:{$classrootdepth:2,name:"thumb",x:1},children:[{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:3,resource:"lzscrollbar_ythumbtop_rsc"},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:3,resource:"lzscrollbar_ythumbmiddle_rsc",stretches:"both"},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:3,resource:"lzscrollbar_ythumbbottom_rsc"},"class":LzView},{attrs:{$classrootdepth:3,axis:"y"},"class":$lzc$class_stableborderlayout},{attrs:{$classrootdepth:3,clip:true,height:new LzAlwaysExpr("$m2n","$m2o",null),resource:"lzscrollbar_ythumbgripper_rsc",valign:"middle",width:11,x:1},"class":$lzc$class__m2w}],"class":$lzc$class_basescrollthumb},{attrs:{$classrootdepth:2,disabledResourceNumber:3,downResourceNumber:2,height:new LzAlwaysExpr("$m2r","$m2s",null),name:"bottom",overResourceNumber:0,resource:"lzscrollbar_ytrack_rsc",stretches:"height",width:new LzAlwaysExpr("$m2t","$m2u",null),x:1,y:new LzAlwaysExpr("$m2p","$m2q",null)},"class":$lzc$class__m2x}],"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:1,height:14,name:"bottomarrow"},children:[{attrs:{$classrootdepth:2,resource:"lzscrollbar_ybuttonbottom_rsc",x:1},"class":$lzc$class_basescrollarrow}],"class":LzView},{attrs:{$classrootdepth:1,axis:"y"},"class":$lzc$class_stableborderlayout}],$lzc$class_basescrollbar["children"]),"__LZCSSTagSelectors",["vscrollbar","basescrollbar","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basescrollbar.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$delegates:["oninit","$m2i","$m2h"],axis:"y",bgcolor:5855577,disabledbgcolor:null,width:14},$lzc$class_vscrollbar.attributes)
}}})($lzc$class_vscrollbar)
};{
Class.make("$lzc$class_simplelayout",["axis",void 0,"$lzc$set_axis",function($0){
this.setAxis($0)
},"inset",void 0,"$lzc$set_inset",function($0){
this.inset=$0;if(this.subviews&&this.subviews.length)this.update();if(this["oninset"])this.oninset.sendEvent(this.inset)
},"spacing",void 0,"$lzc$set_spacing",function($0){
this.spacing=$0;if(this.subviews&&this.subviews.length)this.update();if(this["onspacing"])this.onspacing.sendEvent(this.spacing)
},"setAxis",function($0){
if(this["axis"]==null||this.axis!=$0){
this.axis=$0;this.sizeAxis=$0=="x"?"width":"height";if(this.subviews.length)this.update();if(this["onaxis"])this.onaxis.sendEvent(this.axis)
}},"addSubview",function($0){
this.updateDelegate.register($0,"on"+this.sizeAxis);this.updateDelegate.register($0,"onvisible");if(!this.locked){
var $1=null;var $2=this.subviews;for(var $3=$2.length-1;$3>=0;--$3){
if($2[$3].visible){
$1=$2[$3];break
}};if($1){
var $4=$1[this.axis]+$1[this.sizeAxis]+this.spacing
}else{
var $4=this.inset
};$0.setAttribute(this.axis,$4)
};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["addSubview"]||this.nextMethod(arguments.callee,"addSubview")).call(this,$0)
},"update",function($0){
switch(arguments.length){
case 0:
$0=null;

};if(this.locked)return;var $1=this.subviews.length;var $2=this.inset;for(var $3=0;$3<$1;$3++){
var $4=this.subviews[$3];if(!$4.visible)continue;if($4[this.axis]!=$2){
$4.setAttribute(this.axis,$2)
};if($4.usegetbounds){
$4=$4.getBounds()
};$2+=this.spacing+$4[this.sizeAxis]
}},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzLayout,["tagname","simplelayout","__LZCSSTagSelectors",["simplelayout","layout","node","Instance"],"attributes",new LzInheritedHash(LzLayout.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{axis:"string",classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",styleclass:"string",subnodes:"string",transition:"string","with":"string"}},axis:"y",inset:0,spacing:0},$lzc$class_simplelayout.attributes)
}}})($lzc$class_simplelayout)
};Class.make("$lzc$class__m3s",["$m3k",function($0){
var $1=this.classroot.spacing;if($1!==this["spacing"]||!this.inited){
this.setAttribute("spacing",$1)
}},"$m3l",function(){
try{
return [this.classroot,"spacing"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_simplelayout,["displayName","<anonymous extends='simplelayout'>","__LZCSSTagSelectors",["simplelayout","layout","node","Instance"],"attributes",new LzInheritedHash($lzc$class_simplelayout.attributes)]);Class.make("$lzc$class__m3r",["$m3e",function($0){
var $1=this.immediateparent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m3f",function(){
try{
return [this.immediateparent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m3g",function($0){
var $1=this.classroot.tracking;if($1!==this["tracking"]||!this.inited){
this.setAttribute("tracking",$1)
}},"$m3h",function(){
try{
return [this.classroot,"tracking"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m3i",function($0){
var $1=this.parent;if($1!==this["boundsref"]||!this.inited){
this.setAttribute("boundsref",$1)
}},"$m3j",function(){
try{
return [this,"parent"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m3m",function($0){
if(this.classroot.itemclassname==""){
this.classroot.__itemclass=$0.constructor
};if((this.classroot.dataoption=="lazy"||this.classroot.dataoption=="resize")&&!this.classroot._itemheight){
this.classroot._itemheight=$0.height
};this.classroot.adjustmyheight()
},"$m3n",function($0){
this.classroot.adjustmyheight()
},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basetrackgroup,["displayName","<anonymous extends='basetrackgroup'>","children",[{attrs:{$classrootdepth:3,axis:"y",spacing:new LzAlwaysExpr("$m3k","$m3l",null)},"class":$lzc$class__m3s}],"__LZCSSTagSelectors",["basetrackgroup","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basetrackgroup.attributes)]);{
Class.make("$lzc$class__m3q",["$m36",function($0){
var $1=this.classroot.border_left;if($1!==this["x"]||!this.inited){
this.setAttribute("x",$1)
}},"$m37",function(){
try{
return [this.classroot,"border_left"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m38",function($0){
var $1=this.classroot.border_top;if($1!==this["y"]||!this.inited){
this.setAttribute("y",$1)
}},"$m39",function(){
try{
return [this.classroot,"border_top"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m3a",function($0){
var $1=this.classroot.width-this.classroot.border_right-this.classroot.border_left;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m3b",function(){
try{
return [this.classroot,"width",this.classroot,"border_right",this.classroot,"border_left"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m3c",function($0){
var $1=this.classroot._bgcolor;if($1!==this["bgcolor"]||!this.inited){
this.setAttribute("bgcolor",$1)
}},"$m3d",function(){
try{
return [this.classroot,"_bgcolor"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"_sbar",void 0,"onmousetrackoutleft",void 0,"onmousetrackoutright",void 0,"content",void 0,"ensurevscrollbar",function(){
if(this._sbar==null){
var $0=this.classroot.scrollbarclassname;if($0==""){
$0="vscrollbar"
};if($0&&lz[$0]){
this._sbar=new (lz[$0])(this,{stepsize:"20"})
}}},"showvscrollbar",function(){
if(this._sbar==null){
this.ensurevscrollbar()
};this._sbar.setAttribute("visible",true);this.classroot.setAttribute("rightinset",this._sbar.width)
},"hidevscrollbar",function(){
if(this._sbar!=null){
this._sbar.setAttribute("visible",false)
};this.classroot.setAttribute("rightinset",0)
},"vscrollbarisvisible",function(){
return this._sbar!=null&&this._sbar.visible
},"$m3o",function($0){
if(this.vscrollbarisvisible())this._sbar.step(1)
},"$m3p",function($0){
if(this.vscrollbarisvisible())this._sbar.step(-1)
},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","children",[{attrs:{$classrootdepth:2,$delegates:["onaddsubview","$m3m",null,"onheight","$m3n",null],boundsref:new LzAlwaysExpr("$m3i","$m3j",null),deactivateevents:["onmouseup","onselect"],name:"content",tracking:new LzAlwaysExpr("$m3g","$m3h",null),width:new LzAlwaysExpr("$m3e","$m3f",null)},"class":$lzc$class__m3r}],"__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m3q.attributes)
}}})($lzc$class__m3q)
};{
Class.make("$lzc$class_list",["rightinset",void 0,"bordersize",void 0,"$m2y",function($0){
var $1=this.bordersize;if($1!==this["border_top"]||!this.inited){
this.setAttribute("border_top",$1)
}},"$m2z",function(){
try{
return [this,"bordersize"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"border_top",void 0,"$m30",function($0){
var $1=this.bordersize;if($1!==this["border_left"]||!this.inited){
this.setAttribute("border_left",$1)
}},"$m31",function(){
try{
return [this,"bordersize"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"border_left",void 0,"$m32",function($0){
var $1=this.bordersize;if($1!==this["border_right"]||!this.inited){
this.setAttribute("border_right",$1)
}},"$m33",function(){
try{
return [this,"bordersize"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"border_right",void 0,"$m34",function($0){
var $1=this.bordersize;if($1!==this["border_bottom"]||!this.inited){
this.setAttribute("border_bottom",$1)
}},"$m35",function(){
try{
return [this,"bordersize"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"border_bottom",void 0,"tracking",void 0,"spacing",void 0,"minheight",void 0,"shownitems",void 0,"$lzc$set_shownitems",function($0){
this._setShownItems($0)
},"onshownitems",void 0,"scrollable",void 0,"autoscrollbar",void 0,"scrollbarclassname",void 0,"init",function(){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this);if(this._hasSetHeight)this.setAttribute("height",this.height);this.adjustmyheight()
},"interior",void 0,"_setShownItems",function($0){
this.shownitems=$0;if(this.onshownitems)this.onshownitems.sendEvent();if(this._initcomplete)this.adjustmyheight()
},"select",function($0){
var $1=$0;if($1&&$1["length"]>0){
$1=$1[0]
};this.ensureItemInView($1);(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["select"]||this.nextMethod(arguments.callee,"select")).call(this,$0)
},"_doFocus",function($0){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["_doFocus"]||this.nextMethod(arguments.callee,"_doFocus")).call(this,$0);if(!this.__focusfromchild){
var $1=this.getSelection();if(this.multiselect){
$1=$1.length==0?null:$1[0]
};this.ensureItemInView($1)
}},"ensureItemInView",function($0){
if(!$0)return;if(this._initcomplete){
this._selector.ensureItemInView($0)
}},"_itemheight",void 0,"calcMyHeight",function(){
var $0=this.getNumItems();if($0==0){
return this.minheight
};var $1;if(this.shownitems>-1&&this.shownitems<$0||this.dataoption=="lazy"||this.dataoption=="resize"){
var $2;if(this.dataoption=="lazy"||this.dataoption=="resize"){
$2=this._itemheight;if(this.shownitems<$0)$0=this.shownitems
}else{
$0=this.shownitems;$2=this.interior.content.subviews[0].height
};$1=$2*$0+this.spacing*($0-1)
}else{
$1=this.interior.content.height
};return $1
},"_hasSetHeight",void 0,"_heightinternal",void 0,"$lzc$set_height",function($0){
if($0!=null&&!this._heightinternal){
this._hasSetHeight=true
}else{
this._hasSetHeight=false;if(!this._heightinternal){
var $1=this.calcMyHeight();$0=$1+this.border_top+this.border_bottom
}};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzc$set_height"]||this.nextMethod(arguments.callee,"$lzc$set_height")).call(this,$0);if(this._initcomplete){
this.interior.setAttribute("height",$0-this.border_top-this.border_bottom);this.checkscrollbar()
}},"checkscrollbar",function(){
if(this.autoscrollbar){
if(this._contentview.height>this.interior.height){
this.interior.showvscrollbar()
}else{
this.interior.hidevscrollbar()
}}},"adjustmyheight",function(){
if(!this._initcomplete)return;if(this._hasSetHeight){
this.checkscrollbar()
}else{
var $0=this.calcMyHeight();this._heightinternal=true;this.setAttribute("height",$0+this.border_top+this.border_bottom);this._heightinternal=false
}},"addItem",function($0,$1){
switch(arguments.length){
case 1:
$1=null;

};if(this.itemclassname==""){
this.setAttribute("itemclassname","textlistitem")
};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["addItem"]||this.nextMethod(arguments.callee,"addItem")).call(this,$0,$1);this.adjustmyheight()
},"_setbordercolor",void 0,"_bgcolor",void 0,"$lzc$set_bgcolor",function($0){
if(this._setbordercolor){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzc$set_bgcolor"]||this.nextMethod(arguments.callee,"$lzc$set_bgcolor")).call(this,$0)
}else{
this._bgcolor=$0;var $1=this["onbgcolor"];if($1&&$1.ready){
$1.sendEvent($0)
}}},"_applystyle",function($0){
if(this.style!=null){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["_applystyle"]||this.nextMethod(arguments.callee,"_applystyle")).call(this,$0);this._setbordercolor=true;this.setAttribute("bgcolor",$0.bordercolor);this._setbordercolor=false;if(this._bgcolor==null)this.interior.setAttribute("bgcolor",$0.bgcolor)
}},"destroy",function(){
if(this.autoscrollbar)this.setAttribute("autoscrollbar",false);if(this.shownitems!=-1)this.setAttribute("shownitems",-1);(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["destroy"]||this.nextMethod(arguments.callee,"destroy")).call(this)
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_baselist,["tagname","list","children",[{attrs:{$classrootdepth:1,$delegates:["onmousetrackoutbottom","$m3o",null,"onmousetrackouttop","$m3p",null],_sbar:null,bgcolor:new LzAlwaysExpr("$m3c","$m3d",null),clip:true,content:void 0,name:"interior",onmousetrackoutleft:LzDeclaredEvent,onmousetrackoutright:LzDeclaredEvent,width:new LzAlwaysExpr("$m3a","$m3b",null),x:new LzAlwaysExpr("$m36","$m37",null),y:new LzAlwaysExpr("$m38","$m39",null)},"class":$lzc$class__m3q},{attrs:"content","class":$lzc$class_userClassPlacement}],"__LZCSSTagSelectors",["list","baselist","baseformitem","basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_baselist.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{__focusfromchild:"boolean",_focusable:"boolean",_heightinternal:"boolean",_setbordercolor:"boolean",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",dataoption:"string",datapath:"string",defaultplacement:"string",doesenter:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",itemclassname:"string",layout:"css",loadratio:"number",mask:"string",minheight:"number",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",scrollbarclassname:"string",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",submit:"boolean",submitname:"string",subnodes:"string",subviews:"string",text:"html",tintcolor:"string",totalframes:"number",transition:"string",type:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},_bgcolor:null,_hasSetHeight:false,_heightinternal:false,_itemheight:null,_setbordercolor:false,autoscrollbar:true,border_bottom:new LzAlwaysExpr("$m34","$m35",null),border_left:new LzAlwaysExpr("$m30","$m31",null),border_right:new LzAlwaysExpr("$m32","$m33",null),border_top:new LzAlwaysExpr("$m2y","$m2z",null),bordersize:1,minheight:24,onshownitems:LzDeclaredEvent,rightinset:0,scrollable:false,scrollbarclassname:"vscrollbar",shownitems:-1,spacing:0,tracking:false,width:100},$lzc$class_list.attributes)
}}})($lzc$class_list)
};{
Class.make("$lzc$class_basefloatinglist",["owner",void 0,"wouldbename",void 0,"attach",void 0,"_currentattachy",void 0,"_currentattachx",void 0,"attachtarget",void 0,"$lzc$set_attachtarget",function($0){
this.setAttachTarget($0)
},"attachoffset",void 0,"_updateAttachPosDel",void 0,"_origshownitems",void 0,"$m3t",function($0){
var $1=this.attachtarget?this.attachtarget["style"]:null;if($1!==this["style"]||!this.inited){
this.setAttribute("style",$1)
}},"$m3u",function(){
try{
return [this,"attachtarget"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"setAttachTarget",function($0){
this.attachtarget=$0;if(this.visible)this.updateAttachLocation();var $1=this._updateAttachPosDel;if($1){
$1.unregisterAll();if($0){
for(var $2=$0;$2!==canvas;$2=$2.immediateparent){
$1.register($2,"onx");$1.register($2,"ony")
}}}},"construct",function($0,$1){
this.owner=$0;if(typeof $1.name!="undefined"){
var $2=$1.name;$1.name=null;this.wouldbename=$2;this.owner[$2]=this
};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["construct"]||this.nextMethod(arguments.callee,"construct")).call(this,canvas,$1);var $3=this.owner;while($3!==canvas){
if($3 instanceof lz.basecomponent){
this._parentcomponent=$3;break
};$3=$3.immediateparent
};new (lz.Delegate)(this,"_handledestroy",$0,"ondestroy");this._updateAttachPosDel=new (lz.Delegate)(this,"_doUpdateAttachLocation")
},"_handledestroy",function($0){
this.destroy()
},"destroy",function(){
if(this.owner!=null){
if(this["wouldbename"]!=null){
this.owner[this.wouldbename]=null
};this.owner=null
};this.setAttachTarget(null);this._updateAttachPosDel=null;var $0=canvas.subviews;for(var $1=$0.length-1;$1>=0;$1--){
if($0[$1]===this){
$0.splice($1,1);break
}};var $2=canvas.subnodes;for(var $1=$2.length-1;$1>=0;$1--){
if($2[$1]===this){
$2.splice($1,1);break
}};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["destroy"]||this.nextMethod(arguments.callee,"destroy")).call(this)
},"init",function(){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this);if(this.attachtarget==null){
this.setAttachTarget(this.owner)
}},"getMenuCapHeight",function(){
return 0
},"_constraintsApplied",void 0,"_setScroll",function(){
var $0=this.interior.content.subviews[0];var $1=$0?$0.height:20;var $2=this.attachtarget.getAttributeRelative("y",canvas);var $3=this.getMenuCapHeight();var $4=$2;var $5=canvas.height-($2+this.attachtarget.height+this.attachoffset+$3);var $6=0;var $7="top";var $8=$4;if($5>$4){
$7="bottom";$6=$2+this.attachtarget.height+this.attachoffset;$8=$5
};var $9=Math.floor(($8+this.spacing-$3)/($1+this.spacing));var $a=$9*($1+this.spacing)-this.spacing+$3;if(this.attach=="left"||this.attach=="right"){
$a+=$1+this.spacing;$9++;if($7=="bottom"){
$6-=this.attachtarget.height+this.attachoffset
}else{
$6+=this.attachtarget.height
}};if($7=="top"){
$6+=$4-$a+$3
};this.setAttribute("y",$6);this.setAttribute("_currentattachy",$7);this._keepshownitems=true;this._setShownItems($9);this._keepshownitems=false;this.setAttribute("scrollable",true)
},"_keepshownitems",void 0,"_setShownItems",function($0){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["_setShownItems"]||this.nextMethod(arguments.callee,"_setShownItems")).call(this,$0);if(this._origshownitems==-2||!this._keepshownitems){
this._origshownitems=$0
}},"_doUpdateAttachLocation",function($0){
this.updateAttachLocation()
},"updateAttachLocation",function(){
if(!this.isinited)return;if(!this.attachtarget)return;var $0=false;var $1=this.attach;var $2=this.attachtarget.getAttributeRelative("x",canvas);while(true){
if($1=="bottom"||$1=="top"){
var $3=$2;if($3<0){
$3=0
}else if($3+this.attachtarget.width>canvas.width){
$3=canvas.width-this.width
}else if($3+this.width>canvas.width){
$3=$2+this.attachtarget.width-this.width
};this.setAttribute("x",$3);break
}else if($1=="left"){
var $3=$2-this.width;if($3>0){
this.setAttribute("x",$3);this.setAttribute("_currentattachx","left");break
}else{
$1="right"
}};if($1=="right"){
var $3=$2+this.attachtarget.width;if($3+this.width<canvas.width){
this.setAttribute("x",$3);this.setAttribute("_currentattachx","right");break
}else{
if(!$0){
$1="left";$0=true
}else{
break
}}}};this._keepshownitems=true;this._setShownItems(this._origshownitems);this._keepshownitems=false;this.setAttribute("scrollable",false);var $0=false;var $1=this.attach;var $4=this.getMenuCapHeight();var $5=this.calcMyHeight()+$4;var $6=this.attachtarget.getAttributeRelative("y",canvas);while(true){
if($1=="left"||$1=="right"){
if($6+$5<canvas.height){
this.setAttribute("y",$6);this.setAttribute("_currentattachy","bottom");break
}else{
$1="top"
}}else if($1=="bottom"){
var $7=$6+this.attachtarget.height+this.attachoffset;if($7+$5<canvas.height){
this.setAttribute("y",$7);this.setAttribute("_currentattachy","bottom");break
}else{
$1="top"
}};if($1=="top"){
var $7=$6-$5;if(this.attach=="right"||this.attach=="left")$7+=this.attachtarget.height;if($7>0){
this.setAttribute("y",$7+$4);this.setAttribute("_currentattachy","top");break
}else{
if(!$0){
$1="bottom";$0=true
}else{
this._setScroll();break
}}}}},"$m3v",function($0){
this.owner.onmousedown.sendEvent();this.bringToFront()
},"$m3w",function($0){
this.updateAttachLocation()
},"$m3x",function($0){
this.updateAttachLocation()
},"$m3y",function($0){
if($0){
this.updateAttachLocation()
}else{
this.setAttribute("x",-1000);this.setAttribute("y",-1000)
}},"toString",function(){
return "floatinglist: wouldbename,owner = "+this.wouldbename+","+this.owner
},"getNextSelection",function(){
var $0=this.owner.getNextSelection();return $0
},"getPrevSelection",function(){
return this.owner.resolveSelection()
},"$m3z",function($0){
if(this.owner!="undefined"&&this.owner["onblur"]){
this.owner.onblur.sendEvent()
}},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_list,["tagname","basefloatinglist","children",LzNode.mergeChildren([],$lzc$class_list["children"]),"__LZCSSTagSelectors",["basefloatinglist","list","baselist","baseformitem","basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_list.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{__focusfromchild:"boolean",_currentattachx:"string",_currentattachy:"string",_focusable:"boolean",_heightinternal:"boolean",_keepshownitems:"boolean",_origshownitems:"number",_setbordercolor:"boolean",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",attach:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",dataoption:"string",datapath:"string",defaultplacement:"string",doesenter:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",itemclassname:"string",layout:"css",loadratio:"number",mask:"string",minheight:"number",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",scrollbarclassname:"string",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",submit:"boolean",submitname:"string",subnodes:"string",subviews:"string",text:"html",tintcolor:"string",totalframes:"number",transition:"string",type:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",wouldbename:"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$delegates:["onmousedown","$m3v",null,"onwidth","$m3w",null,"onheight","$m3x",null,"onvisible","$m3y",null,"onblur","$m3z",null],_constraintsApplied:false,_currentattachx:"bottom",_currentattachy:"bottom",_keepshownitems:false,_origshownitems:-2,_updateAttachPosDel:null,attach:"bottom",attachoffset:0,attachtarget:null,clickable:true,options:{ignorelayout:true},style:new LzAlwaysExpr("$m3t","$m3u",null),wouldbename:"",x:-1000,y:-1000},$lzc$class_basefloatinglist.attributes)
}}})($lzc$class_basefloatinglist)
};{
Class.make("$lzc$class__m4d",["$m41",function($0){
var $1=this.classroot.offsety;if($1!==this["y"]||!this.inited){
this.setAttribute("y",$1)
}},"$m42",function(){
try{
return [this.classroot,"offsety"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m43",function($0){
var $1=this.parent.width-this.classroot.inset;if($1!==this["x"]||!this.inited){
this.setAttribute("x",$1)
}},"$m44",function(){
try{
return [this.parent,"width",this.classroot,"inset"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m45",function($0){
var $1=this.parent.height-this.classroot.offsety;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$m46",function(){
try{
return [this.parent,"height",this.classroot,"offsety"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"top",void 0,"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","children",[{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,name:"top",resource:"shadowTR"},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,resource:"shadowMR",stretches:"height"},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,height:0},"class":LzView},{attrs:{$classrootdepth:2,axis:"y"},"class":$lzc$class_stableborderlayout}],"__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m4d.attributes)
}}})($lzc$class__m4d)
};{
Class.make("$lzc$class__m4e",["$m47",function($0){
var $1=this.parent.bottomvisible;if($1!==this["visible"]||!this.inited){
this.setAttribute("visible",$1)
}},"$m48",function(){
try{
return [this.parent,"bottomvisible"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m49",function($0){
var $1=this.parent.height;if($1!==this["y"]||!this.inited){
this.setAttribute("y",$1)
}},"$m4a",function(){
try{
return [this.parent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m4b",function($0){
var $1=this.parent.width+this.parent.right.width-this.classroot.inset;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m4c",function(){
try{
return [this.parent,"width",this.parent.right,"width",this.classroot,"inset"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","children",[{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,resource:"shadowBL"},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,resource:"shadowBM",stretches:"width"},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,resource:"shadowBR"},"class":LzView},{attrs:{$classrootdepth:2,axis:"x"},"class":$lzc$class_stableborderlayout}],"__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m4e.attributes)
}}})($lzc$class__m4e)
};{
Class.make("$lzc$class__floatshadow",["$m40",function($0){
this.setCornerResourceNumber(this.cornerresourcenumber)
},"inset",void 0,"offsety",void 0,"shadowsize",void 0,"bottomvisible",void 0,"$lzc$set_bottomvisible",function($0){
this.setBottomVisible($0)
},"onbottomvisible",void 0,"cornerresourcenumber",void 0,"$lzc$set_cornerresourcenumber",function($0){
this.setCornerResourceNumber($0)
},"oncornerresourcenumber",void 0,"right",void 0,"bottom",void 0,"setBottomVisible",function($0){
this.bottomvisible=$0;if(this.onbottomvisible)this.onbottomvisible.sendEvent($0);this.setCornerResourceNumber(this.cornerresourcenumber)
},"setCornerResourceNumber",function($0){
if(!this.bottomvisible){
this.cornerresourcenumber=3
}else{
this.cornerresourcenumber=2
};if(!this.isinited)return;this.right.top.setAttribute("frame",this.cornerresourcenumber);if(this.oncornerresourcenumber)this.oncornerresourcenumber.sendEvent()
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["tagname","_floatshadow","children",[{attrs:{$classrootdepth:1,height:new LzAlwaysExpr("$m45","$m46",null),name:"right",top:void 0,x:new LzAlwaysExpr("$m43","$m44",null),y:new LzAlwaysExpr("$m41","$m42",null)},"class":$lzc$class__m4d},{attrs:{$classrootdepth:1,name:"bottom",visible:new LzAlwaysExpr("$m47","$m48",null),width:new LzAlwaysExpr("$m4b","$m4c",null),y:new LzAlwaysExpr("$m49","$m4a",null)},"class":$lzc$class__m4e}],"__LZCSSTagSelectors",["_floatshadow","view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$delegates:["oninit","$m40",null],bottomvisible:true,cornerresourcenumber:0,inset:10,offsety:10,onbottomvisible:LzDeclaredEvent,oncornerresourcenumber:LzDeclaredEvent,shadowsize:5},$lzc$class__floatshadow.attributes)
}}})($lzc$class__floatshadow)
};Class.make("$lzc$class__m59",["$m4p",function($0){
var $1=this.classroot._currentattachy!="top";if($1!==this["bottomvisible"]||!this.inited){
this.setAttribute("bottomvisible",$1)
}},"$m4q",function(){
try{
return [this.classroot,"_currentattachy"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m4r",function($0){
var $1=this.classroot.shadowoffsety;if($1!==this["offsety"]||!this.inited){
this.setAttribute("offsety",$1)
}},"$m4s",function(){
try{
return [this.classroot,"shadowoffsety"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m4t",function($0){
var $1=this.classroot.shadowcrn;if($1!==this["cornerresourcenumber"]||!this.inited){
this.setAttribute("cornerresourcenumber",$1)
}},"$m4u",function(){
try{
return [this.classroot,"shadowcrn"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m4v",function($0){
var $1=this.immediateparent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m4w",function(){
try{
return [this.immediateparent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m4x",function($0){
var $1=this.immediateparent.height;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$m4y",function(){
try{
return [this.immediateparent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class__floatshadow,["displayName","<anonymous extends='_floatshadow'>","children",LzNode.mergeChildren([],$lzc$class__floatshadow["children"]),"__LZCSSTagSelectors",["_floatshadow","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class__floatshadow.attributes)]);{
Class.make("$lzc$class__m5a",["$m4z",function($0){
var $1=this.immediateparent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m50",function(){
try{
return [this.immediateparent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m51",function($0){
var $1=this.immediateparent.height;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$m52",function(){
try{
return [this.immediateparent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m5a.attributes)
}}})($lzc$class__m5a)
};{
Class.make("$lzc$class__m58",["$m4l",function($0){
var $1=this.immediateparent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m4m",function(){
try{
return [this.immediateparent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m4n",function($0){
var $1=this.immediateparent.height;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$m4o",function(){
try{
return [this.immediateparent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"shdw",void 0,"borderview",void 0,"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","children",[{attrs:{$classrootdepth:2,bottomvisible:new LzAlwaysExpr("$m4p","$m4q",null),cornerresourcenumber:new LzAlwaysExpr("$m4t","$m4u",null),height:new LzAlwaysExpr("$m4x","$m4y",null),name:"shdw",offsety:new LzAlwaysExpr("$m4r","$m4s",null),opacity:0.6,width:new LzAlwaysExpr("$m4v","$m4w",null)},"class":$lzc$class__m59},{attrs:{$classrootdepth:2,bgcolor:8421504,height:new LzAlwaysExpr("$m51","$m52",null),name:"borderview",width:new LzAlwaysExpr("$m4z","$m50",null)},"class":$lzc$class__m5a}],"__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m58.attributes)
}}})($lzc$class__m58)
};{
Class.make("$lzc$class__m5b",["$m53",function($0){
var $1=this.parent._currentattachy=="top"?-this.height+1:this.parent.height;if($1!==this["y"]||!this.inited){
this.setAttribute("y",$1)
}},"$m54",function(){
try{
return [this.parent,"_currentattachy",this,"height",this.parent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m55",function($0){
var $1=this.classroot.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m56",function(){
try{
return [this.classroot,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m57",function($0){
this.setAttribute("frame",1)
},"$lzc$set_frame",function($0){
var $1=this.subviews.length;for(var $2=0;$2<$1;$2++){
this.subviews[$2].setAttribute("frame",$0)
}},"$lzc$set_y",function($0){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzc$set_y"]||this.nextMethod(arguments.callee,"$lzc$set_y")).call(this,$0);if($0<0){
this.setAttribute("frame",1)
}else{
this.setAttribute("frame",2)
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","children",[{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,resource:"menucap_lft"},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,resource:"menucap_mid",stretches:"width"},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:2,resource:"menucap_rt"},"class":LzView},{attrs:{$classrootdepth:2,axis:"x"},"class":$lzc$class_stableborderlayout}],"__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m5b.attributes)
}}})($lzc$class__m5b)
};{
Class.make("$lzc$class_floatinglist",["$m4f",function($0){
var $1=this._currentattachy=="bottom"?0:this.bordersize;if($1!==this["border_bottom"]||!this.inited){
this.setAttribute("border_bottom",$1)
}},"$m4g",function(){
try{
return [this,"_currentattachy",this,"bordersize"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m4h",function($0){
var $1=this._currentattachy=="top"?0:this.bordersize;if($1!==this["border_top"]||!this.inited){
this.setAttribute("border_top",$1)
}},"$m4i",function(){
try{
return [this,"_currentattachy",this,"bordersize"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"shadowcrn",void 0,"$m4j",function($0){
var $1=this._currentattachy=="bottom"?3:-9;if($1!==this["shadowoffsety"]||!this.inited){
this.setAttribute("shadowoffsety",$1)
}},"$m4k",function(){
try{
return [this,"_currentattachy"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"shadowoffsety",void 0,"bkgnd",void 0,"menucap",void 0,"_applystyle",function($0){
if(this.style!=null){
this.setTint(this.menucap,$0.basecolor)
}},"init",function(){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this);this.bkgnd.sendToBack();this.bringToFront()
},"$lzc$set_bgcolor",function($0){
if(!this.isinited)return;this.bkgnd.borderview.setAttribute("bgcolor",$0)
},"getMenuCapHeight",function(){
return this.menucap.height
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basefloatinglist,["tagname","floatinglist","children",LzNode.mergeChildren([{attrs:{$classrootdepth:1,borderview:void 0,height:new LzAlwaysExpr("$m4n","$m4o",null),ignoreplacement:true,name:"bkgnd",shdw:void 0,width:new LzAlwaysExpr("$m4l","$m4m",null)},"class":$lzc$class__m58},{attrs:{$classrootdepth:1,$delegates:["oninit","$m57",null],ignoreplacement:true,name:"menucap",width:new LzAlwaysExpr("$m55","$m56",null),y:new LzAlwaysExpr("$m53","$m54",null)},"class":$lzc$class__m5b}],$lzc$class_basefloatinglist["children"]),"__LZCSSTagSelectors",["floatinglist","basefloatinglist","list","baselist","baseformitem","basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basefloatinglist.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({border_bottom:new LzAlwaysExpr("$m4f","$m4g",null),border_top:new LzAlwaysExpr("$m4h","$m4i",null),shadowcrn:0,shadowoffsety:new LzAlwaysExpr("$m4j","$m4k",null)},$lzc$class_floatinglist.attributes)
}}})($lzc$class_floatinglist)
};{
Class.make("$lzc$class__m6r",["$m5g",function($0){
var $1=this.immediateparent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m5h",function(){
try{
return [this.immediateparent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m6r.attributes)
}}})($lzc$class__m6r)
};{
Class.make("$lzc$class__m6t",["$m5o",function($0){
var $1=this.immediateparent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m5p",function(){
try{
return [this.immediateparent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m5q",function($0){
var $1=this.immediateparent.height;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$m5r",function(){
try{
return [this.immediateparent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m6t.attributes)
}}})($lzc$class__m6t)
};{
Class.make("$lzc$class__m6u",["$m5s",function($0){
this.setAttribute("width",this.parent.width-4)
},"$m5t",function($0){
if($0==38||$0==40){
if(!this.classroot.isopen){
this.classroot.setOpen(true,true)
};this.classroot.cblist.onkeydown.sendEvent($0)
}else if($0>31&&$0!=8){
this.classroot.cblist.clearSelection()
}},"$m5u",function($0){
if(this.classroot["onfocus"])this.classroot.onfocus.sendEvent($0)
},"$m5v",function($0){
this.classroot.setAttribute("text",this.text);if(this.classroot["onblur"])this.classroot.onblur.sendEvent($0)
},"$m5w",function($0){
if(this.classroot["onkeyup"])this.classroot.onkeyup.sendEvent($0)
},"$m5x",function($0){
if(this.classroot["onkeydown"])this.classroot.onkeydown.sendEvent($0)
},"getFocusRect",function(){
return this.classroot.getFocusRect()
},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzInputText,["displayName","<anonymous extends='inputtext'>","__LZCSSTagSelectors",["inputtext","text","view","node","Instance"],"attributes",new LzInheritedHash(LzInputText.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",antiAliasType:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",cdata:"cdata",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",direction:"string",embedfonts:"boolean",enabled:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",gridFit:"string",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",hscroll:"number",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",letterspacing:"number",lineheight:"number",loadratio:"number",mask:"string",maxhscroll:"number",maxlength:"numberExpression",maxscroll:"number",multiline:"boolean",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",password:"boolean",pattern:"string",pixellock:"boolean",placement:"string",playing:"boolean",resize:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",scroll:"number",scrollevents:"boolean",scrollheight:"number",scrollwidth:"number",selectable:"boolean",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",sharpness:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",textalign:"string",textdecoration:"string",textindent:"number",thickness:"number",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",xscroll:"number",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression",yscroll:"number"}}},$lzc$class__m6u.attributes)
}}})($lzc$class__m6u)
};{
Class.make("$lzc$class__m6v",["$m5y",function($0){
var $1=this.parent.width-4;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m5z",function(){
try{
return [this.parent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m60",function($0){
if($0==38||$0==40||$0==32){
if(!this.classroot.isopen){
this.classroot.setOpen(true,true)
};if($0!=32){
this.classroot.cblist.onkeydown.sendEvent($0)
}}},"$m61",function($0){
this.classroot.toggle()
},"$m62",function($0){
if(this.classroot["onfocus"])this.classroot.onfocus.sendEvent($0)
},"$m63",function($0){
if(this.classroot["onblur"])this.classroot.onblur.sendEvent($0)
},"$m64",function($0){
if(this.classroot["onkeyup"])this.classroot.onkeyup.sendEvent($0)
},"$m65",function($0){
if(this.classroot["onkeydown"])this.classroot.onkeydown.sendEvent($0)
},"getPrevSelection",function(){
return lz.Focus.getPrev(this.parent)
},"getFocusRect",function(){
return this.classroot.getFocusRect()
},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzText,["displayName","<anonymous extends='text'>","__LZCSSTagSelectors",["text","view","node","Instance"],"attributes",new LzInheritedHash(LzText.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",antiAliasType:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",cdata:"cdata",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",direction:"string",embedfonts:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",gridFit:"string",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",hscroll:"number",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",letterspacing:"number",lineheight:"number",loadratio:"number",mask:"string",maxhscroll:"number",maxlength:"numberExpression",maxscroll:"number",multiline:"boolean",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pattern:"string",pixellock:"boolean",placement:"string",playing:"boolean",resize:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",scroll:"number",scrollevents:"boolean",scrollheight:"number",scrollwidth:"number",selectable:"boolean",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",sharpness:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",textalign:"string",textdecoration:"string",textindent:"number",thickness:"number",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",xscroll:"number",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression",yscroll:"number"}}},$lzc$class__m6v.attributes)
}}})($lzc$class__m6v)
};{
Class.make("$lzc$class__m6s",["$m5i",function($0){
this.setAttribute("x",this.classroot.text_x)
},"$m5j",function($0){
this.setAttribute("y",this.classroot.text_y)
},"$m5k",function($0){
var $1=this.classroot.text_width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m5l",function(){
try{
return [this.classroot,"text_width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m5m",function($0){
var $1=this.classroot.height-2*this.classroot.bordersize-2;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$m5n",function(){
try{
return [this.classroot,"height",this.classroot,"bordersize"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"_dsblfield",void 0,"setupText",function(){
var $0=this.classroot.cblist.getText();if(!$0){
if(this.classroot.defaultselection){
if(this.classroot.cblist._contentview!=null){
this.classroot.cblist.selectItemAt(this.classroot.defaultselection);$0=this.classroot.cblist.getText()
}}else{
$0=this.classroot.defaulttext
}};if(this.cbtext)this.cbtext.setAttribute("text",$0);if(this._dsblfield)this._dsblfield.setAttribute("text",$0);this.parent._applystyle(this.parent.style)
},"editable_state",void 0,"non_editable_state",void 0,"editbkgnd",void 0,"cbtext",void 0,"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","children",[{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{applied:"boolean",classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",pooling:"boolean",styleclass:"string",subnodes:"string",transition:"string","with":"string"}},$classrootdepth:2,cbtext:void 0,editbkgnd:void 0,name:"editable_state"},children:[{attrs:{$classrootdepth:2,bgcolor:16777215,height:new LzAlwaysExpr("$m5q","$m5r",null),name:"editbkgnd",width:new LzAlwaysExpr("$m5o","$m5p",null)},"class":$lzc$class__m6t},{attrs:{$classrootdepth:2,$delegates:["onkeydown","$m5t",null,"onfocus","$m5u",null,"onblur","$m5v",null,"onkeyup","$m5w",null,"onkeydown","$m5x",null],name:"cbtext",width:new LzOnceExpr("$m5s",null),x:2,y:1},"class":$lzc$class__m6u}],"class":LzState},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{applied:"boolean",classroot:"string",cloneManager:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",name:"token",nodeLevel:"number",options:"css",parent:"string",placement:"string",pooling:"boolean",styleclass:"string",subnodes:"string",transition:"string","with":"string"}},$classrootdepth:2,cbtext:void 0,name:"non_editable_state"},children:[{attrs:{$classrootdepth:2,$delegates:["onkeydown","$m60",null,"onmouseup","$m61",null,"onfocus","$m62",null,"onblur","$m63",null,"onkeyup","$m64",null,"onkeydown","$m65",null],clickable:true,focusable:true,name:"cbtext",width:new LzAlwaysExpr("$m5y","$m5z",null),x:2,y:1},"class":$lzc$class__m6v}],"class":LzState}],"__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m6s.attributes)
}}})($lzc$class__m6s)
};Class.make("$lzc$class__m6w",["$m66",function($0){
var $1=this.owner.width-1;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m67",function(){
try{
return [this.owner,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m68",function($0){
var $1=this.owner.bordersize;if($1!==this["bordersize"]||!this.inited){
this.setAttribute("bordersize",$1)
}},"$m69",function(){
try{
return [this.owner,"bordersize"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m6a",function($0){
var $1=this.owner.spacing;if($1!==this["spacing"]||!this.inited){
this.setAttribute("spacing",$1)
}},"$m6b",function(){
try{
return [this.owner,"spacing"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m6c",function($0){
var $1=this.owner.shownitems;if($1!==this["shownitems"]||!this.inited){
this.setAttribute("shownitems",$1)
}},"$m6d",function(){
try{
return [this.owner,"shownitems"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m6e",function($0){
var $1=this.owner.attachoffset;if($1!==this["attachoffset"]||!this.inited){
this.setAttribute("attachoffset",$1)
}},"$m6f",function(){
try{
return [this.owner,"attachoffset"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m6g",function($0){
var $1=this.owner.autoscrollbar;if($1!==this["autoscrollbar"]||!this.inited){
this.setAttribute("autoscrollbar",$1)
}},"$m6h",function(){
try{
return [this.owner,"autoscrollbar"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m6i",function($0){
var $1=this.owner.defaultselection?this.owner.defaultselection:(this.owner.defaulttext==""?0:null);if($1!==this["defaultselection"]||!this.inited){
this.setAttribute("defaultselection",$1)
}},"$m6j",function(){
try{
return [this.owner,"defaultselection",this.owner,"defaulttext"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m6k",function($0){
this.dataoption=this.owner.dataoption
},"$m6l",function($0){
if(this.owner.shownitems==-1){
var $1=Math.floor((canvas.height-this.owner.y)/this.owner.height);this.setAttribute("shownitems",$1)
}},"_dokeyup",function($0){
if($0==27){
this.owner.setOpen(false)
}},"$classrootdepth",void 0,"$datapath",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_floatinglist,["displayName","<anonymous extends='floatinglist'>","children",LzNode.mergeChildren([],$lzc$class_floatinglist["children"]),"__LZCSSTagSelectors",["floatinglist","basefloatinglist","list","baselist","baseformitem","basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_floatinglist.attributes)]);{
Class.make("$lzc$class_basecombobox",["$m5c",function($0){
var $1=this.cblist.value;if($1!==this["value"]||!this.inited){
this.setAttribute("value",$1)
}},"$m5d",function(){
try{
return [this.cblist,"value"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"isopen",void 0,"$lzc$set_isopen",function($0){
this.setOpen($0)
},"bordersize",void 0,"spacing",void 0,"defaulttext",void 0,"defaultselection",void 0,"$lzc$set_defaultselection",function($0){
this.setDefaultSelection($0)
},"ondefaultselection",void 0,"editable",void 0,"$lzc$set_editable",function($0){
this.setEditable($0)
},"itemclassname",void 0,"$lzc$set_itemclassname",function($0){
this.setItemclassname($0)
},"shownitems",void 0,"mousedownintext",void 0,"initcomplete",void 0,"autoscrollbar",void 0,"selected",void 0,"onselect",void 0,"dataoption",void 0,"attachoffset",void 0,"text_x",void 0,"text_y",void 0,"$m5e",function($0){
var $1=this.width-19;if($1!==this["text_width"]||!this.inited){
this.setAttribute("text_width",$1)
}},"$m5f",function(){
try{
return [this,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"text_width",void 0,"min_width",void 0,"getNextSelection",function(){
this.setOpen(false);if(!this.editable){
return lz.Focus.getNext(this.bkgnd)
}else{
return lz.Focus.getNext(this.interior.cbtext)
}},"resolveSelection",function(){
this.setOpen(false);if(!this.editable){
return this.bkgnd
}else{
return this.interior.cbtext
}},"bkgnd",void 0,"interior",void 0,"cblist",void 0,"setDefaultSelection",function($0){
this.defaultselection=$0;if($0==null)return;if(this.defaulttext!=""){
this.defaulttext=""
};if(this.ondefaultselection)this.ondefaultselection.sendEvent()
},"$m6m",function($0){
if(lz.DataNodeMixin["$lzsc$isa"]?lz.DataNodeMixin.$lzsc$isa($0):$0 instanceof lz.DataNodeMixin){
this.cblist.datapath.setPointer($0)
}},"onitemclassname",void 0,"setItemclassname",function($0){
this.itemclassname=$0;if(this.isinited){
if($0!=""){
this.cblist.setAttribute("itemclassname",this.itemclassname)
}else{
this.itemclassname=this.cblist.itemclassname
}};if(this.onitemclassname)this.onitemclassname.sendEvent()
},"oneditable",void 0,"setEditable",function($0){
this.editable=$0;if(this._initcomplete){
if($0){
this.interior.non_editable_state.setAttribute("applied",false);this.interior.editable_state.setAttribute("applied",true)
}else{
this.interior.editable_state.setAttribute("applied",false);this.interior.non_editable_state.setAttribute("applied",true)
};this._showEnabled();this.interior.setupText();if(this.oneditable)this.oneditable.sendEvent()
}},"ontext",void 0,"determinePlacement",function($0,$1,$2){
if($1=="cblist"){
return this.cblist.determinePlacement($0,$1,$2)
}else return(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["determinePlacement"]||this.nextMethod(arguments.callee,"determinePlacement")).call(this,$0,$1,$2)
},"init",function(){
this._initcomplete=true;this.setEditable(this.editable);(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["init"]||this.nextMethod(arguments.callee,"init")).call(this);this.setItemclassname(this.itemclassname);this.cblist.setAttribute("visible",false)
},"$m6n",function($0){
if(lz.Focus.getFocus()!=this.interior.cbtext)this.setOpen(false)
},"getFocusRect",function(){
var $0=this.getAttributeRelative("x",canvas);var $1=this.getAttributeRelative("y",canvas);var $2=this.getAttributeRelative("width",canvas);var $3=this.getAttributeRelative("height",canvas);return [$0,$1,$2,$3]
},"select",function($0){
this.cblist.select($0)
},"$m6o",function($0){
this.setAttribute("_fixseldel",new LzDelegate(this,"fixSelection"))
},"_fixseldel",void 0,"_fixselstart",void 0,"_fixselend",void 0,"fixSelection",function($0){
this.interior.cbtext.setSelection(this._fixselstart,this._fixselend)
},"$m6p",function(){
return this.cblist
},"$m6q",function($0){
this.setOpen(false);this.selected=$0;if($0)this.setText($0.text);if(this.editable&&lz.Focus.getFocus()==this.interior.cbtext){
this._fixselstart=0;this._fixselend=$0.text.length;lz.Idle.callOnIdle(this._fixseldel)
};if(this.onselect)this.onselect.sendEvent($0)
},"passModeEvent",function($0,$1){
if($0=="onmousedown"){
if($1!=null){
if(!$1.childOf(this.cblist)){
this.setOpen(false)
}}else{
this.setOpen(false)
}};if($1&&$1.childOf(this.cblist)){
if($1[$0]){
$1[$0].sendEvent($1)
};return false
};return true
},"toggle",function($0){
switch(arguments.length){
case 0:
$0=null;

};this.setOpen(!this.isopen,$0)
},"setOpen",function($0,$1){
switch(arguments.length){
case 1:
$1=null;

};if(!this.isinited){
this.isopen=$0;return
};if($0){
if(this.isopen)return;lz.ModeManager.makeModal(this);this.cblist.bringToFront();this.cblist.setAttribute("visible",true);lz.Focus.setFocus(this.cblist,$1);this.isopen=true;if(this["onisopen"])this.onisopen.sendEvent(true)
}else{
if(!this["isopen"])return;this.isopen=false;lz.ModeManager.release(this);this.cblist.setAttribute("visible",false);if(this["onisopen"])this.onisopen.sendEvent(false);if(lz.Focus.getFocus()==this.cblist){
if(!this.editable){
lz.Focus.setFocus(this.bkgnd,$1)
}else{
lz.Focus.setFocus(this.interior.cbtext,$1)
}}}},"acceptValue",function($0,$1){
switch(arguments.length){
case 1:
$1=null;

};this.setText($0)
},"getValue",function(){
var $0;var $1=this.cblist.getValue();if($1==null){
$0=this.interior.cbtext.text
}else{
$0=$1
};return $0
},"setText",function($0){
this.text=$0;this.interior.cbtext.setAttribute("text",$0);if(!this._enabled)this.interior._dsblfield.setAttribute("text",$0);if(this.ontext)this.ontext.sendEvent($0)
},"getText",function(){
return this.interior.cbtext.text
},"getSelection",function(){
return this.cblist.getSelection()
},"addItem",function($0,$1){
switch(arguments.length){
case 1:
$1=null;

};this.cblist.addItem($0,$1)
},"getItem",function($0){
return this.cblist.getItem($0)
},"getItemAt",function($0){
return this.cblist.getItemAt($0)
},"removeItem",function($0){
this.cblist.removeItem($0)
},"removeItemAt",function($0){
this.cblist.removeItemAt($0)
},"selectItem",function($0){
this.cblist.selectItem($0)
},"selectItemAt",function($0){
this.cblist.selectItemAt($0)
},"clearSelection",function(){
this.cblist.clearSelection();this.setText("")
},"_applystyle",function($0){
if(this.style!=null){
if(this.editable){
this.interior.editbkgnd.setAttribute("bgcolor",$0.textfieldcolor);this.interior.cbtext.setAttribute("bgcolor",$0.textfieldcolor)
}else{
this.interior.cbtext.setAttribute("bgcolor",null);this.interior.cbtext.setAttribute("fgcolor",$0.textcolor)
};this.setTint(this.bkgnd,$0.basecolor)
}},"_showEnabled",function(){
this.interior.cbtext.setAttribute("visible",this._enabled);if(!this._enabled){
if(this.interior._dsblfield==null){
var $0=new (lz.text)(this.interior,{name:"_dsblfield",x:2,y:1,width:this.interior.width,height:this.interior.height,fgcolor:this["style"]?this.style.textdisabledcolor:null})
}else{
this.interior._dsblfield.setAttribute("visible",true)
};this.interior._dsblfield.setAttribute("text",this.getText())
}else{
if(this.interior._dsblfield)this.interior._dsblfield.setAttribute("visible",false)
}},"$lzc$set_width",function($0){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzc$set_width"]||this.nextMethod(arguments.callee,"$lzc$set_width")).call(this,Math.max($0,this.min_width))
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_baseformitem,["tagname","basecombobox","children",[{attrs:{$classrootdepth:1,focusable:false,name:"bkgnd",width:new LzAlwaysExpr("$m5g","$m5h",null)},"class":$lzc$class__m6r},{attrs:{$classrootdepth:1,_dsblfield:null,cbtext:void 0,editable_state:void 0,editbkgnd:void 0,focusable:false,height:new LzAlwaysExpr("$m5m","$m5n",null),name:"interior",non_editable_state:void 0,width:new LzAlwaysExpr("$m5k","$m5l",null),x:new LzOnceExpr("$m5i",null),y:new LzOnceExpr("$m5j",null)},"class":$lzc$class__m6s},{attrs:{$classrootdepth:1,$datapath:{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{axis:"string",classroot:"string",cloneManager:"string",context:"string",datapath:"string",defaultplacement:"string",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",name:"token",nodeLevel:"number",options:"css",p:"string",parent:"string",placement:"string",pooling:"boolean",replication:"string",rerunxpath:"boolean",sortorder:"string",sortpath:"string",spacing:"number",styleclass:"string",subnodes:"string",transition:"string","with":"string",xpath:"string"}},datacontrolsvisibility:false},"class":LzDatapath},$delegates:["onconstruct","$m6k",null,"oninit","$m6l",null,"onkeyup","_dokeyup",null],attach:"bottom",attachoffset:new LzAlwaysExpr("$m6e","$m6f",null),autoscrollbar:new LzAlwaysExpr("$m6g","$m6h",null),bordersize:new LzAlwaysExpr("$m68","$m69",null),datapath:LzNode._ignoreAttribute,defaultselection:new LzAlwaysExpr("$m6i","$m6j",null),multiselect:false,name:"cblist",shownitems:new LzAlwaysExpr("$m6c","$m6d",null),spacing:new LzAlwaysExpr("$m6a","$m6b",null),visible:false,width:new LzAlwaysExpr("$m66","$m67",null)},"class":$lzc$class__m6w},{attrs:"cblist","class":$lzc$class_userClassPlacement}],"__LZCSSTagSelectors",["basecombobox","baseformitem","basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_baseformitem.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{_fixselend:"number",_fixselstart:"number",_focusable:"boolean",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",attachoffset:"number",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",dataoption:"string",datapath:"string",defaultplacement:"string",defaultselection:"number",defaulttext:"string",doesenter:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",itemclassname:"string",layout:"css",loadratio:"number",mask:"string",min_width:"number",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",submit:"boolean",submitname:"string",subnodes:"string",subviews:"string",text:"html",text_width:"number",text_x:"number",text_y:"number",tintcolor:"string",totalframes:"number",transition:"string",type:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$delegates:["ondata","$m6m",null,"onblur","$m6n",null,"onselect","$m6q","$m6p"],_fixseldel:new LzOnceExpr("$m6o",null),attachoffset:-1,autoscrollbar:true,bordersize:1,dataoption:"none",defaultselection:null,defaulttext:"",editable:true,focusable:false,initcomplete:0,isopen:false,itemclassname:"",min_width:50,mousedownintext:false,ondefaultselection:LzDeclaredEvent,oneditable:LzDeclaredEvent,onitemclassname:LzDeclaredEvent,onselect:LzDeclaredEvent,ontext:LzDeclaredEvent,selected:null,shownitems:-1,spacing:0,text_width:new LzAlwaysExpr("$m5e","$m5f",null),text_x:2,text_y:2,value:new LzAlwaysExpr("$m5c","$m5d",null),width:100},$lzc$class_basecombobox.attributes)
}}})($lzc$class_basecombobox)
};Class.make("$lzc$class__m6y",["$m6x",function($0){
this.classroot.toggle(false)
},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basebutton,["displayName","<anonymous extends='basebutton'>","__LZCSSTagSelectors",["basebutton","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basebutton.attributes)]);Class.make("$lzc$class_combobox",["lft",void 0,"mid",void 0,"rgt",void 0,"_showEnabled",function(){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["_showEnabled"]||this.nextMethod(arguments.callee,"_showEnabled")).call(this);if(this._enabled){
if(!this.editable){
this.bkgnd.lft.setAttribute("frame",2);this.bkgnd.mid.setAttribute("frame",2)
}else{
this.bkgnd.lft.setAttribute("frame",1);this.bkgnd.mid.setAttribute("frame",1)
}}else{
if(!this.editable){
this.bkgnd.lft.setAttribute("frame",4);this.bkgnd.mid.setAttribute("frame",4)
}else{
this.bkgnd.lft.setAttribute("frame",3);this.bkgnd.mid.setAttribute("frame",3)
}}},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basecombobox,["tagname","combobox","children",LzNode.mergeChildren([{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:1,name:"lft",placement:"bkgnd",resource:"lzcombobox_lft_rsc"},"class":LzView},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:1,name:"mid",placement:"bkgnd",resource:"lzcombobox_mid_rsc",stretches:"width"},"class":LzView},{attrs:{$classrootdepth:1,$delegates:["onclick","$m6x",null],clickable:true,name:"rgt",placement:"bkgnd",resource:"lzcombobox_rgt_rsc",styleable:true},"class":$lzc$class__m6y},{attrs:{$classrootdepth:1,axis:"x",placement:"bkgnd"},"class":$lzc$class_stableborderlayout}],$lzc$class_basecombobox["children"]),"__LZCSSTagSelectors",["combobox","basecombobox","baseformitem","basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basecombobox.attributes)]);{
Class.make("$lzc$class_baselistitem",["selected",void 0,"$lzc$set_selected",function($0){
this._setSelected($0)
},"onselected",void 0,"onselect",void 0,"_selectonevent",void 0,"$lzc$set__selectonevent",function($0){
this.setSelectOnEvent($0)
},"$lzc$set_datapath",function($0){
if(null!=this.datapath){
this.datapath.setXPath($0)
}else{
var $1={xpath:$0};if(this._parentcomponent.dataoption=="lazy"||this._parentcomponent.dataoption=="resize"){
$1.replication=this._parentcomponent.dataoption;if(this.parent["spacing"])$1.spacing=this.parent.spacing
}else if(this._parentcomponent.dataoption=="pooling"){
$1.pooling=true
};new (lz.datapath)(this,$1)
}},"_valuedatapath",void 0,"_textdatapath",void 0,"dataBindAttribute",function($0,$1,$2){
if(this._parentcomponent.dataoption=="lazy"||this._parentcomponent.dataoption=="resize"){
if($0=="text"){
this._textdatapath=$1
}else if($0=="value")this._valuedatapath=$1
};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["dataBindAttribute"]||this.nextMethod(arguments.callee,"dataBindAttribute")).call(this,$0,$1,$2)
},"setSelectOnEvent",function($0){
this._selectDL=new LzDelegate(this,"doClick",this,$0)
},"doClick",function($0){
if(this._parentcomponent){
this._parentcomponent.select(this)
}},"_doMousedown",function($0){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["_doMousedown"]||this.nextMethod(arguments.callee,"_doMousedown")).call(this,$0);var $1=this._parentcomponent;if(!this.focusable&&$1&&$1.focusable){
$1.__focusfromchild=true;lz.Focus.setFocus($1,false);$1.__focusfromchild=false
}},"setSelected",function($0){
this.selected=$0;if(this.onselect.ready)this.onselect.sendEvent(this);if(this.onselected.ready)this.onselected.sendEvent(this)
},"_setSelected",function($0){
this.selected=$0;if($0){
this.parent.select(this)
}},"setHilite",function($0){},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basevaluecomponent,["tagname","baselistitem","__LZCSSTagSelectors",["baselistitem","basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basevaluecomponent.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{_focusable:"boolean",_selectonevent:"string",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",doesenter:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",tintcolor:"string",totalframes:"number",transition:"string",type:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},_selectonevent:"onclick",_textdatapath:null,_valuedatapath:null,clickable:true,focusable:false,onselect:LzDeclaredEvent,onselected:LzDeclaredEvent,selected:false},$lzc$class_baselistitem.attributes)
}}})($lzc$class_baselistitem)
};{
Class.make("$lzc$class_listitem",["$m6z",function($0){
var $1=this.immediateparent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m70",function(){
try{
return [this.immediateparent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m71",function($0){
this.setAttribute("_ipclassroot",this.immediateparent.classroot)
},"_ipclassroot",void 0,"hilited",void 0,"$m72",function($0){
this._ipclassroot.setHilite(this)
},"$m73",function($0){
if(!this.immediateparent.tracking){
this._ipclassroot.setHilite(this)
}},"$m74",function($0){
if(!this.immediateparent.tracking){
this._ipclassroot.setHilite(null)
}},"setSelected",function($0){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["setSelected"]||this.nextMethod(arguments.callee,"setSelected")).call(this,$0);if(this._initcomplete)this._applystyle(this.style)
},"setHilite",function($0){
if($0!=this.hilited){
this.hilited=$0;if(this._initcomplete)this._applystyle(this.style)
}},"$m75",function(){
return this.immediateparent.classroot
},"$m76",function($0){
lz.Track.register(this,$0)
},"_applystyle",function($0){
if(this.style!=null){
if(this._enabled){
if(this.selected){
this.setAttribute("bgcolor",this.style.selectedcolor)
}else if(this.hilited){
this.setAttribute("bgcolor",this.style.hilitecolor)
}else this.setAttribute("bgcolor",this.style.textfieldcolor)
}else{
this.setAttribute("bgcolor",this.style.textfieldcolor)
}}},"_showEnabled",function(){
this.setAttribute("clickable",this._enabled);if(this._initcomplete){
this._applystyle(this.style)
}},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_baselistitem,["tagname","listitem","__LZCSSTagSelectors",["listitem","baselistitem","basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_baselistitem.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$delegates:["onmousetrackover","$m72",null,"onmouseover","$m73",null,"onmouseout","$m74",null,"ontrackgroup","$m76","$m75"],_ipclassroot:new LzOnceExpr("$m71",null),_selectonevent:"onmousetrackup",clickable:true,height:20,hilited:false,width:new LzAlwaysExpr("$m6z","$m70",null)},$lzc$class_listitem.attributes)
}}})($lzc$class_listitem)
};{
Class.make("$lzc$class__m7h",["$m79",function($0){
var $1=this.classroot.text_x;if($1!==this["x"]||!this.inited){
this.setAttribute("x",$1)
}},"$m7a",function(){
try{
return [this.classroot,"text_x"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m7b",function($0){
var $1=this.classroot.text_y;if($1!==this["y"]||!this.inited){
this.setAttribute("y",$1)
}},"$m7c",function(){
try{
return [this.classroot,"text_y"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m7d",function($0){
var $1=this.immediateparent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m7e",function(){
try{
return [this.immediateparent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m7f",function($0){
var $1=this.parent.text;if($1!==this["text"]||!this.inited){
this.setAttribute("text",$1)
}},"$m7g",function(){
try{
return [this.parent,"text"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzText,["displayName","<anonymous extends='text'>","__LZCSSTagSelectors",["text","view","node","Instance"],"attributes",new LzInheritedHash(LzText.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",antiAliasType:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",cdata:"cdata",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",direction:"string",embedfonts:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",gridFit:"string",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",hscroll:"number",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",letterspacing:"number",lineheight:"number",loadratio:"number",mask:"string",maxhscroll:"number",maxlength:"numberExpression",maxscroll:"number",multiline:"boolean",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pattern:"string",pixellock:"boolean",placement:"string",playing:"boolean",resize:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",scroll:"number",scrollevents:"boolean",scrollheight:"number",scrollwidth:"number",selectable:"boolean",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",sharpness:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",textalign:"string",textdecoration:"string",textindent:"number",thickness:"number",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",xscroll:"number",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression",yscroll:"number"}}},$lzc$class__m7h.attributes)
}}})($lzc$class__m7h)
};{
Class.make("$lzc$class_textlistitem",["text_x",void 0,"$m77",function($0){
var $1=this.height/2-this._title.height/2;if($1!==this["text_y"]||!this.inited){
this.setAttribute("text_y",$1)
}},"$m78",function(){
try{
return [this,"height",this._title,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"text_y",void 0,"_title",void 0,"_applystyle",function($0){
var $1=this["style"];if($1!=null){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["_applystyle"]||this.nextMethod(arguments.callee,"_applystyle")).call(this,$0);var $2;if(this._enabled){
if(this.hilited){
$2=$1.texthilitecolor
}else if(this.selected){
$2=$1.textselectedcolor
}else{
$2=$1.textcolor
}}else{
$2=$1.textdisabledcolor
};if(this._title)this._title.setAttribute("fgcolor",$2)
}},"_showEnabled",function(){
(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["_showEnabled"]||this.nextMethod(arguments.callee,"_showEnabled")).call(this);if(this._initcomplete){
this._applystyle(this.style)
}},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_listitem,["tagname","textlistitem","children",[{attrs:{$classrootdepth:1,name:"_title",text:new LzAlwaysExpr("$m7f","$m7g",null),width:new LzAlwaysExpr("$m7d","$m7e",null),x:new LzAlwaysExpr("$m79","$m7a",null),y:new LzAlwaysExpr("$m7b","$m7c",null)},"class":$lzc$class__m7h}],"__LZCSSTagSelectors",["textlistitem","listitem","baselistitem","basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_listitem.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({text_x:4,text_y:new LzAlwaysExpr("$m77","$m78",null)},$lzc$class_textlistitem.attributes)
}}})($lzc$class_textlistitem)
};{
Class.make("$lzc$class__m7z",["$m7x",function($0){
this.setAttribute("width",this.parent.width)
},"$m7y",function($0){
this.setAttribute("height",this.parent.height)
},"reset",function(){
this.setAttribute("x",this.parent.insetleft);this.setAttribute("y",this.parent.insettop);this.setAttribute("width",this.parent.width-this.parent.insetleft-this.parent.insetright-1);this.setAttribute("height",this.parent.height-this.parent.insettop-this.parent.insetbottom-1)
},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m7z.attributes)
}}})($lzc$class__m7z)
};{
Class.make("$lzc$class_roundrect",["inset",void 0,"$lzc$set_inset",function($0){
this.setInset($0)
},"oninset",void 0,"$m7i",function($0){
var $1=null;if($1!==this["insetleft"]||!this.inited){
this.setAttribute("insetleft",$1)
}},"$m7j",function(){
try{
return []
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"insetleft",void 0,"$lzc$set_insetleft",function($0){
this.setInsetLeft($0)
},"oninsetleft",void 0,"$m7k",function($0){
var $1=null;if($1!==this["insetright"]||!this.inited){
this.setAttribute("insetright",$1)
}},"$m7l",function(){
try{
return []
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"insetright",void 0,"$lzc$set_insetright",function($0){
this.setInsetRight($0)
},"oninsetright",void 0,"$m7m",function($0){
var $1=null;if($1!==this["insettop"]||!this.inited){
this.setAttribute("insettop",$1)
}},"$m7n",function(){
try{
return []
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"insettop",void 0,"$lzc$set_insettop",function($0){
this.setInsetTop($0)
},"oninsettop",void 0,"$m7o",function($0){
var $1=null;if($1!==this["insetbottom"]||!this.inited){
this.setAttribute("insetbottom",$1)
}},"$m7p",function(){
try{
return []
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"insetbottom",void 0,"$lzc$set_insetbottom",function($0){
this.setInsetBottom($0)
},"oninsetbottom",void 0,"setInset",function($0){
this.insetleft=$0;this.insetright=$0;this.insettop=$0;this.insetbottom=$0;if(this.context)this.drawStructure();if(this.oninset)this.oninset.sendEvent()
},"setInsetLeft",function($0){
if($0)this.insetleft=$0;if(this.context)this.drawStructure();if(this.oninsetleft)this.oninsetleft.sendEvent()
},"setInsetRight",function($0){
if($0)this.insetright=$0;if(this.context)this.drawStructure();if(this.oninsetright)this.oninsetright.sendEvent()
},"setInsetTop",function($0){
if($0)this.insettop=$0;if(this.context)this.drawStructure();if(this.oninsettop)this.oninsettop.sendEvent()
},"setInsetBottom",function($0){
if($0)this.insetbottom=$0;if(this.context)this.drawStructure();if(this.oninsetbottom)this.oninsetbottom.sendEvent()
},"$m7q",function($0){
if(this.context)this.drawStructure()
},"$m7r",function($0){
if(this.context)this.drawStructure()
},"borderWidth",void 0,"borderRadius",void 0,"borderColor",void 0,"borderOpacity",void 0,"$m7s",function($0){
this.setAttribute("backgroundStartColor",null)
},"backgroundStartColor",void 0,"$m7t",function($0){
this.setAttribute("backgroundStopColor",null)
},"backgroundStopColor",void 0,"backgroundStartOpacity",void 0,"backgroundStopOpacity",void 0,"backgroundGradientOrientation",void 0,"boxShadowX",void 0,"boxShadowY",void 0,"$m7u",function($0){
this.setAttribute("boxShadowColor",null)
},"boxShadowColor",void 0,"boxShadowOpacity",void 0,"$m7v",function($0){
if(this.context)this.drawStructure()
},"$m7w",function($0){
this.drawStructure();this._cache=null
},"drawStructure",function(){
if(!this.context)return;if(!this["_cache"]){
this._cache={borderWidth:this.borderWidth,borderRadius:this.borderRadius,borderColor:this.borderColor,borderOpacity:this.borderOpacity,backgroundStartColor:this.backgroundStartColor,backgroundStopColor:this.backgroundStopColor,backgroundGradientOrientation:this.backgroundGradientOrientation,backgroundStartOpacity:this.backgroundStartOpacity,backgroundStopOpacity:this.backgroundStopOpacity,boxShadowColor:this.boxShadowColor,boxShadowOpacity:this.boxShadowOpacity,boxShadowX:this.boxShadowX,boxShadowY:this.boxShadowY,insetleft:this.insetleft,insettop:this.insettop,insetright:this.insetright,insetbottom:this.insetbottom,inset:this["inset"],height:this.height,width:this.width}}else{
var $0=false;var $1=this._cache;for(var $2 in $1){
if($1[$2]!=this[$2]){
$1[$2]=this[$2];$0=true;break
}};if($0==false)return
};var $3=this.borderWidth;var $4=this.borderRadius;var $5=$3/2;var $6=$3/2;var $7=this.backgroundStartColor;var $8=this.backgroundStopColor;this.clear();if(typeof this.content!="undefined"){
this.content.reset()
};if($3!=0&&this.boxShadowColor!=null&&this.boxShadowOpacity!=0){
var $9=this.boxShadowX;var $a=this.boxShadowY;this.beginPath();this.rect($9+$5,$a+$6,this.width-$3,this.height-$3,$4);this.fillStyle=this.boxShadowColor;this.globalAlpha=this.boxShadowOpacity;this.lineWidth=this.borderWidth;this.fill();if($7==null&&$8==null)$7=$8=16777215
};this.beginPath();this.rect($5,$6,this.width-$3,this.height-$3,$4);if($7!=null||$8!=null){
var $b=this.backgroundGradientOrientation=="vertical"?this.createLinearGradient(0,$3/2,0,this.height-$3):this.createLinearGradient($3/2,0,this.width-$3,0);var $c=this.backgroundStartOpacity;var $d=this.backgroundStopOpacity;if($7==null){
$7=$8;$c=0
};if($8==null){
$8=$7;$d=0
};this.globalAlpha=$c;$b.addColorStop(0,$7);this.globalAlpha=$d;$b.addColorStop(1,$8);this.fillStyle=$b;this.fill()
};this.strokeStyle=this.borderColor;this.lineWidth=this.borderWidth;this.globalAlpha=this.borderOpacity;this.stroke()
},"content",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_drawview,["tagname","roundrect","children",LzNode.mergeChildren([{attrs:{$classrootdepth:1,height:new LzOnceExpr("$m7y",null),name:"content",width:new LzOnceExpr("$m7x",null),x:0,y:0},"class":$lzc$class__m7z},{attrs:"content","class":$lzc$class_userClassPlacement}],$lzc$class_drawview["children"]),"__LZCSSTagSelectors",["roundrect","drawview","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_drawview.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",aliaslines:"boolean",align:"string",backgroundGradientOrientation:"string",backgroundStartColor:"color",backgroundStopColor:"color",backgroundrepeat:"string",bgcolor:"color",borderColor:"color",boxShadowColor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",fillStyle:"string",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",globalAlpha:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",inset:"size",insetbottom:"size",insetleft:"size",insetright:"size",insettop:"size",isinited:"boolean",layout:"css",lineCap:"string",lineJoin:"string",lineWidth:"number",loadratio:"number",mask:"string",measuresize:"boolean",miterLimit:"number",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",strokeStyle:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$delegates:["onwidth","$m7q",null,"onheight","$m7r",null,"oninit","$m7v",null,"oncontext","$m7w",null],backgroundGradientOrientation:"vertical",backgroundStartColor:new LzOnceExpr("$m7s",null),backgroundStartOpacity:1,backgroundStopColor:new LzOnceExpr("$m7t",null),backgroundStopOpacity:1,borderColor:0,borderOpacity:1,borderRadius:5,borderWidth:1,boxShadowColor:new LzOnceExpr("$m7u",null),boxShadowOpacity:0.5,boxShadowX:5,boxShadowY:5,height:100,inset:5,insetbottom:new LzAlwaysExpr("$m7o","$m7p",null),insetleft:new LzAlwaysExpr("$m7i","$m7j",null),insetright:new LzAlwaysExpr("$m7k","$m7l",null),insettop:new LzAlwaysExpr("$m7m","$m7n",null),oninset:null,oninsetbottom:null,oninsetleft:null,oninsetright:null,oninsettop:null,width:100},$lzc$class_roundrect.attributes)
}}})($lzc$class_roundrect)
};{
Class.make("$lzc$class__m8y",["$m80",function($0){
var $1=this.immediateparent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m81",function(){
try{
return [this.immediateparent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m82",function($0){
var $1=this.immediateparent.height;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$m83",function(){
try{
return [this.immediateparent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m84",function($0){
this.setAttribute("borderColor",this.parent.borderColor)
},"$m85",function($0){
this.setAttribute("borderWidth",this.parent.borderWidth)
},"$m86",function($0){
this.setAttribute("backgroundStartColor",this.parent.upStartColor)
},"$m87",function($0){
this.setAttribute("backgroundStopColor",this.parent.upStopColor)
},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_roundrect,["displayName","<anonymous extends='roundrect'>","children",LzNode.mergeChildren([],$lzc$class_roundrect["children"]),"__LZCSSTagSelectors",["roundrect","drawview","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_roundrect.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",aliaslines:"boolean",align:"string",backgroundGradientOrientation:"string",backgroundStartColor:"color",backgroundStopColor:"color",backgroundrepeat:"string",bgcolor:"color",borderColor:"color",boxShadowColor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",fillStyle:"string",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",globalAlpha:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",inset:"size",insetbottom:"size",insetleft:"size",insetright:"size",insettop:"size",isinited:"boolean",layout:"css",lineCap:"string",lineJoin:"string",lineWidth:"number",loadratio:"number",mask:"string",measuresize:"boolean",miterLimit:"number",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",strokeStyle:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m8y.attributes)
}}})($lzc$class__m8y)
};{
Class.make("$lzc$class__m8z",["$m88",function($0){
var $1=this.parent.width*0.5;if($1!==this["x"]||!this.inited){
this.setAttribute("x",$1)
}},"$m89",function(){
try{
return [this.parent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m8a",function($0){
var $1=this.classroot.text;if($1!==this["text"]||!this.inited){
this.setAttribute("text",$1)
}},"$m8b",function(){
try{
return [this.classroot,"text"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m8c",function($0){
var $1=this.parent.height*0.2;if($1!==this["fontsize"]||!this.inited){
this.setAttribute("fontsize",$1)
}},"$m8d",function(){
try{
return [this.parent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m8e",function($0){
var $1=this.classroot.enabled?this.classroot.fgcolor:"#CCCCCC";if($1!==this["fgcolor"]||!this.inited){
this.setAttribute("fgcolor",$1)
}},"$m8f",function(){
try{
return [this.classroot,"enabled",this.classroot,"fgcolor"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzText,["displayName","<anonymous extends='text'>","__LZCSSTagSelectors",["text","view","node","Instance"],"attributes",new LzInheritedHash(LzText.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",antiAliasType:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",cdata:"cdata",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",direction:"string",embedfonts:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",gridFit:"string",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",hscroll:"number",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",letterspacing:"number",lineheight:"number",loadratio:"number",mask:"string",maxhscroll:"number",maxlength:"numberExpression",maxscroll:"number",multiline:"boolean",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pattern:"string",pixellock:"boolean",placement:"string",playing:"boolean",resize:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",scroll:"number",scrollevents:"boolean",scrollheight:"number",scrollwidth:"number",selectable:"boolean",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",sharpness:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",textalign:"string",textdecoration:"string",textindent:"number",thickness:"number",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",xscroll:"number",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression",yscroll:"number"}}},$lzc$class__m8z.attributes)
}}})($lzc$class__m8z)
};{
Class.make("$lzc$class__m90",["$m8g",function($0){
var $1=this.height;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m8h",function(){
try{
return [this,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m8i",function($0){
var $1=this.parent.height*0.8;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$m8j",function(){
try{
return [this.parent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m8k",function($0){
var $1=this.parent.height*0.1;if($1!==this["x"]||!this.inited){
this.setAttribute("x",$1)
}},"$m8l",function(){
try{
return [this.parent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m8m",function($0){
var $1=this.parent.height*0.1;if($1!==this["y"]||!this.inited){
this.setAttribute("y",$1)
}},"$m8n",function(){
try{
return [this.parent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m8o",function($0){
var $1=this.classroot.resourcename;if($1!==this["resource"]||!this.inited){
this.setAttribute("resource",$1)
}},"$m8p",function(){
try{
return [this.classroot,"resourcename"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m8q",function($0){
var $1=this.classroot.enabled?1:0.2;if($1!==this["opacity"]||!this.inited){
this.setAttribute("opacity",$1)
}},"$m8r",function(){
try{
return [this.classroot,"enabled"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["displayName","<anonymous extends='view'>","__LZCSSTagSelectors",["view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}}},$lzc$class__m90.attributes)
}}})($lzc$class__m90)
};{
Class.make("$lzc$class_poodllbigbutton",["downStartColor",void 0,"downStopColor",void 0,"upStartColor",void 0,"upStopColor",void 0,"overStartColor",void 0,"overStopColor",void 0,"borderColor",void 0,"borderWidth",void 0,"resourcename",void 0,"_rr",void 0,"_label",void 0,"_iconview",void 0,"$m8s",function($0){
this._rr.setAttribute("backgroundStartColor",this.overStartColor);this._rr.setAttribute("backgroundStopColor",this.overStopColor);this._rr.drawStructure()
},"_applystyle",function($0){
this.setAttribute("downStartColor",$0.basecolor);this.setAttribute("downStopColor",$0.bgcolor);this.setAttribute("overStartColor",16777215);this.setAttribute("overStopColor",$0.basecolor);this.setAttribute("upStartColor",$0.hilitecolor);this.setAttribute("upStopColor",$0.basecolor);this._rr.setAttribute("backgroundStartColor",this.upStartColor);this._rr.setAttribute("backgroundStopColor",this.upStopColor);this._rr.setAttribute("bordercolor",$0.bordercolor);this._rr.setAttribute("borderwidth",$0.bordersize);this._rr.drawStructure()
},"$m8t",function($0){
this._rr.setAttribute("backgroundStartColor",this.overStartColor);this._rr.setAttribute("backgroundStopColor",this.overStopColor);this._rr.drawStructure()
},"$m8u",function($0){
this._rr.setAttribute("backgroundStartColor",this.upStartColor);this._rr.setAttribute("backgroundStopColor",this.upStopColor);this._rr.drawStructure()
},"$m8v",function($0){
this._rr.setAttribute("backgroundStartColor",this.downStartColor);this._rr.setAttribute("backgroundStopColor",this.downStopColor);this._rr.drawStructure()
},"$m8w",function($0){
if(!this["_rr"])return;this._rr.setAttribute("width",this.width);this._rr.drawStructure()
},"$m8x",function($0){
if(!this["_rr"])return;this._rr.setAttribute("height",this.height);this._rr.drawStructure()
},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_basecomponent,["tagname","poodllbigbutton","children",[{attrs:{$classrootdepth:1,backgroundStartColor:new LzOnceExpr("$m86",null),backgroundStopColor:new LzOnceExpr("$m87",null),borderColor:new LzOnceExpr("$m84",null),borderRadius:15,borderWidth:new LzOnceExpr("$m85",null),boxShadowColor:11776947,boxShadowX:0,boxShadowY:2,height:new LzAlwaysExpr("$m82","$m83",null),name:"_rr",width:new LzAlwaysExpr("$m80","$m81",null)},"class":$lzc$class__m8y},{attrs:{$classrootdepth:1,clickable:false,fgcolor:new LzAlwaysExpr("$m8e","$m8f",null),fontsize:new LzAlwaysExpr("$m8c","$m8d",null),fontstyle:"bold",name:"_label",resize:true,text:new LzAlwaysExpr("$m8a","$m8b",null),valign:"middle",x:new LzAlwaysExpr("$m88","$m89",null)},"class":$lzc$class__m8z},{attrs:{$classrootdepth:1,clickable:false,height:new LzAlwaysExpr("$m8i","$m8j",null),name:"_iconview",opacity:new LzAlwaysExpr("$m8q","$m8r",null),resource:new LzAlwaysExpr("$m8o","$m8p",null),stretches:"both",width:new LzAlwaysExpr("$m8g","$m8h",null),x:new LzAlwaysExpr("$m8k","$m8l",null),y:new LzAlwaysExpr("$m8m","$m8n",null)},"class":$lzc$class__m90}],"__LZCSSTagSelectors",["poodllbigbutton","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_basecomponent.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$attributeDescriptor:{types:{_focusable:"boolean",aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",borderColor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",doesenter:"boolean",downStartColor:"color",downStopColor:"color",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",overStartColor:"color",overStopColor:"color",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcename:"html",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",upStartColor:"color",upStopColor:"color",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$delegates:["onmouseover","$m8s",null,"onmouseup","$m8t",null,"onmouseout","$m8u",null,"onmousedown","$m8v",null,"onwidth","$m8w",null,"onheight","$m8x",null],borderColor:10066329,borderWidth:2,clickable:true,downStartColor:16777215,downStopColor:13421772,enabled:true,overStartColor:10066329,overStopColor:7829367,styleable:true,upStartColor:13421772,upStopColor:10066329},$lzc$class_poodllbigbutton.attributes)
}}})($lzc$class_poodllbigbutton)
};{
Class.make("$lzc$class__ma5",["$m9d",function($0){
var $1=this.classroot.usefontheight;if($1!==this["fontsize"]||!this.inited){
this.setAttribute("fontsize",$1)
}},"$m9e",function(){
try{
return [this.classroot,"usefontheight"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m9f",function($0){
var $1=this.classroot.currentcount;if($1!==this["text"]||!this.inited){
this.setAttribute("text",$1)
}},"$m9g",function(){
try{
return [this.classroot,"currentcount"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m9h",function($0){
var $1=this.classroot.canclick?255:16711680;if($1!==this["fgcolor"]||!this.inited){
this.setAttribute("fgcolor",$1)
}},"$m9i",function(){
try{
return [this.classroot,"canclick"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzText,["displayName","<anonymous extends='text'>","__LZCSSTagSelectors",["text","view","node","Instance"],"attributes",new LzInheritedHash(LzText.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",antiAliasType:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",cdata:"cdata",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",direction:"string",embedfonts:"boolean",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",gridFit:"string",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",hscroll:"number",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",letterspacing:"number",lineheight:"number",loadratio:"number",mask:"string",maxhscroll:"number",maxlength:"numberExpression",maxscroll:"number",multiline:"boolean",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pattern:"string",pixellock:"boolean",placement:"string",playing:"boolean",resize:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",scroll:"number",scrollevents:"boolean",scrollheight:"number",scrollwidth:"number",selectable:"boolean",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",sharpness:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",text:"html",textalign:"string",textdecoration:"string",textindent:"number",thickness:"number",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",xscroll:"number",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression",yscroll:"number"}}},$lzc$class__ma5.attributes)
}}})($lzc$class__ma5)
};Class.make("$lzc$class__ma4",["$m96",function($0){
var $1=this.parent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m97",function(){
try{
return [this.parent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m98",function($0){
var $1=this.parent.height-this.parent.buttonsview.height-30;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$m99",function(){
try{
return [this.parent,"height",this.parent.buttonsview,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m9a",function($0){
var $1=this.classroot.canclick;if($1!==this["clickable"]||!this.inited){
this.setAttribute("clickable",$1)
}},"$m9b",function(){
try{
return [this.classroot,"canclick"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m9c",function($0){
this.classroot.doClick()
},"countDisplay",void 0,"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_roundrect,["displayName","<anonymous extends='roundrect'>","children",LzNode.mergeChildren([{attrs:{$classrootdepth:2,align:"center",fgcolor:new LzAlwaysExpr("$m9h","$m9i",null),fontsize:new LzAlwaysExpr("$m9d","$m9e",null),name:"countDisplay",text:new LzAlwaysExpr("$m9f","$m9g",null),valign:"middle"},"class":$lzc$class__ma5}],$lzc$class_roundrect["children"]),"__LZCSSTagSelectors",["roundrect","drawview","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_roundrect.attributes)]);Class.make("$lzc$class__ma6",["$m9j",function($0){
var $1=this.classroot.canclick;if($1!==this["enabled"]||!this.inited){
this.setAttribute("enabled",$1)
}},"$m9k",function(){
try{
return [this.classroot,"canclick"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m9l",function($0){
var $1=this.classroot.initcount==0?"add_button":"remove_button";if($1!==this["resourcename"]||!this.inited){
this.setAttribute("resourcename",$1)
}},"$m9m",function(){
try{
return [this.classroot,"initcount"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m9n",function($0){
var $1=this.classroot.usepresets?(this.parent.parent.displayview.width-180)*0.33:this.parent.parent.displayview.width*0.33-10;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m9o",function(){
try{
return [this.classroot,"usepresets",this.parent.parent.displayview,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m9p",function($0){
if(this.enabled){
this.classroot.doClick()
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_poodllbigbutton,["displayName","<anonymous extends='poodllbigbutton'>","children",LzNode.mergeChildren([],$lzc$class_poodllbigbutton["children"]),"__LZCSSTagSelectors",["poodllbigbutton","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_poodllbigbutton.attributes)]);Class.make("$lzc$class__ma7",["$m9q",function($0){
var $1=this.classroot.usepresets?(this.parent.parent.displayview.width-180)*0.33:this.parent.parent.displayview.width*0.33-10;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m9r",function(){
try{
return [this.classroot,"usepresets",this.parent.parent.displayview,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m9s",function($0){
var $1=this.classroot.initcount==0?"remove_button":"add_button";if($1!==this["resourcename"]||!this.inited){
this.setAttribute("resourcename",$1)
}},"$m9t",function(){
try{
return [this.classroot,"initcount"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m9u",function($0){
var $1=this.classroot.currentcount!=this.classroot.initcount;if($1!==this["enabled"]||!this.inited){
this.setAttribute("enabled",$1)
}},"$m9v",function(){
try{
return [this.classroot,"currentcount",this.classroot,"initcount"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m9w",function($0){
if(this.enabled){
this.classroot.doUnclick()
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_poodllbigbutton,["displayName","<anonymous extends='poodllbigbutton'>","children",LzNode.mergeChildren([],$lzc$class_poodllbigbutton["children"]),"__LZCSSTagSelectors",["poodllbigbutton","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_poodllbigbutton.attributes)]);Class.make("$lzc$class__ma8",["$m9x",function($0){
var $1=this.classroot.usepresets?(this.parent.parent.displayview.width-180)*0.33:this.parent.parent.displayview.width*0.33-10;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$m9y",function(){
try{
return [this.classroot,"usepresets",this.parent.parent.displayview,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$m9z",function($0){
var $1=this.classroot.currentcount!=this.classroot.initcount;if($1!==this["enabled"]||!this.inited){
this.setAttribute("enabled",$1)
}},"$ma0",function(){
try{
return [this.classroot,"currentcount",this.classroot,"initcount"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$ma1",function($0){
this.classroot.doReset()
},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_poodllbigbutton,["displayName","<anonymous extends='poodllbigbutton'>","children",LzNode.mergeChildren([],$lzc$class_poodllbigbutton["children"]),"__LZCSSTagSelectors",["poodllbigbutton","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_poodllbigbutton.attributes)]);Class.make("$lzc$class__ma9",["$ma2",function($0){
this.setAttribute("visible",this.classroot.usepresets)
},"$ma3",function($0){
if(this.classroot.usepresets){
this.classroot.setAttribute("initcount",this.value);this.classroot.doReset()
}},"$classrootdepth",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_combobox,["displayName","<anonymous extends='combobox'>","children",LzNode.mergeChildren([{attrs:{$classrootdepth:3,selected:true,text:"Count Forward",value:0},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 2",value:2},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 3",value:3},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 4",value:4},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 5",value:5},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 6",value:6},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 7",value:7},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 8",value:8},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 9",value:9},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 10",value:10},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 15",value:15},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 20",value:20},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 25",value:25},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 30",value:30},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 35",value:35},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 40",value:40},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 45",value:45},"class":$lzc$class_textlistitem},{attrs:{$classrootdepth:3,text:"backwards from 50",value:50},"class":$lzc$class_textlistitem}],$lzc$class_combobox["children"]),"__LZCSSTagSelectors",["combobox","basecombobox","baseformitem","basevaluecomponent","basecomponent","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_combobox.attributes)]);{
Class.make("$lzc$class_counterview",["fontheight",void 0,"$m91",function($0){
var $1=this.fontheight==null||this.fontheight==0?this.height*0.3:this.fontheight;if($1!==this["usefontheight"]||!this.inited){
this.setAttribute("usefontheight",$1)
}},"$m92",function(){
try{
return [this,"fontheight",this,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"usefontheight",void 0,"initcount",void 0,"currentcount",void 0,"usepresets",void 0,"$m93",function($0){
var $1=!(this.initcount!="0"&&this.currentcount==0);if($1!==this["canclick"]||!this.inited){
this.setAttribute("canclick",$1)
}},"$m94",function(){
try{
return [this,"initcount",this,"currentcount"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"canclick",void 0,"doClick",function(){
if(this.initcount!=0){
this.setAttribute("currentcount",this.currentcount-1)
}else{
this.setAttribute("currentcount",this.currentcount+1)
}},"doUnclick",function(){
if(this.initcount!=0){
this.setAttribute("currentcount",this.currentcount+1)
}else{
this.setAttribute("currentcount",this.currentcount-1)
}},"doReset",function(){
this.setAttribute("currentcount",parseInt(this.initcount))
},"$m95",function($0){
this.doReset()
},"displayview",void 0,"buttonsview",void 0,"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],LzView,["tagname","counterview","children",[{attrs:{$classrootdepth:1,axis:"y",inset:10,spacing:10},"class":$lzc$class_simplelayout},{attrs:{$classrootdepth:1,$delegates:["onclick","$m9c",null],align:"center",backgroundStartColor:15658734,backgroundStopColor:14540253,borderColor:255,borderWidth:5,clickable:new LzAlwaysExpr("$m9a","$m9b",null),countDisplay:void 0,height:new LzAlwaysExpr("$m98","$m99",null),name:"displayview",width:new LzAlwaysExpr("$m96","$m97",null)},"class":$lzc$class__ma4},{attrs:{$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$classrootdepth:1,actionButton:void 0,align:"center",countcombo:void 0,gobackButton:void 0,name:"buttonsview",resetButton:void 0},children:[{attrs:{$classrootdepth:2,axis:"x",inset:10,spacing:10},"class":$lzc$class_simplelayout},{attrs:{$classrootdepth:2,$delegates:["onclick","$m9p",null],clickable:true,enabled:new LzAlwaysExpr("$m9j","$m9k",null),height:40,name:"actionButton",resourcename:new LzAlwaysExpr("$m9l","$m9m",null),text:"Count",width:new LzAlwaysExpr("$m9n","$m9o",null)},"class":$lzc$class__ma6},{attrs:{$classrootdepth:2,$delegates:["onclick","$m9w",null],clickable:true,enabled:new LzAlwaysExpr("$m9u","$m9v",null),height:40,name:"gobackButton",resourcename:new LzAlwaysExpr("$m9s","$m9t",null),text:"Go Back",width:new LzAlwaysExpr("$m9q","$m9r",null)},"class":$lzc$class__ma7},{attrs:{$classrootdepth:2,$delegates:["onclick","$ma1",null],clickable:true,enabled:new LzAlwaysExpr("$m9z","$ma0",null),height:40,name:"resetButton",resourcename:"reset_button",text:"RESET",width:new LzAlwaysExpr("$m9x","$m9y",null)},"class":$lzc$class__ma8},{attrs:{$classrootdepth:2,$delegates:["onselect","$ma3",null],editable:false,name:"countcombo",valign:"middle",visible:new LzOnceExpr("$ma2",null),width:150},"class":$lzc$class__ma9}],"class":LzView}],"__LZCSSTagSelectors",["counterview","view","node","Instance"],"attributes",new LzInheritedHash(LzView.attributes)]);(function($0){
with($0)with($0.prototype){
{
LzNode.mergeAttributes({$CSSDescriptor:{},$attributeDescriptor:{types:{aaactive:"boolean",aadescription:"string",aaname:"string",aasilent:"boolean",aatabindex:"number",align:"string",backgroundrepeat:"string",bgcolor:"color",cachebitmap:"boolean",capabilities:"string",classroot:"string",clickable:"boolean",clickregion:"string",clip:"boolean",cloneManager:"string",contextmenu:"string",cornerradius:"string",currentcount:"number",cursor:"token",datapath:"string",defaultplacement:"string",fgcolor:"color",focusable:"boolean",focustrap:"boolean",font:"string",fontsize:"size",fontstyle:"string",frame:"numberExpression",framesloadratio:"number",hasdirectionallayout:"boolean",hassetheight:"boolean",hassetwidth:"boolean",height:"size",id:"ID",ignoreplacement:"boolean",immediateparent:"string",initcount:"number",inited:"boolean",initstage:"string",isinited:"boolean",layout:"css",loadratio:"number",mask:"string",name:"token",nodeLevel:"number",opacity:"number",options:"css",parent:"string",pixellock:"boolean",placement:"string",playing:"boolean",resource:"string",resourceheight:"number",resourcewidth:"number",rotation:"numberExpression",shadowangle:"number",shadowblurradius:"number",shadowcolor:"color",shadowdistance:"number",showhandcursor:"boolean",source:"string",stretches:"string",styleclass:"string",subnodes:"string",subviews:"string",tintcolor:"string",totalframes:"number",transition:"string",unstretchedheight:"number",unstretchedwidth:"number",usegetbounds:"boolean",valign:"string",visibility:"string",visible:"boolean",width:"size","with":"string",x:"numberExpression",xoffset:"numberExpression",xscale:"numberExpression",y:"numberExpression",yoffset:"numberExpression",yscale:"numberExpression"}},$delegates:["oninit","$m95",null],canclick:new LzAlwaysExpr("$m93","$m94",null),currentcount:0,initcount:0,usefontheight:new LzAlwaysExpr("$m91","$m92",null),usepresets:false},$lzc$class_counterview.attributes)
}}})($lzc$class_counterview)
};Class.make("$lzc$class__mak",["$maa",function($0){
var $1=canvas.initcount;if($1!==this["initcount"]||!this.inited){
this.setAttribute("initcount",$1)
}},"$mab",function(){
try{
return [canvas,"initcount"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$mac",function($0){
var $1=canvas.usepresets=="true";if($1!==this["usepresets"]||!this.inited){
this.setAttribute("usepresets",$1)
}},"$mad",function(){
try{
return [canvas,"usepresets"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$mae",function($0){
var $1=canvas.fontheight;if($1!==this["fontheight"]||!this.inited){
this.setAttribute("fontheight",$1)
}},"$maf",function(){
try{
return [canvas,"fontheight"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$mag",function($0){
var $1=this.parent.width;if($1!==this["width"]||!this.inited){
this.setAttribute("width",$1)
}},"$mah",function(){
try{
return [this.parent,"width"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$mai",function($0){
var $1=this.parent.height;if($1!==this["height"]||!this.inited){
this.setAttribute("height",$1)
}},"$maj",function(){
try{
return [this.parent,"height"]
}
catch($lzsc$e){
if(Error["$lzsc$isa"]?Error.$lzsc$isa($lzsc$e):$lzsc$e instanceof Error){
lz.$lzsc$thrownError=$lzsc$e
};throw $lzsc$e
}},"$lzsc$initialize",function($0,$1,$2,$3){
switch(arguments.length){
case 0:
$0=null;
case 1:
$1=null;
case 2:
$2=null;
case 3:
$3=false;

};(arguments.callee["$superclass"]&&arguments.callee.$superclass.prototype["$lzsc$initialize"]||this.nextMethod(arguments.callee,"$lzsc$initialize")).call(this,$0,$1,$2,$3)
}],$lzc$class_counterview,["displayName","<anonymous extends='counterview'>","children",LzNode.mergeChildren([],$lzc$class_counterview["children"]),"__LZCSSTagSelectors",["counterview","view","node","Instance"],"attributes",new LzInheritedHash($lzc$class_counterview.attributes)]);canvas.LzInstantiateView({attrs:{fontheight:new LzAlwaysExpr("$mae","$maf",null),height:new LzAlwaysExpr("$mai","$maj",null),initcount:new LzAlwaysExpr("$maa","$mab",null),usepresets:new LzAlwaysExpr("$mac","$mad",null),width:new LzAlwaysExpr("$mag","$mah",null)},"class":$lzc$class__mak},89);lz["basefocusview"]=$lzc$class_basefocusview;lz["focusoverlay"]=$lzc$class_focusoverlay;lz["_componentmanager"]=$lzc$class__componentmanager;lz["style"]=$lzc$class_style;lz["statictext"]=$lzc$class_statictext;lz["basecomponent"]=$lzc$class_basecomponent;lz["basevaluecomponent"]=$lzc$class_basevaluecomponent;lz["baseformitem"]=$lzc$class_baseformitem;lz["selectionmanager"]=$lzc$class_selectionmanager;lz["listselector"]=$lzc$class_listselector;lz["dataselectionmanager"]=$lzc$class_dataselectionmanager;lz["datalistselector"]=$lzc$class_datalistselector;lz["baselist"]=$lzc$class_baselist;lz["basetrackgroup"]=$lzc$class_basetrackgroup;lz["basebutton"]=$lzc$class_basebutton;lz["basebuttonrepeater"]=$lzc$class_basebuttonrepeater;lz["basescrollbar"]=$lzc$class_basescrollbar;lz["basescrollthumb"]=$lzc$class_basescrollthumb;lz["basescrollarrow"]=$lzc$class_basescrollarrow;lz["basescrolltrack"]=$lzc$class_basescrolltrack;lz["layout"]=LzLayout;lz["stableborderlayout"]=$lzc$class_stableborderlayout;lz["vscrollbar"]=$lzc$class_vscrollbar;lz["simplelayout"]=$lzc$class_simplelayout;lz["list"]=$lzc$class_list;lz["basefloatinglist"]=$lzc$class_basefloatinglist;lz["_floatshadow"]=$lzc$class__floatshadow;lz["floatinglist"]=$lzc$class_floatinglist;lz["basecombobox"]=$lzc$class_basecombobox;lz["combobox"]=$lzc$class_combobox;lz["baselistitem"]=$lzc$class_baselistitem;lz["listitem"]=$lzc$class_listitem;lz["textlistitem"]=$lzc$class_textlistitem;lz["roundrect"]=$lzc$class_roundrect;lz["poodllbigbutton"]=$lzc$class_poodllbigbutton;lz["counterview"]=$lzc$class_counterview;canvas.initDone();