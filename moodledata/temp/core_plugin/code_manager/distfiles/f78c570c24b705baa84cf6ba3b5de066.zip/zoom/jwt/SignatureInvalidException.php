<?php
//@codingStandardsIgnoreStart - Ignore library file.
namespace Firebase\JWT;
class SignatureInvalidException extends \UnexpectedValueException {}
