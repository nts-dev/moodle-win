PoodLL All
========================================
Thanks for downloading the PoodLL filter

Information on installing the PoodLL filter and getting started in general is available here.
https://poodll.com/poodll-3-docs/getting-started/

In short however, upload the unzipped PoodLL filter into a directory called "poodll" in your Moodle site, under [path to Moodle]/filter

Be sure that the files are in such a structure that [path to Moodle]/filter/poodll/version.php exists. If your folder structure is different Moodle will complain.

Setting up the PoodLL Filter
=============================
After you install the PoodLL filter you will be presented with an impossibly long list of settings. 
Just scroll to the bottom and save those settings as the defaults. Later you can return and edit them using from the site administration.


More instructions, documentation and tutorials are available at https://poodll.com/poodll-3-docs/

Good luck.

Justin Hunt
The PoodLL Guy
http://www.poodll.com
poodllsupport@gmail.com