
H5P.externalDispatcher.on('xAPI', function (event) {
//	console.log(event)

	const verb = event.getVerb();
	var currentdate = new Date();
	var n =  currentdate.getHours() + ":"
                + currentdate.getMinutes() + ":"
                + currentdate.getSeconds();
	const data = {
			
		start_time: n,
		answer: "Printer",
		slide_score: 0,
		question_type: "Multi-choice",
		slide_position: 0
	}
//	console.log(event.data.statement.object.definition);

	if(verb === "interacted"){
		//h5p-answer h5p-selected
		$.post("/captivate/data.php", data, function(e){
		
			console.log(e.message);
		})
		console.log("Value" + event.data.statement.result );
		
	}
	if(verb ==="attempted"){
//		console.log(event.allowedXAPIVerbs);
//		console.log(event.data.statement); 
	}
});

